// src/firebase.js
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyDL-LRaIw2hNnNrTxNxZC4qe5-UyYmSVYs",
  authDomain: "ust-fyp-e7858.firebaseapp.com",
  projectId: "ust-fyp-e7858",
  storageBucket: "ust-fyp-e7858.firebasestorage.app",
  messagingSenderId: "770473672213",
  appId: "1:770473672213:web:b8f90a413b7d9bb80a981c",
  measurementId: "G-LVJYEEGT6B",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

export const auth = getAuth(app); // Export auth object
export const db = getFirestore(app);