<script>
	import { auth } from '../../firebase';
	import { createUserWithEmailAndPassword } from 'firebase/auth';
	import { getFirestore, doc, setDoc } from 'firebase/firestore';
	import { FirebaseError } from 'firebase/app';
	import { goto } from '$app/navigation';

	let email = '';
	let password = '';
	let firstName = '';
	let lastName = '';
	let className = '';
	let errorMessage = '';
	let role = '';

	const db = getFirestore();
	const signUp = async () => {
		try {
			errorMessage = '';
			// Create user authentication
			const userCredential = await createUserWithEmailAndPassword(auth, email, password);


			// Add user to students collection with additional details
			await setDoc(doc(db, 'users', userCredential.user.uid), {
				email: email,
				firstName: firstName,
				lastName: lastName,
				class: className,
				role: role,
				userId: userCredential.user.uid,
				createdAt: new Date().toISOString()
			});

			console.log('User signed up:', userCredential.user);
			alert('Sign-up successful!');
			goto('/');
			email = '';
			password = '';
			firstName = '';
			lastName = '';
			className = '';
		} catch (error) {
			if (error instanceof FirebaseError) {
				console.error('Sign-up failed:', error);
				switch (error.code) {
					case 'auth/email-already-in-use':
						errorMessage =
							'This email is already registered. Please use a different email address.';
						break;
					case 'auth/invalid-email':
						errorMessage = 'Please enter a valid email address.';
						break;
					case 'auth/weak-password':
						errorMessage = 'Password should be at least 6 characters long.';
						break;
					default:
						errorMessage = 'An error occurred during sign up. Please try again.';
				}
			} else {
				errorMessage = 'An unexpected error occurred. Please try again.';
			}
		}
	};
</script>

<div class="page-container">
	<div class="logo">Power Writing</div>
	<div class="signup-container">
		<h1>Create a new account</h1>
		<p>It's quick and easy.</p>
		<form on:submit|preventDefault={signUp}>
			<select name="roles" id="roles" bind:value={role} required>
				<option value="" selected disabled hidden>Please select your role</option>
				<option value="student">Student</option>
				<option value="teacher">Teacher</option>
			</select>
			<div class="name-row">
				<input type="text" placeholder="First name" bind:value={firstName} required />
				<input type="text" placeholder="Last name" bind:value={lastName} required />
			</div>
			<input type="text" placeholder="Class" bind:value={className} required />
			<input type="email" placeholder="Email address" bind:value={email} required />
			<input type="password" placeholder="Password" bind:value={password} required />
			{#if errorMessage}
				<p class="error">{errorMessage}</p>
			{/if}
			<button type="submit">Sign Up</button>
		</form>
		<div class="footer">
			Already have an account? <a href="/">Log In</a>
		</div>
	</div>
</div>

<style>
	.page-container {
		min-height: 100vh;
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
	}

	.signup-container {
		background: white;
		border-radius: 8px;
		box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
		width: 360px;
		padding: 2rem;
		text-align: center;
	}

	.logo {
		font-size: 2.5rem;
		font-weight: bold;
		color: #6b47dc;
		margin-bottom: 1rem;
	}

	h1 {
		font-size: 1.5rem;
		font-weight: bold;
		margin-bottom: 1rem;
		color: #333;
	}

	p {
		color: #666;
		font-size: 0.9rem;
		margin-bottom: 1.5rem;
	}

	form {
		display: flex;
		flex-direction: column;
		gap: 1rem;
	}

	input, select {
		padding: 0.8rem;
		font-size: 1rem;
		border: 1px solid #ccc;
		border-radius: 6px;
		transition: border-color 0.3s;
	}

	input:focus {
		border-color: #1877f2;
		outline: none;
	}

	button {
		background-color: #000000;
		color: white;
		font-size: 1rem;
		padding: 0.8rem;
		border: none;
		border-radius: 6px;
		cursor: pointer;
		transition: background 0.3s;
	}

	button:hover {
		background-color: #333333;
	}

	.error {
		font-size: 0.9rem;
		color: red;
		margin-top: -0.5rem;
		margin-bottom: 1rem;
	}

	.footer {
		font-size: 0.9rem;
		margin-top: 1.5rem;
		color: #666;
	}

	.footer a {
		color: #1877f2;
		text-decoration: none;
		font-weight: bold;
	}

	.footer a:hover {
		text-decoration: underline;
	}

	.name-row {
		display: flex;
		gap: 1rem;
		width: 100%;
	}

	.name-row input {
		width: 50%;
		min-width: 0; 
	}
</style>
