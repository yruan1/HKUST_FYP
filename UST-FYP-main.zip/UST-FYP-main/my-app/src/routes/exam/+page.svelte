<script lang="ts">
	import { onMount } from 'svelte';

	let timeLeft = 55 * 60;
	let wordCount = 0;
	let currentAnswer = '';
	let currentPart = 1;

    interface Question {
    title: string;
    instructions: string;
    questionText: string;
    }

    interface Questions {
        [key: number]: Question;
    }
	// Questions data
	const questions: Questions = {
    1: {
        title: 'Part 1',
        instructions: 'You should spend about 20 minutes on this task. Write at least 150 words.',
        questionText: 'Summarise the information by selecting and reporting the main features, and make comparisons where relevant.'
    },
    2: {
        title: 'Part 2',
        instructions: 'You should spend about 40 minutes on this task. Write at least 250 words.',
        questionText: 'Some people think that parents should teach children how to be good members of society. Others, however, believe that school is the place to learn this. Discuss both these views and give your own opinion.'
    }
};

	// Format the time into mm:ss format
	const formatTime = (seconds: number): string => {
		const minutes = Math.floor(seconds / 60);
		const remainingSeconds = seconds % 60;
		return `${minutes}:${remainingSeconds.toString().padStart(2, '0')} LEFT`;
	};

	// Update word count based on textarea input
	const updateWordCount = (text: string) => {
		const words = text.trim().split(/\s+/);
		wordCount = text.trim() === '' ? 0 : words.length;
	};

	// Handle input event for the textarea
	const handleInput = (event: Event) => {
		const target = event.target as HTMLTextAreaElement;
		currentAnswer = target.value;
		updateWordCount(currentAnswer);
	};

	// Handle part change
	const handlePartClick = (part: number, e: MouseEvent) => {
		e.preventDefault();
		currentPart = part;
	};

    // Handle next button click
    const handleNextClick = () => {
        if (currentPart < 2) {
            currentPart++;
        }
    };

	const handleDirectionClick = () => {
        if (currentPart === 1) {
            currentPart = 2;
        } else {
            currentPart = 1;
        }
    };

	// Decrease timeLeft every second
	onMount(() => {
		const interval = setInterval(() => {
			if (timeLeft > 0) timeLeft--;
		}, 1000);

		return () => clearInterval(interval); // Cleanup interval on component destroy
	});
</script>

<main class="exam-interface">
	<header class="exam-header">
		<button class="nav-btn exit-btn">← EXIT</button>
		<div class="timer">
			<span class="timer-icon">⏱</span>
			<span>{formatTime(timeLeft)}</span>
		</div>
		<button class="nav-btn submit-btn">SUBMIT →</button>
	</header>

	<div class="exam-content">
		<div class="question-section">
			<div class="question-card">
				<h2>{questions[currentPart].title}</h2>
				<p class="instructions">
					{questions[currentPart].instructions}
				</p>
				<p class="question-text">
					{questions[currentPart].questionText}
				</p>
			</div>
		</div>

		<div class="answer-section">
			<div class="answer-card">
				<textarea placeholder="Write here." on:input={handleInput} bind:value={currentAnswer}
				></textarea>
				<div class="word-count">Word Count: {wordCount}</div>
			</div>
		</div>
	</div>

	<footer class="exam-footer">
		<div class="part-navigation">
			<a
				href="#"
				class="part-btn {currentPart === 1 ? 'active' : ''}"
				on:click={(e) => handlePartClick(1, e)}
			>
				Part 1
				<span class="part-number">1</span>
			</a>
			<a
				href="#"
				class="part-btn {currentPart === 2 ? 'active' : ''}"
				on:click={(e) => handlePartClick(2, e)}
			>
				Part 2
				<span class="part-number">2</span>
			</a>
		</div>
		<button class="next-btn" on:click={handleDirectionClick}>
			{currentPart === 1 ? '→' : '←'}
		</button>
	</footer>
</main>

<style>
	/* Reset margin and padding for body and html */
	:global(html, body) {
		margin: 0;
		padding: 0;
		width: 100%;
		height: 100%;
	}

	.exam-interface {
		height: 100vh;
		display: flex;
		flex-direction: column;
		background-color: #f5f5f5;
		font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
	}

	.exam-header {
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding: 0 20px; /* Adjust padding for proper spacing */
		background-color: #2b2b2b;
		color: white;
		height: 75px;
		box-shadow: 0 2px 4px rgba(0, 0, 0, 0.15);
	}

	.nav-btn {
		border: none;
		background: none;
		color: white;
		cursor: pointer;
		font-size: 13px;
		padding: 0;
		font-weight: 400;
		letter-spacing: 0.2px;
		display: flex;
		align-items: center;
		gap: 4px;
	}

	.exit-btn {
		margin-right: auto;
	}

	.submit-btn {
		margin-left: auto;
	}

	.timer {
		font-size: 13px;
		color: #ffd700;
		display: flex;
		align-items: center;
		gap: 4px;
		font-weight: 500;
		position: absolute;
		left: 50%;
		transform: translateX(-50%);
	}

	.timer-icon {
		font-size: 14px;
		margin-right: 2px;
	}

	.exam-content {
		display: flex;
		flex: 1;
		padding: 1.5rem;
		gap: 1.5rem;
		width: 100%;
		max-width: 100%;
		box-sizing: border-box;
	}

	.question-section,
	.answer-section {
		flex: 1;
		display: flex;
		flex-direction: column;
	}

	.question-card,
	.answer-card {
		background: white;
		border-radius: 20px;
		padding: 2rem;
		box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
		height: 100%;
	}

	h2 {
		font-size: 1.5rem;
		color: #333;
		margin: 0 0 1rem 0;
		font-weight: 600;
	}

	.instructions {
		color: #666;
		margin-bottom: 1.5rem;
		line-height: 1.5;
	}

	.question-text {
		line-height: 1.5;
		color: #333;
	}

	textarea {
		width: 100%;
		height: calc(100% - 30px);
		padding: 0.2rem;
		border: 1px solid #e0e0e0;
		border-radius: 4px;
		resize: none;
		font-size: 1rem;
		line-height: 1.5;
		color: #333;
		background: #fff;
		/* Add margin-top to move the textarea down */
		margin-top: 0rem; /* Adjust this value as needed */

	}

	textarea:focus {
		outline: none;
		border-color: #4a90e2;
	}

	.word-count {
		margin-top: 0.4rem;
		color: #666;
		font-size: 0.9rem;
		text-align: right;
	}

	.exam-footer {
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding: 1rem 1.5rem;
		background-color: white;
		border-top: 1px solid #eee;
	}

	.part-navigation {
		display: flex;
		gap: 1.5rem;
	}

	.part-btn {
		display: flex;
		align-items: center;
		gap: 0.5rem;
		color: #333;
		text-decoration: none;
		font-size: 0.9rem;
		font-weight: 500;
	}

	.part-btn.active {
		color: #333;
	}

	.part-number {
		display: inline-flex;
		align-items: center;
		justify-content: center;
		width: 24px;
		height: 24px;
		border-radius: 50%;
		background-color: #464646; /* Dark gray for inactive */
		color: white;
		font-size: 0.9rem;
		font-weight: 500;
	}

	.part-btn.active .part-number {
		background-color: #4d7fff; /* Blue for active */
	}

	.next-btn {
		width: 36px;
		height: 36px;
		border: none;
		background: #333;
		color: white;
		border-radius: 4px;
		cursor: pointer;
		display: flex;
		align-items: center;
		justify-content: center;
		font-size: 1rem;
	}

	@media (max-width: 768px) {
		.exam-content {
			flex-direction: column;
			padding: 1rem;
		}
	}
</style>