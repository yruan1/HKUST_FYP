import { collection, getDocs , getDoc, doc} from "firebase/firestore"; 
import {db} from "$lib/firebase";
import {json} from '@sveltejs/kit';
/*export async function GET(){

    const querySnapshot = await getDocs(collection(db, "assignmentResult/grading"));
    querySnapshot.forEach((doc) => {
        console.log(`${doc.id} => ${doc.data()}`);
    });
    return new Response(Object(doc.data()));

    
}*/

let doc_id = 'a2m4BCYc1CfXRch73TSO';

export async function GET() {
        const querySnapshot = await getDoc(doc(db, 'assignmentResult', doc_id));
        const data = querySnapshot.data();
        //return new Response(JSON.stringify(data));
        return json(data);
}

