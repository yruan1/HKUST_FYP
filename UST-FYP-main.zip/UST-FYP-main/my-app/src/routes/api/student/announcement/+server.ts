import { collection, getDocs , getDoc, doc} from "firebase/firestore"; 
import {db} from "$lib/firebase";
import {json} from '@sveltejs/kit';
import type { RequestHandler } from './$types';

export const GET: RequestHandler = async ({ url }) => {
    const uid = url.searchParams.get('uid');
    const querySnapshot = await getDocs(collection(db, 'classes/1a/announcements'));
    //const data = querySnapshot.data();
    //let announcement = data.announcement;
    const announcements = querySnapshot.docs.map(doc => ({
        id: doc.id, // Document ID
        ...doc.data() // Document data
    }));
    return json({
        announcements
    })
};