import {db} from "$lib/firebase";
import {json} from '@sveltejs/kit';

export async function POST({ request, cookies }) {
	const { description } = await request.json();

	const uid = cookies.get('uid');
	const { id } = await db.createTodo({ uid, description });

	return json({ id }, { status: 201 });
}