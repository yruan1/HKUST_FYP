import { doc, updateDoc } from "firebase/firestore";
import { db } from "$lib/firebase";
import { json } from '@sveltejs/kit';
import type { RequestHandler } from './$types';
import { error } from '@sveltejs/kit';

export const PUT: RequestHandler = async ({ request, url }) => {
    const classId = url.searchParams.get('class');
    const announcementId = url.searchParams.get('id');
    
    if (!classId || !announcementId) {
        throw error(400, 'Class ID and Announcement ID are required');
    }

    try {
        const data = await request.json();
        const announcementRef = doc(db, `classes/${classId}/announcements/${announcementId}`);
        
        await updateDoc(announcementRef, {
            title: data.title,
            content: data.content,
            updatedAt: new Date()
        });

        return json({ success: true });
    } catch (e) {
        console.error('Error updating announcement:', e);
        throw error(500, 'Failed to update announcement');
    }
};