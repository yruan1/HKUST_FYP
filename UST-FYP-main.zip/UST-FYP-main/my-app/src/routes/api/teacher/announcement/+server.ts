import { collection, getDocs , getDoc, doc} from "firebase/firestore"; 
import {db} from "$lib/firebase";
import {json} from '@sveltejs/kit';
import type { RequestHandler } from './$types';

export const GET: RequestHandler = async ({ url }) => {
    const user_class = url.searchParams.get('class');
    const querySnapshot = await getDocs(collection(db, 'classes/'+user_class+'/announcements'));
    const announcements = querySnapshot.docs.map(doc => ({
        id: doc.id, // Document ID
        ...doc.data() // Document data
    }));
    return json(
        announcements
    )
};