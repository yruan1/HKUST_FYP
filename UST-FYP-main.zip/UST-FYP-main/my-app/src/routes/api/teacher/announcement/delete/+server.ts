import { deleteDoc, doc } from "firebase/firestore";
import { db } from "$lib/firebase";
import { json } from '@sveltejs/kit';
import type { RequestHandler } from './$types';
import { error } from '@sveltejs/kit';

export const DELETE: RequestHandler = async ({ url }) => {
    const classId = url.searchParams.get('class');
    const announcementId = url.searchParams.get('id');
    
    if (!classId || !announcementId) {
        throw error(400, 'Class ID and Announcement ID are required');
    }

    try {
        const announcementRef = doc(db, `classes/${classId}/announcements/${announcementId}`);
        await deleteDoc(announcementRef);
        return json({ success: true });
    } catch (e) {
        console.error('Error deleting announcement:', e);
        throw error(500, 'Failed to delete announcement');
    }
};