import { json } from '@sveltejs/kit';
import type { RequestEvent } from '@sveltejs/kit';
import { getFirestore } from 'firebase-admin/firestore';
import { db } from '$lib/firebase/admin';

export async function GET({ request }: RequestEvent) {
    try {
        const writingsRef = db.collection('examResult');
        const snapshot = await writingsRef.get();
        
        const writings = [];
        snapshot.forEach(doc => {
            const data = doc.data();
            if (data.answers) {
                // 处理每个answer为单独的写作样本
                Object.entries(data.answers).forEach(([id, answer]) => {
                    if (typeof answer === 'string' && answer.length > 100) { // 只获取较长的文本
                        writings.push({
                            id: doc.id + '_' + id,
                            answer: answer,
                            // 提取文本的前30个字符作为标题
                            title: answer.substring(0, 30) + '...',
                            // 计算字数
                            wordCount: answer.split(/\s+/).filter(word => word.length > 0).length
                        });
                    }
                });
            }
        });

        return json({ writings });
    } catch (error) {
        console.error('Error fetching writings:', error);
        return json({ 
            error: 'Failed to fetch writings',
            details: error.message 
        }, { status: 500 });
    }
}
