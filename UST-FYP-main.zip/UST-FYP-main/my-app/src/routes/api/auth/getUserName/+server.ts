import { collection, getDocs , getDoc, doc} from "firebase/firestore"; 
import {db} from "$lib/firebase";
import {json} from '@sveltejs/kit';
import type { RequestHandler } from './$types';
import { error } from '@sveltejs/kit';

//let uid = 'sQogQYHZqHdiiFNsgSSdHbiQLMG2';
let firstName: string[] = [];
let lastName: string[] = [];

export const GET: RequestHandler = async ({ url }) => {
	const uid = url.searchParams.get('uid');
    const querySnapshot = await getDoc(doc(db, 'users', uid));
    const data = querySnapshot.data();
    firstName = data.firstName;
    lastName = data.lastName;
    let fullName = firstName + " " + lastName;
    return json({
        "name": fullName
    })
};