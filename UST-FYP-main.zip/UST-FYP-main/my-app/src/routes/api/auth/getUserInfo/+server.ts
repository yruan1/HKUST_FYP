import { getDoc, doc} from "firebase/firestore"; 
import {db} from "$lib/firebase";
import {json} from '@sveltejs/kit';
import type { RequestHandler } from './$types';
import { error } from '@sveltejs/kit';


export const GET: RequestHandler = async ({ url }) => {
    const uid = url.searchParams.get('uid');
    if (!uid) {
        throw error(400, 'User ID is required');
    }

    const docRef = doc(db, 'users', uid);
    const querySnapshot = await getDoc(docRef);
    if (!querySnapshot.exists()) {
        throw error(404, 'User not found');
    }

    const data = querySnapshot.data();
    return json(
        data
    )
};