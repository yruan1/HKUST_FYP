// /api/practice/+server.ts
import { json } from '@sveltejs/kit';
import { OpenAI } from 'openai';
import type { RequestEvent } from '@sveltejs/kit';

const apiKey = '997023335f664dfb99ad792a17d3e82a';
const baseURL = 'https://api.aimlapi.com/v1';

const api = new OpenAI({
    apiKey,
    baseURL,
});

export async function POST({ request }: RequestEvent) {
    try {
        const { resultId, grammarAnalysis } = await request.json();

        if (!resultId) {
            return json({
                success: false,
                error: 'Result ID is required',
                questions: JSON.stringify([])
            }, { status: 400 });
        }

        if (!grammarAnalysis || typeof grammarAnalysis !== 'string' || grammarAnalysis.trim() === '') {
            return json({ 
                success: false,
                error: 'No grammar analysis provided',
                questions: JSON.stringify([{
                    id: 'error',
                    question: 'No grammar analysis was provided. Please ensure your submission includes grammar feedback.',
                    options: ["", "", "", ""],
                    correctAnswer: 0,
                    explanation: '',
                    isPlaceholder: true
                }])
            }, { status: 400 });
        }

        console.log('Processing grammar practice questions request...');

        // Create a system prompt for generating grammar questions
        const systemPrompt = `You are an expert English grammar tutor who creates helpful, accurate practice questions.`;
        
        // Create a user prompt with the grammar analysis
        const userPrompt = `
Based on the following grammar analysis of a student's writing, generate 4 multiple-choice questions that target the specific grammar issues identified. Each question should test understanding of the grammatical concepts the student struggled with.

Grammar Analysis:
${grammarAnalysis}

For each question:
1. Create a clear, concise question that tests understanding of a specific grammar rule
2. Provide 4 possible answer choices (A, B, C, D)
3. Indicate which answer is correct (as an index from 0-3, where 0=A, 1=B, 2=C, 3=D)
4. Include a detailed explanation of why the correct answer is right and why the others are wrong

Return your response as a JSON array with the following structure:
[
  {
    "id": "q1",
    "question": "Question text",
    "options": ["Option A", "Option B", "Option C", "Option D"],
    "correctAnswer": 0,
    "explanation": "Explanation text"
  },
  // more questions...
]

Important: Ensure your response is valid JSON that can be parsed directly.`;

        // Call the OpenAI API
        const completion = await api.chat.completions.create({
            model: 'chatgpt-4o-latest',
            messages: [
                { role: 'system', content: systemPrompt },
                { role: 'user', content: userPrompt }
            ],
            temperature: 0.7,
            max_tokens: 2000,
            presence_penalty: 0.6,
            frequency_penalty: 0.3,
        });

        console.log('AI response received for grammar questions');

        const responseText = completion.choices[0]?.message?.content || '';
        
        // Parse the JSON response
        let questions;
        try {
            // Find the JSON part in the response (in case AI added extra text)
            const jsonMatch = responseText.match(/\[[\s\S]*\]/);
            if (jsonMatch) {
                questions = JSON.parse(jsonMatch[0]);
            } else {
                questions = JSON.parse(responseText);
            }
            
            // Validate the questions format
            if (!Array.isArray(questions)) {
                throw new Error('Response is not an array');
            }
            
            // Ensure each question has the required fields
            questions = questions.map((q, index) => ({
                id: q.id || `q${index + 1}`,
                question: q.question || `Question ${index + 1}`,
                options: Array.isArray(q.options) ? q.options : ["Option A", "Option B", "Option C", "Option D"],
                correctAnswer: typeof q.correctAnswer === 'number' ? q.correctAnswer : 0,
                explanation: q.explanation || `The correct answer is ${q.options?.[q.correctAnswer] || "Option A"}.`
            }));
            
        } catch (error) {
            console.error('Error parsing AI response:', error);
            console.error('Raw response:', responseText);
            
            // If parsing fails, create fallback questions
            questions = [
                {
                    id: 'fallback1',
                    question: "Which sentence is grammatically correct?",
                    options: [
                        "I have been study English for three years.",
                        "I have been studying English for three years.",
                        "I have been studied English for three years.",
                        "I have studying English for three years."
                    ],
                    correctAnswer: 1,
                    explanation: "The present perfect continuous tense requires 'have been' followed by the present participle (verb + ing). Therefore, 'I have been studying' is correct."
                },
                {
                    id: 'fallback2',
                    question: "Choose the sentence with the correct subject-verb agreement:",
                    options: [
                        "The team are playing well today.",
                        "The team is playing well today.",
                        "The team were playing well today.",
                        "The team have playing well today."
                    ],
                    correctAnswer: 1,
                    explanation: "In American English, collective nouns like 'team' are treated as singular and require singular verbs. Therefore, 'The team is playing' is correct."
                }
            ];
        }

        // Return the questions in the format expected by your frontend
        return json({ 
            success: true, 
            questions: JSON.stringify(questions)
        });
        
    } catch (error) {
        console.error('Error generating grammar questions:', error);
        return json({ 
            success: false,
            error: 'Failed to generate questions: ' + error.message,
            questions: JSON.stringify([{
                id: 'error',
                question: 'An error occurred while generating questions. Please try again.',
                options: ["", "", "", ""],
                correctAnswer: 0,
                explanation: '',
                isPlaceholder: true
            }])
        }, { status: 500 });
    }
}