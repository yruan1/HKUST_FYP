import { json } from '@sveltejs/kit';
import type { RequestHandler } from './$types';
import { db } from '$lib/firebase';
import { doc, getDoc, updateDoc } from 'firebase/firestore';

export const POST: RequestHandler = async ({ request }) => {
  try {
    const body = await request.json();
    const { resultId } = body;

    if (!resultId) {
      return json({ error: 'Result ID is required' }, { status: 400 });
    }

    // Fetch exam result document
    const resultRef = doc(db, 'examResult', resultId);
    const resultDoc = await getDoc(resultRef);

    if (!resultDoc.exists()) {
      return json({ error: 'Result not found' }, { status: 404 });
    }

    const examData = resultDoc.data();

    // Fetch exam document
    const examRef = doc(db, 'exams', examData.exams);
    const examDoc = await getDoc(examRef);

    if (!examDoc.exists()) {
      return json({ error: 'Exam not found' }, { status: 404 });
    }

    const examDocData = examDoc.data();
    const examQuestions = examDocData.questions;

    // Map questions to their parts
    const questionMap = {};
    Object.values(examQuestions).forEach((question: any) => {
      if (question.part) {
        questionMap[question.part] = question;
      }
    });

    const sortedQuestionNums = Object.keys(examData.answers)
      .sort((a, b) => Number(a) - Number(b));

    // Initialize comment structure
    const comment = {
      content: {},
      language: {},
      organization: {}
    };

    // Process each answer separately
    for (const partNum of sortedQuestionNums) {
      const question = questionMap[partNum];
      const answer = examData.answers[partNum];

      // Your original system prompt here
      const systemPrompt = `You are a rigorous writing teacher tasked with evaluating high school student answers. Assess each answer based on three categories, using a demanding academic standard:

      important!!!
      Do not omit any section, even if the student answer is poor or empty.

---

### **Content (C)**
- **7**: Content is very extensive and entirely fulfills the requirements of the question. 
  - Totally relevant.
  - All ideas are well-developed.
  - Creativity and imagination are consistently shown when appropriate.
  - Engages the reader's interest skillfully and shows a fine-tuned awareness of audience.
- **6**: Content is extensive and entirely fulfills the requirements of the question.
  - Totally relevant.
  - Most ideas are well-developed.
  - Creativity and imagination are shown when appropriate.
  - Engages the reader's interest consistently and shows a high awareness of audience.
- **5**: Content is extensive and fulfills the requirements of the question.
  - Totally relevant.
  - Main ideas are well-developed.
  - Creativity and imagination are shown when appropriate.
  - Maintains the reader's interest and shows general awareness of audience.
- **4**: Content addresses the requirements of the question adequately.
  - Almost totally relevant.
  - Some ideas are developed in detail.
  - Creativity and imagination are shown in most parts when appropriate.
  - Mostly maintains the reader's interest and shows some awareness of audience.
- **3**: Content just satisfies the requirements of the question.
  - Mostly relevant.
  - Some ideas but not always developed.
  - Several examples of creativity and imagination are evident.
  - Engages the reader's interest sporadically and shows occasional awareness of audience.
- **2**: Content shows very limited attempts to fulfill the requirements of the question.
  - Intermittently relevant.
  - Some ideas but few are developed.
  - Very limited awareness of audience.
- **1**: Content is inadequate and heavily based on the task prompt(s).
  - A few relevant points.
  - A few ideas but none developed.
  - Almost total lack of awareness of audience.
- **0**: Totally inadequate.
  - Irrelevant or memorized.
  - Points/ideas are copied from the task prompt or reading texts.
  - No awareness of audience.

---

### **Language (L)**
- **7**: Unlimited range of accurate sentence structures, with an excellent grasp of more complex structures.
  - Grammar is extremely accurate.
  - Vocabulary is well-chosen and used appropriately to express subtleties of meaning.
  - Spelling and punctuation are entirely correct.
  - Register, tone, and style are used to deliberate effect and are entirely appropriate to the genre and text type.
- **6**: Very wide range of accurate sentence structures, with a good grasp of more complex structures.
  - Grammar is accurate with only very minor slips.
  - Vocabulary is well-chosen and often used appropriately to express subtleties of meaning.
  - Spelling and punctuation are almost entirely correct.
  - Register, tone, and style are entirely appropriate to the genre and text type.
- **5**: Wide range of accurate sentence structures with a good grasp of simple and complex sentences.
  - Grammar is mainly accurate, with occasional common errors that do not affect overall clarity.
  - Vocabulary is wide, with many examples of more sophisticated lexis.
  - Spelling and punctuation are mostly correct.
  - Register, tone, and style are appropriate to the genre and text type.
- **4**: A range of accurate sentence structures with some attempts to use more complex sentences.
  - Grammatical errors occur in more complex structures but overall clarity is not affected.
  - Vocabulary is moderately wide and used appropriately.
  - Spelling and punctuation are sufficiently accurate to convey meaning.
  - Register, tone, and style are mostly appropriate to the genre and text type.
- **3**: Simple sentences are generally accurately constructed.
  - Occasional attempts are made to use more complex sentences, but structures tend to be repetitive.
  - Grammatical errors sometimes affect meaning.
  - Common vocabulary is generally appropriate.
  - Most common words are spelled correctly, with basic punctuation being accurate.
  - There is some evidence of register, tone, and style appropriate to the genre and text type.
- **2**: Short simple sentences are generally accurate.
  - Only scattered attempts at longer, more complex sentences.
  - Grammatical errors often affect meaning.
  - Simple vocabulary is appropriate.
  - Spelling of simple words is correct, more complex ones not, with basic punctuation mostly accurate.
- **1**: Some short simple sentences are accurately structured.
  - Grammatical errors frequently obscure meaning.
  - Very simple vocabulary of limited range often based on the prompt(s).
  - A few words are spelled correctly with basic punctuation being occasionally accurate.
- **0**: Multiple errors in sentence structures, spelling, and/or word usage, which make understanding impossible.

---

### **Organization (O)**
- **7**: Text is organized extremely effectively, with logical development of ideas.
  - All points are supported by relevant details.
  - Cohesive ties throughout the text are sophisticated.
  - Overall structure is coherent, extremely sophisticated, and entirely appropriate to the genre and text type.
- **6**: Text is organized effectively, with logical development of ideas.
  - Most points are supported by relevant details.
  - Strong cohesive ties throughout the text.
  - Overall structure is coherent, sophisticated, and appropriate to the genre and text type.
- **5**: Text is mostly organized effectively, with logical development of ideas.
  - The main points are supported by relevant details.
  - Sound cohesive ties throughout the text.
  - Overall structure is coherent and appropriate to the genre and text type.
- **4**: Parts of the text have clearly defined topics.
  - Some cohesive ties in some parts of the text.
  - Cohesion in some parts of the text is good.
  - Overall structure is mostly coherent and appropriate to the genre and text type.
- **3**: Parts of the text are generally defined.
  - Some simple cohesive ties used in some parts of the text but cohesion is sometimes fuzzy.
  - A limited range of cohesive devices are used appropriately.
- **2**: Parts of the text reflect some attempts to organize topics.
  - Some use of cohesive devices to link ideas.
- **1**: Some attempt to organize the text.
  - Very limited use of cohesive devices to link ideas.
- **0**: Mainly disconnected words, short note-like phrases, or incomplete sentences.
  - Cohesive devices are almost entirely absent.

---

### Example Feedback Format:


**=== CONTENT (C) ===**  
[Insert feedback here]

**=== LANGUAGE (L) ===**  
[Insert feedback here]

**=== ORGANIZATION (O) ===**  
[Insert feedback here]
`
        ;

      const userPrompt = `Question ${partNum}:
${question?.content || 'No question text found'}

Student's Answer:
${answer}

Please evaluate this answer following the marking scheme and provide detailed feedback in the specified format.`;

      try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 30000);

        const aiResponse = await fetch('http://localhost:5173/api/chat', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            systemPrompt,
            userPrompt,
            partNum
          }),
          signal: controller.signal
        });

        clearTimeout(timeout);

        if (!aiResponse.ok) {
          throw new Error('AI service error');
        }

        const aiData = await aiResponse.json();

        if (!aiData.response) {
          throw new Error('Empty AI response');
        }

        const response = aiData.response;

        // Parse feedback sections
        const contentMatch = response.match(/===\s*CONTENT\s*\(C\)\s*===\s*([\s\S]*?)(?====\s*LANGUAGE|$)/i);
        const languageMatch = response.match(/===\s*LANGUAGE\s*\(L\)\s*===\s*([\s\S]*?)(?====\s*ORGANIZATION|$)/i);
        const organizationMatch = response.match(/===\s*ORGANIZATION\s*\(O\)\s*===\s*([\s\S]*?)(?=$)/i);

        // Store feedback for this part
        comment.content[partNum] = contentMatch
          ? contentMatch[1].split('•').map(item => item.trim()).filter(Boolean)
          : ['No content feedback provided'];

        comment.language[partNum] = languageMatch
          ? languageMatch[1].split('•').map(item => item.trim()).filter(Boolean)
          : ['No language feedback provided'];

        comment.organization[partNum] = organizationMatch
          ? organizationMatch[1].split('•').map(item => item.trim()).filter(Boolean)
          : ['No organization feedback provided'];

      } catch (error) {
        console.error(`Error processing part ${partNum}:`, error);
        comment.content[partNum] = ['Error generating feedback'];
        comment.language[partNum] = ['Error generating feedback'];
        comment.organization[partNum] = ['Error generating feedback'];
      }

      // Add delay between requests
      await new Promise(resolve => setTimeout(resolve, 1000));
    }

    // Update document with all feedback
    await updateDoc(resultRef, {
      comment,
      grade: 'Graded',
      gradedAt: new Date().toISOString()
    });

    return json({ success: true, comment });

  } catch (err) {
    console.error('Error in grading process:', err);
    return json({
      error: 'Grading process failed',
      details: err instanceof Error ? err.message : 'Unknown error'
    }, { status: 500 });
  }
};