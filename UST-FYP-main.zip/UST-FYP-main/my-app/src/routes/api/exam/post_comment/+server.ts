import { json } from '@sveltejs/kit';
import type { RequestHandler } from './$types';
import { db } from '$lib/firebase';
import { doc, updateDoc } from 'firebase/firestore';

export const POST: RequestHandler = async ({ request }) => {
    try {
        const { resultId, comments } = await request.json();
        
        const resultRef = doc(db, 'examResult', resultId);
        await updateDoc(resultRef, {
            'markedComments': comments
        });

        return json({ success: true });
    } catch (error) {
        console.error('Error saving comments:', error);
        return json({ success: false, error: 'Failed to save comments' }, { status: 500 });
    }
};
