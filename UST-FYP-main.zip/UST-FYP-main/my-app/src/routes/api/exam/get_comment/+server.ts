import { json } from '@sveltejs/kit';
import type { RequestHandler } from './$types';
import { db } from '$lib/firebase';
import { doc, getDoc } from 'firebase/firestore';

export const GET: RequestHandler = async ({ url }) => {
    try {
        const resultId = url.searchParams.get('resultId');
        
        if (!resultId) {
            return json({ success: false, error: 'Result ID is required' }, { status: 400 });
        }

        const resultRef = doc(db, 'examResult', resultId);
        const resultDoc = await getDoc(resultRef);

        if (!resultDoc.exists()) {
            return json({ success: false, error: 'Result not found' }, { status: 404 });
        }

        const data = resultDoc.data();
        return json({ 
            success: true, 
            comments: data.markedComments || {} 
        });
    } catch (error) {
        console.error('Error fetching comments:', error);
        return json({ success: false, error: 'Failed to fetch comments' }, { status: 500 });
    }
};
