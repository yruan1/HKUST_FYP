import { json } from '@sveltejs/kit';
import type { RequestHandler } from './$types';
import { db } from '$lib/firebase';
import { doc, getDoc, updateDoc } from 'firebase/firestore';

export const POST: RequestHandler = async ({ request }) => {
  try {
    const body = await request.json();
    const { resultId } = body;

    if (!resultId) {
      return json({ error: 'Result ID is required' }, { status: 400 });
    }

    // Fetch exam result document
    const resultRef = doc(db, 'examResult', resultId);
    const resultDoc = await getDoc(resultRef);

    if (!resultDoc.exists()) {
      return json({ error: 'Result not found' }, { status: 404 });
    }

    const examData = resultDoc.data();

    // Fetch exam document
    const examRef = doc(db, 'exams', examData.exams);
    const examDoc = await getDoc(examRef);

    if (!examDoc.exists()) {
      return json({ error: 'Exam not found' }, { status: 404 });
    }

    const examDocData = examDoc.data();
    const examQuestions = examDocData.questions;

    // Map questions to their parts
    const questionMap = {};
    Object.values(examQuestions).forEach((question: any) => {
      if (question.part) {
        questionMap[question.part] = question;
      }
    });

    const sortedQuestionNums = Object.keys(examData.answers)
      .sort((a, b) => Number(a) - Number(b));

    // Initialize grammarAnalysis structure
    const grammarAnalysis = {};

    for (const partNum of sortedQuestionNums) {
      const answer = examData.answers[partNum];

      // Check if analysis exists for this part
      if (
        examData.comment?.grammarAnalysis?.[partNum]?.originalText === answer &&
        examData.comment?.grammarAnalysis?.[partNum]?.analysis
      ) {
        grammarAnalysis[partNum] = examData.comment.grammarAnalysis[partNum];
        continue;
      }

      const systemPrompt = `You are an expert English language teacher providing detailed grammar corrections. Follow this EXACT format:

### 1. [Grammar Issue Type]
**Original:**  
❌ "[Quote the exact text containing the error with context]"
**Corrected:**  
✅ "[Write the complete corrected text]"
**Rule:** [Brief explanation of the grammar rule]

---

Key points to follow:
1. Always use "### " followed by a number for each correction
2. For Original (❌), ALWAYS include the complete sentence or paragraph containing the error
3. When quoting the Original text, copy the EXACT text from before and after the error
4. Always format using markdown with bold (**) for section headers
5. Always separate each correction with "---"
6. Never truncate or omit parts of the original text
7. Include surrounding sentences if needed for context

Check for these common grammar issues:
- Article usage (a/an/the)
- Preposition usage
- Subject-verb agreement
- Pronoun agreement
- Parallel structure
- Word order
- Verb tense consistency
- Run-on sentences
- Fragment sentences
- Comma usage`;

      const userPrompt = `Please analyze and correct any grammar issues in the following text (Part ${partNum}):\n\n${answer}`;

      try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 30000);

        const aiResponse = await fetch('http://localhost:5173/api/chat', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            systemPrompt,
            userPrompt
          }),
          signal: controller.signal
        });

        clearTimeout(timeout);

        if (!aiResponse.ok) {
          throw new Error('AI service error');
        }

        const aiData = await aiResponse.json();

        if (!aiData.response) {
          throw new Error('Empty AI response');
        }

        // Store analysis for this part
        grammarAnalysis[partNum] = {
          originalText: answer,
          analysis: aiData.response,
          analyzedAt: new Date().toISOString()
        };

      } catch (error) {
        console.error(`Error processing part ${partNum}:`, error);
        grammarAnalysis[partNum] = {
          originalText: answer,
          analysis: 'Error generating grammar analysis',
          analyzedAt: new Date().toISOString(),
          error: error instanceof Error ? error.message : 'Unknown error'
        };
      }

      // Add delay between requests
      await new Promise(resolve => setTimeout(resolve, 1000));
    }

    // Create or update the comment object with grammar analysis
    const currentComment = examData.comment || {};
    const updatedComment = {
      ...currentComment,
      grammarAnalysis
    };

    // Update the exam result document with grammar analysis inside comment
    await updateDoc(resultRef, {
      comment: updatedComment,
      updatedAt: new Date().toISOString()
    });

    return json({
      success: true,
      grammarAnalysis,
      cached: false
    });

  } catch (err) {
    console.error('Error in grammar analysis:', err);
    return json({
      error: 'Grammar analysis failed',
      details: err instanceof Error ? err.message : 'Unknown error'
    }, { status: 500 });
  }
};