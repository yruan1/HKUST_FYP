import { json } from '@sveltejs/kit';
import type { RequestHandler } from './$types';

export const POST: RequestHandler = async ({ request }) => {
    try {
        const body = await request.json();
        const { question, answer } = body;

        if (!question || !answer) {
            return json({ error: 'Question and answer are required' }, { status: 400 });
        }

        const systemPrompt = `You are an expert English language teacher providing detailed grammar corrections. Follow this EXACT format:

### 1. [Grammar Issue Type]
**Original:**  
❌ "[Quote the exact text containing the error with context]"
**Corrected:**  
✅ "[Write the complete corrected text]"
**Rule:** [Brief explanation of the grammar rule]

---

Key points to follow:
1. Always use "### " followed by a number for each correction
2. For Original (❌), ALWAYS include the complete sentence or paragraph containing the error
3. When quoting the Original text, copy the EXACT text from before and after the error
4. Always format using markdown with bold (**) for section headers
5. Always separate each correction with "---"
6. Never truncate or omit parts of the original text
7. Include surrounding sentences if needed for context

Check for these common grammar issues:
- Article usage (a/an/the)
- Preposition usage
- Subject-verb agreement
- Pronoun agreement
- Parallel structure
- Word order
- Verb tense consistency
- Run-on sentences
- Fragment sentences
- Comma usage`;


        const userPrompt = `Please analyze and correct any grammar issues in the following student's answer:

Question: ${question}

Student's Answer:
${answer}`;

        try {
            const controller = new AbortController();
            const timeout = setTimeout(() => controller.abort(), 30000);

            const aiResponse = await fetch('http://localhost:5173/api/chat', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    systemPrompt,
                    userPrompt
                }),
                signal: controller.signal
            });

            clearTimeout(timeout);

            if (!aiResponse.ok) {
                throw new Error('AI service error');
            }

            const aiData = await aiResponse.json();

            if (!aiData.response) {
                throw new Error('Empty AI response');
            }

            return json({
                success: true,
                analysis: {
                    originalText: answer,
                    analysis: aiData.response,
                    analyzedAt: new Date().toISOString()
                }
            });

        } catch (error) {
            console.error('Error in AI processing:', error);
            return json({
                error: 'AI processing failed',
                details: error instanceof Error ? error.message : 'Unknown error'
            }, { status: 500 });
        }

    } catch (err) {
        console.error('Error in grammar analysis:', err);
        return json({
            error: 'Grammar analysis failed',
            details: err instanceof Error ? err.message : 'Unknown error'
        }, { status: 500 });
    }
};