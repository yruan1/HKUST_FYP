// /api/chat/+server.ts
import { json } from '@sveltejs/kit';
import { OpenAI } from 'openai';
import type { RequestEvent } from '@sveltejs/kit';

const apiKey = '997023335f664dfb99ad792a17d3e82a';
const baseURL = 'https://api.aimlapi.com/v1';

const api = new OpenAI({
    apiKey,
    baseURL,
}); 

export async function POST({ request }: RequestEvent) {
    try {
        const { systemPrompt, userPrompt } = await request.json();

        console.log('Processing AI request...');

        const completion = await api.chat.completions.create({
            model: 'chatgpt-4o-latest',
            messages: [
                { role: 'system', content: systemPrompt },
                { role: 'user', content: userPrompt }
            ],
            temperature: 0.7,
            max_tokens: 10000,
            presence_penalty: 0.6,
            frequency_penalty: 0.3,
        });

        console.log('AI response received');

        return json({
            response: completion.choices[0]?.message?.content ?? 'No response received.',
        });
    } catch (error) {
        console.error('Error in chat API:', error);
        return json({ 
            error: 'AI service error',
            details: error.message 
        }, { status: 500 });
    }
}