<script lang="ts">
	import ChatBotWidget from '$lib/components/ChatBotWidget.svelte';
	import SearchHeader from '$lib/components/SearchHeader.svelte';
	import AnnouncementCard from '$lib/components/AnnouncementCardT.svelte';
	import { onMount } from 'svelte';
	import { db } from '$lib/firebase'; // Import Firestore
	import { collection, doc, updateDoc, setDoc, addDoc, serverTimestamp } from 'firebase/firestore';
	import firebase from 'firebase/compat/app';
	export let data;
</script>

<main>
	<ChatBotWidget></ChatBotWidget>
	
</main>
