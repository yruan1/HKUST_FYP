<script lang="ts">
	import ChartCard from '$lib/components/ChartCard.svelte';
	import CircleChart from '$lib/components/CircleChart.svelte';
</script>

<main>
	<div>
		<ChartCard></ChartCard>
	</div>
	<div>
		<ChartCard></ChartCard>
	</div>
	<div>
		<ChartCard value={20}></ChartCard>
	</div>
</main>

<style lang="scss">
</style>
