<script lang="ts">
	import SearchHeader from '$lib/components/SearchHeader.svelte';
	import SemesmterCard from '$lib/components/SemesmterCard.svelte';
	import SubheadingBar from '$lib/components/SubheadingBar.svelte';
	import TaskList from '$lib/components/TaskList.svelte';
	import UnderscoreDiv from '$lib/components/UnderscoreDiv.svelte';
	import type { Task } from '$lib/type';
	//TODO: get data from DB
	//TODO: implementation of type:Task
	interface Sememster {
		year: string;
		btnValue1?: string;
		btnValue2?: string;
	}

	let tasks: Task[] = [
		{
			title: 'Mock Exam 1',
			dueDate: '14:33PM'
		},
		{
			title: 'Mock Exam 2',
			dueDate: '14:33PM'
		},
		{
			title: 'Mock Exam 3',
			dueDate: '14:33PM'
		},
		{
			title: 'Mock Exam 2',
			dueDate: '14:33PM'
		},
		{
			title: 'Mock Exam 3',
			dueDate: '14:33PM'
		},
		{
			title: 'Mock Exam 2',
			dueDate: '14:33PM'
		},
		{
			title: 'Mock Exam 3',
			dueDate: '14:33PM'
		},
		{
			title: 'Mock Exam 2',
			dueDate: '14:33PM'
		},
		{
			title: 'Mock Exam 3',
			dueDate: '14:33PM'
		}
	];
	let Sememsters: Sememster[] = [
		{
			year: ' 2020'
		},
		{
			year: '2021'
		},
		{
			year: '2022'
		}
	];
</script>

<main>
	
	<div class="container">
		<UnderscoreDiv>
			<SubheadingBar title={'Exam'}></SubheadingBar>
		</UnderscoreDiv>

		<UnderscoreDiv>
			<div class="sem-card">
				{#each Sememsters as sem}
					<SemesmterCard year={sem.year} />
				{/each}
			</div>
		</UnderscoreDiv>
		<UnderscoreDiv>
			<SubheadingBar title={'Recommendation'} checkShow={false}></SubheadingBar>
			<TaskList {tasks}></TaskList>
		</UnderscoreDiv>
	</div>
</main>

<style lang="scss">
	main {
		position: relative;
		height: 100%;
		width: 100%;
		background-color: var(--clr-content-background);
	}
	.container {
		padding: 10px 40px;
	}
	.sem-card {
		display: grid;
		grid-template-columns: 33.333% 33.333% 33.333%;
		row-gap: 25px;
		padding: 25px;
		justify-items: center;
	}
</style>
