<script lang="ts">
	import Button from '$lib/components/Button.svelte';
	import ResultCard from '$lib/components/Result/ResultCard.svelte';
	import ResultTag from '$lib/components/Result/ResultTagBar.svelte';
	import ScrollRowBar from '$lib/components/Result/ScrollRowBar.svelte';

	let currentRowbarIndex: number;
	let currentNavTagIndex: number;
	let systemAnswer: HTMLDivElement;

	$: if (systemAnswer) {
		switch (currentRowbarIndex) {
			case 0:
				systemAnswer.innerHTML = 'Correct';
				break;
			case 1:
				systemAnswer.innerHTML = 'Model Answer';
				break;
			case 2:
				systemAnswer.innerHTML = '3';
				break;
		}
	}
	let questionNumber: HTMLHeadingElement;
	let taskTitile: HTMLHeadingElement;
	let taskContent: HTMLHeadingElement;
	$: if (questionNumber && taskTitile && taskContent) {
		switch (currentNavTagIndex) {
			case 0:
				questionNumber.innerHTML = 'Q1';
				break;
			case 1:
				questionNumber.innerHTML = 'Q2';
				break;
			case 2:
				questionNumber.innerHTML = 'Q3';
				break;
		}
	}
</script>

<div class="container">
	<div class="nav"><ResultTag bind:currentTagIndex={currentNavTagIndex}></ResultTag></div>
	<div class="header">
		<div class="question">
			<div>
				<div class="question-number"><h1 bind:this={questionNumber}>Q1</h1></div>
				<h2 bind:this={taskTitile}>Task 1 - Bar Chart</h2>
			</div>
			<h2 bind:this={taskContent}>
				The bar chart below gives information about the sales of electric cars in China, Europe, and
				the United States between 2016 and 2023.
			</h2>
			<!-- <Button>Show Image</Button> -->
		</div>
		<div class="summery">
			<div class="card-container">
				<ResultCard value="0.0" unit="/9.0" description="description"></ResultCard>
				<ResultCard value="0.0" unit="/9.0" description="description"></ResultCard>
			</div>
			<div>
				<ScrollRowBar bind:RowBarIndex={currentRowbarIndex}></ScrollRowBar>
			</div>
		</div>
	</div>
	<div class="answer">
		<div class="user-answer"></div>
		<div class="system-answer" bind:this={systemAnswer}></div>
	</div>
</div>

<style lang="scss">
	.container {
		display: flex;
		flex-direction: column;
		height: 100%;
		width: 100%;
		padding: 20px 20px;
		background-color: var(--clr-content-result-background);
		gap: 5px;
		--header-height: 18%;
		--nav-height: 5%;
	}
	h2 {
		overflow: hidden;
	}
	.nav {
		display: flex;
		align-items: center;
		height: var(--nav-height);
		min-height: var(--nav-height);
		background-color: var(--clr-content-background);
		padding: 0px 12px;
	}
	.header {
		display: flex;
		height: var(--header-height);
		width: 100%;
		gap: 5px;
		min-height: 160px;
		> div {
			height: 100%;
			width: 50%;
			background-color: var(--clr-content-background);
		}
	}
	.question {
		padding: 18px;
		> div {
			display: flex;
			align-items: center;
			height: 25%;
			> .question-number {
				position: relative;
				--margin-right: 20px;
				margin-right: var(--margin-right);
				> h1 {
					font-size: 24px;
					&::after {
						position: absolute;
						content: '';
						width: 2px;
						height: 100%;
						top: 0;
						right: calc(var(--margin-right) * -1);
						background-color: #5b5c61;
						opacity: 0.3;
					}
				}
			}
			> h2 {
				color: #5b5c61;
				font-size: 18px;
				font-weight: 400;
				margin-left: 20px;
			}
		}
		> h2 {
			overflow-y: scroll;
			word-wrap: normal;
			white-space: normal;
			font-size: 18px;
			font-weight: 400;
			height: 50%;
			line-height: 32px;
		}
		> :global(button) {
			height: 25%;
			margin-top: 14px;
		}
	}
	.summery {
		display: flex;
		flex-direction: column;
		justify-content: space-between;
	}
	.card-container {
		display: flex;
		flex-direction: row;
		justify-content: space-between;
		gap: 10px;
		padding: 5px 24px 5px 24px;
	}
	.answer {
		display: flex;
		width: 100%;
		gap: 5px;
		height: calc(100% - var(--header-height) - var(--nav-height));
		> div {
			height: 100%;
			width: 50%;
			background-color: var(--clr-content-background);
		}
	}
</style>
