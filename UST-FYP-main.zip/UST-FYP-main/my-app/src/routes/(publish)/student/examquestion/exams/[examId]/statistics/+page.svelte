<script lang="ts">
	import { page } from '$app/stores';
	import { onMount } from 'svelte';
	import { db } from '$lib/firebase';
	import { collection, getDocs, query, where } from 'firebase/firestore';
	import ExamNavigation from '$lib/components/Exam/ExamNavigation.svelte';
	import Chart from 'chart.js/auto';
	import { getCurrentUserIdFromCookie } from '$lib/utils/auth';
	// Get examId from URL path dynamically
	$: examId = $page.url.pathname.split('/')[4];

	interface ExamResult {
		exams: string;
		comment?: {
			content?: {
				[key: string]: string[]; // "1", "2" etc with array of feedback
			};
			language?: {
				[key: string]: string[];
			};
			organization?: {
				[key: string]: string[];
			};
		};
	}

	interface Scores {
		content: number[];
		language: number[];
		organization: number[];
	}

	interface ScoresByPart {
		[key: string]: Scores;
	}

	let scores: Scores = {
		content: [],
		language: [],
		organization: []
	};

	let partScores: ScoresByPart = {};
	let activeTab = '1';
	let availableParts: string[] = [];

	// Chart instance variables
	let contentChart: Chart | null = null;
	let languageChart: Chart | null = null;
	let organizationChart: Chart | null = null;
	let overallChart: Chart | null = null;

	let loading = true;
	let error = null;

	// Reactive statement to fetch results when examId changes
	$: {
		if (examId) {
			fetchExamResults();
		}
	}


	async function fetchExamResults() {
		try {
			loading = true;
			partScores = {};
			availableParts = [];
			cleanupCharts();

			const examResultsRef = collection(db, 'examResult');
			const q = query(examResultsRef, where('exams', '==', examId));
			const querySnapshot = await getDocs(q);

			querySnapshot.forEach((doc) => {
				const data = doc.data() as ExamResult;

				if (data.comment) {
					// Process content scores
					if (data.comment.content) {
						Object.entries(data.comment.content).forEach(([key, feedbackArray]) => {
							if (feedbackArray && feedbackArray.length > 0) {
								const score = extractScore(feedbackArray[0]);
								if (score !== null) {
									if (!partScores[key]) {
										partScores[key] = {
											content: [],
											language: [],
											organization: []
										};
									}
									partScores[key].content.push(score);
								}
							}
						});
					}

					// Process language scores
					if (data.comment.language) {
						Object.entries(data.comment.language).forEach(([key, feedbackArray]) => {
							if (feedbackArray && feedbackArray.length > 0) {
								const score = extractScore(feedbackArray[0]);
								if (score !== null) {
									if (!partScores[key]) {
										partScores[key] = {
											content: [],
											language: [],
											organization: []
										};
									}
									partScores[key].language.push(score);
								}
							}
						});
					}

					// Process organization scores
					if (data.comment.organization) {
						Object.entries(data.comment.organization).forEach(([key, feedbackArray]) => {
							if (feedbackArray && feedbackArray.length > 0) {
								const score = extractScore(feedbackArray[0]);
								if (score !== null) {
									if (!partScores[key]) {
										partScores[key] = {
											content: [],
											language: [],
											organization: []
										};
									}
									partScores[key].organization.push(score);
								}
							}
						});
					}
				}
			});

			// Update available parts and sort them numerically
			availableParts = Array.from(Object.keys(partScores)).sort((a, b) => Number(a) - Number(b));

			if (availableParts.length > 0) {
				activeTab = availableParts[0];
				scores = partScores[activeTab] || {
					content: [],
					language: [],
					organization: []
				};
			}
		} catch (err) {
			console.error('Error fetching exam results:', err);
			error = 'Error fetching exam results';
		} finally {
			loading = false;
		}
	}

	function extractScore(text: string): number | null {
		if (!text) return null;

		const patterns = [
			/Score:\s*\*\*(\d+)\/7\*\*/, // Matches "Score: **2/7**"
			/\*\*(\d+)\/7\*\*/, // Matches "**2/7**"
			/Score:\s*(\d+)/i, // Matches "Score: 2"
			/(\d+)\/7/, // Matches "2/7"
			/Score:\s*\*\*(\d+)\*\*/, // Added pattern to match "Score: **4**"
			/\*\*(\d+)\*\*/ // Added pattern to match "**4**"
		];

		for (const pattern of patterns) {
			const match = text.match(pattern);
			if (match && match[1]) {
				const score = parseInt(match[1]);
				if (score >= 0 && score <= 7) {
					return score;
				}
			}
		}
		return null;
	}

	function calculateMetrics(scores: number[]) {
		if (scores.length === 0) return { average: 0, max: 0, min: 0, distribution: {} };

		const metrics = {
			average: scores.reduce((a, b) => a + b, 0) / scores.length,
			max: Math.max(...scores),
			min: Math.min(...scores),
			distribution: {}
		};

		scores.forEach((score) => {
			metrics.distribution[score] = (metrics.distribution[score] || 0) + 1;
		});

		return metrics;
	}

	function calculateOverallScores(activePartScores) {
		const totalScores = [];
		if (!activePartScores.content || !activePartScores.language || !activePartScores.organization)
			return [];

		// Get the length of scores array (assuming all arrays have same length)
		const length = Math.max(
			activePartScores.content.length,
			activePartScores.language.length,
			activePartScores.organization.length
		);

		for (let i = 0; i < length; i++) {
			const contentScore = activePartScores.content[i] || 0;
			const languageScore = activePartScores.language[i] || 0;
			const organizationScore = activePartScores.organization[i] || 0;
			const total = contentScore + languageScore + organizationScore;
			totalScores.push(total);
		}
		return totalScores;
	}

	function createChart(canvas: HTMLCanvasElement, scores: number[], label: string, color: string) {
		const existingChart = Chart.getChart(canvas);
		if (existingChart) {
			existingChart.destroy();
		}

		const distribution = calculateMetrics(scores).distribution;
		const labels = Array.from({ length: 8 }, (_, i) => `Score ${i}`);
		const data = labels.map((label) => {
			const score = parseInt(label.split(' ')[1]);
			return distribution[score] || 0;
		});

		return new Chart(canvas, {
			type: 'bar',
			data: {
				labels: labels,
				datasets: [
					{
						label: `${label} (Number of Students)`,
						data: data,
						backgroundColor: color,
						borderColor: color,
						borderWidth: 1
					}
				]
			},
			options: {
				responsive: true,
				maintainAspectRatio: false,
				scales: {
					y: {
						beginAtZero: true,
						title: {
							display: true,
							text: 'Number of Students'
						},
						ticks: {
							stepSize: 1,
							callback: function (value) {
								return Math.floor(value);
							}
						}
					},
					x: {
						grid: {
							display: false
						}
					}
				},
				plugins: {
					tooltip: {
						callbacks: {
							label: function (context) {
								return `${context.dataset.label}: ${context.raw} student(s)`;
							}
						}
					}
				}
			}
		});
	}

	function createOverallChart(canvas: HTMLCanvasElement, scores: number[]) {
		const existingChart = Chart.getChart(canvas);
		if (existingChart) {
			existingChart.destroy();
		}

		const distribution = {};
		scores.forEach((score) => {
			distribution[score] = (distribution[score] || 0) + 1;
		});

		const labels = Array.from({ length: 22 }, (_, i) => `${i}/21`);
		const data = labels.map((label) => {
			const score = parseInt(label.split('/')[0]);
			return distribution[score] || 0;
		});

		return new Chart(canvas, {
			type: 'bar',
			data: {
				labels: labels,
				datasets: [
					{
						label: 'Total Scores (Number of Students)',
						data: data,
						backgroundColor: '#4CAF50',
						borderColor: '#4CAF50',
						borderWidth: 1
					}
				]
			},
			options: {
				responsive: true,
				maintainAspectRatio: false,
				scales: {
					y: {
						beginAtZero: true,
						title: {
							display: true,
							text: 'Number of Students'
						},
						ticks: {
							stepSize: 1,
							callback: function (value) {
								return Math.floor(value);
							}
						}
					},
					x: {
						grid: {
							display: false
						},
						title: {
							display: true,
							text: 'Total Score (out of 21)'
						}
					}
				},
				plugins: {
					title: {
						display: true,
						text: 'Overall Score Distribution (out of 21)',
						font: {
							size: 16
						}
					},
					tooltip: {
						callbacks: {
							label: function (context) {
								return `${context.dataset.label}: ${context.raw} student(s)`;
							}
						}
					}
				}
			}
		});
	}

	function cleanupCharts() {
		if (contentChart) contentChart.destroy();
		if (languageChart) languageChart.destroy();
		if (organizationChart) organizationChart.destroy();
		if (overallChart) overallChart.destroy();
	}

	onMount(() => {
		return () => {
			cleanupCharts();
		};
	});

	$: if (!loading && !error) {
		setTimeout(() => {
			const contentCanvas = document.getElementById('contentChart') as HTMLCanvasElement;
			const languageCanvas = document.getElementById('languageChart') as HTMLCanvasElement;
			const organizationCanvas = document.getElementById('organizationChart') as HTMLCanvasElement;
			const overallCanvas = document.getElementById('overallChart') as HTMLCanvasElement;

			if (contentCanvas) {
				contentChart = createChart(contentCanvas, scores.content, 'Content Scores', '#66BB6A');
			}
			if (languageCanvas) {
				languageChart = createChart(languageCanvas, scores.language, 'Language Scores', '#66BB6A');
			}
			if (organizationCanvas) {
				organizationChart = createChart(
					organizationCanvas,
					scores.organization,
					'Organization Scores',
					'#66BB6A'
				);
			}
			if (overallCanvas) {
				// Pass the current part's scores
				const overallScores = calculateOverallScores(scores);
				overallChart = createOverallChart(overallCanvas, overallScores);
			}
		}, 0);
	}
</script>

<ExamNavigation>
	<div class="statistics-container">
		<h2 class="title">Exam Results Statistics</h2>

		{#if loading}
			<div class="loading">Loading statistics...</div>
		{:else if error}
			<div class="error">{error}</div>
		{:else}
			<div class="parts-navigation">
				{#each availableParts as part}
					<button
						class="part-button {activeTab === part ? 'active' : ''}"
						on:click={() => {
							activeTab = part;
							scores = partScores[part];
							cleanupCharts(); // This will trigger the reactive statement above
						}}
					>
						Part {part}
					</button>
				{/each}
			</div>

			<div class="stats-grid">
				<!-- Content Scores -->
				<!-- Content Scores -->
				<div class="stat-card">
					<h3>Content Scores</h3>
					<div class="stat-details">
						<div class="stat-item">
							<span class="label">Average:</span>
							<span class="value">{calculateMetrics(scores.content).average.toFixed(2)}</span>
						</div>
						<div class="stat-item">
							<span class="label">Highest:</span>
							<span class="value">{calculateMetrics(scores.content).max}</span>
						</div>
						<div class="stat-item">
							<span class="label">Lowest:</span>
							<span class="value">{calculateMetrics(scores.content).min}</span>
						</div>
						<div class="stat-item">
							<span class="label">Total Submissions:</span>
							<span class="value">{scores.content.length}</span>
						</div>
						<div class="score-distribution">
							<h4>Score Distribution</h4>
							{#each Object.entries(calculateMetrics(scores.content).distribution) as [score, count]}
								<div class="distribution-item">
									<span>Score {score}:</span>
									<span>{count} submissions</span>
								</div>
							{/each}
						</div>
						<div class="chart-container">
							<canvas id="contentChart"></canvas>
						</div>
					</div>
				</div>

				<!-- Language Scores -->
				<div class="stat-card">
					<h3>Language Scores</h3>
					<div class="stat-details">
						<div class="stat-item">
							<span class="label">Average:</span>
							<span class="value">{calculateMetrics(scores.language).average.toFixed(2)}</span>
						</div>
						<div class="stat-item">
							<span class="label">Highest:</span>
							<span class="value">{calculateMetrics(scores.language).max}</span>
						</div>
						<div class="stat-item">
							<span class="label">Lowest:</span>
							<span class="value">{calculateMetrics(scores.language).min}</span>
						</div>
						<div class="stat-item">
							<span class="label">Total Submissions:</span>
							<span class="value">{scores.language.length}</span>
						</div>
						<div class="score-distribution">
							<h4>Score Distribution</h4>
							{#each Object.entries(calculateMetrics(scores.language).distribution) as [score, count]}
								<div class="distribution-item">
									<span>Score {score}:</span>
									<span>{count} submissions</span>
								</div>
							{/each}
						</div>
						<div class="chart-container">
							<canvas id="languageChart"></canvas>
						</div>
					</div>
				</div>

				<!-- Organization Scores -->
				<div class="stat-card">
					<h3>Organization Scores</h3>
					<div class="stat-details">
						<div class="stat-item">
							<span class="label">Average:</span>
							<span class="value">{calculateMetrics(scores.organization).average.toFixed(2)}</span>
						</div>
						<div class="stat-item">
							<span class="label">Highest:</span>
							<span class="value">{calculateMetrics(scores.organization).max}</span>
						</div>
						<div class="stat-item">
							<span class="label">Lowest:</span>
							<span class="value">{calculateMetrics(scores.organization).min}</span>
						</div>
						<div class="stat-item">
							<span class="label">Total Submissions:</span>
							<span class="value">{scores.organization.length}</span>
						</div>
						<div class="score-distribution">
							<h4>Score Distribution</h4>
							{#each Object.entries(calculateMetrics(scores.organization).distribution) as [score, count]}
								<div class="distribution-item">
									<span>Score {score}:</span>
									<span>{count} submissions</span>
								</div>
							{/each}
						</div>
						<div class="chart-container">
							<canvas id="organizationChart"></canvas>
						</div>
					</div>
				</div>
			</div>

			<!-- Overall Scores -->
			<!-- Overall Scores -->
			<div class="overall-stats-container">
				<div class="stat-card">
					<h3>Overall Scores Distribution (out of 21)</h3>
					<div class="stat-details">
						<div class="stat-summary">
							<div class="stat-item">
								<span class="label">Average Overall Score:</span>
								<span class="value">
									{(
										calculateOverallScores(scores).reduce((a, b) => a + b, 0) /
											calculateOverallScores(scores).length || 0
									).toFixed(2)}/21
								</span>
							</div>
							<div class="stat-item">
								<span class="label">Highest Overall Score:</span>
								<span class="value">
									{calculateOverallScores(scores).length
										? Math.max(...calculateOverallScores(scores))
										: 0}/21
								</span>
							</div>
							<div class="stat-item">
								<span class="label">Lowest Overall Score:</span>
								<span class="value">
									{calculateOverallScores(scores).length
										? Math.min(...calculateOverallScores(scores))
										: 0}/21
								</span>
							</div>
						</div>
						<div class="score-distribution">
							<h4>Score Distribution</h4>
							{#each Object.entries(calculateMetrics(calculateOverallScores(scores)).distribution) as [score, count]}
								<div class="distribution-item">
									<span>Score {score}/21:</span>
									<span>{count} submissions</span>
								</div>
							{/each}
						</div>
						<div class="chart-container">
							<canvas id="overallChart"></canvas>
						</div>
					</div>
				</div>
			</div>
		{/if}
	</div>
</ExamNavigation>

<style lang="scss">
	.statistics-container {
		padding: 2rem;
		max-width: 1200px;
		margin: 0 auto;
	}

	.title {
		font-size: 1.5rem;
		font-weight: 600;
		color: #333;
		margin-bottom: 2rem;
	}

	.parts-navigation {
		display: flex;
		gap: 0.5rem;
		margin-bottom: 2rem;
		flex-wrap: wrap;
	}

	.part-button {
		padding: 0.5rem 1.5rem;
		border: none;
		border-radius: 0.375rem;
		background-color: #f3f4f6;
		cursor: pointer;
		transition: all 0.2s;
		font-weight: 500;
		color: #4b5563;

		&:hover {
			background-color: #e5e7eb;
		}

		&.active {
			background-color: #2563eb;
			color: white;
		}
	}

	.loading {
		text-align: center;
		color: #666;
		padding: 2rem;
	}

	.error {
		color: #dc2626;
		text-align: center;
		padding: 2rem;
	}

	.stats-grid {
		display: grid;
		grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
		gap: 1.5rem;
		margin-bottom: 2rem;
	}

	.stat-card {
		background: white;
		border-radius: 8px;
		padding: 1.5rem;
		box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);

		h3 {
			color: #1a1a1a;
			font-size: 1.25rem;
			margin-bottom: 1rem;
			padding-bottom: 0.5rem;
			border-bottom: 1px solid #e5e5e5;
		}
	}

	.stat-details {
		display: flex;
		flex-direction: column;
		gap: 0.75rem;
	}

	.stat-item {
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding: 0.5rem 0;

		.label {
			color: #666;
		}

		.value {
			font-weight: 600;
			color: #1a1a1a;
		}
	}

	.score-distribution {
		margin-top: 1rem;
		padding-top: 1rem;
		border-top: 1px solid #e5e5e5;

		h4 {
			font-size: 1rem;
			color: #666;
			margin-bottom: 0.5rem;
		}
	}

	.distribution-item {
		display: flex;
		justify-content: space-between;
		padding: 0.25rem 0;
		color: #666;
	}

	.chart-container {
		margin-top: 1rem;
		padding-top: 1rem;
		border-top: 1px solid #e5e5e5;
		height: 300px;
		width: 100%;
		position: relative;
	}

	.overall-stats-container {
		margin-top: 2rem;
	}

	.stat-summary {
		margin-bottom: 1rem;
		padding: 1rem;
		background-color: #f9fafb;
		border-radius: 0.5rem;
	}

	@media (max-width: 768px) {
		.statistics-container {
			padding: 1rem;
		}

		.stats-grid {
			grid-template-columns: 1fr;
		}

		.overall-stats-container {
			margin-top: 1rem;
		}
	}
</style>
