<script lang="ts">
	import SearchHeader from '$lib/components/SearchHeader.svelte';
	import SubheadingBar from '$lib/components/SubheadingBar.svelte';
	import UnderscoreDiv from '$lib/components/UnderscoreDiv.svelte';
	import ExamNavigation from '$lib/components/Exam/ExamNavigation.svelte';
	import { onMount, onDestroy } from 'svelte';
	import { db } from '$lib/firebase';
	import { collection, onSnapshot } from 'firebase/firestore';
	import { goto } from '$app/navigation';
    import { getCurrentUserIdFromCookie } from '$lib/utils/auth';
	interface Question {
		content: string;
		part: number;
		
	}

	interface Exam {
		id: string;
		createdAt: string;
		questions: Question[];
		year: number;
		title: string;  // Add this line
	}

	let exams: Exam[] = [];
	let loading = true;
	let userId: string | null = null;
	let unsubscribe: () => void;



	function setupRealtimeExams() {
    const examCollection = collection(db, 'exams');

    unsubscribe = onSnapshot(
        examCollection,
        (snapshot) => {
            exams = snapshot.docs.map((doc) => {
                const data = doc.data();
                return {
                    id: doc.id,
                    createdAt: data.createdAt,
                    questions: data.questions || [],
                    year: data.year,
                    title: data.title || 'Untitled Question'  // Add this line
                };
            });

            exams.sort((a, b) => b.year - a.year);
            loading = false;
        },
        (error) => {
            console.error('Error fetching exams:', error);
            loading = false;
        }
    );
}

	async function handleExamClick(examId: string) {
		if (!userId) {
			console.error('No user ID found in cookie');
			return;
		}
		goto(`/student/examquestion/exams/${examId}`);
	}

	onMount(() => {
		userId = getCurrentUserIdFromCookie();
		if (!userId) {
			console.error('No user ID found in cookie');
			return;
		}
		setupRealtimeExams();
	});

	onDestroy(() => {
		if (unsubscribe) {
			unsubscribe();
		}
	});
</script>

<main>
 
    <div class="container">
        <UnderscoreDiv>
            <SubheadingBar title={'Exam'} />
        </UnderscoreDiv>

        <UnderscoreDiv>
            <div class="exam-grid">
                {#if loading}
                    <div class="loading-skeleton">
                        {#each Array(6) as _}
                            <div class="skeleton-card">
                                <div class="skeleton-icon"></div>
                                <div class="skeleton-year"></div>
                                <div class="skeleton-title"></div>
                                <div class="skeleton-subtitle"></div>
                            </div>
                        {/each}
                    </div>
                {:else}
                    {#each exams as exam}
                        <div 
                            class="exam-card" 
                            on:click={() => handleExamClick(exam.id)}
                            on:keydown={(e) => e.key === 'Enter' && handleExamClick(exam.id)}
                            role="button"
                            tabindex="0"
                        >
                            <div class="card-content">
                                <div class="exam-badge">{exam.year}</div>
                                <div class="book-icon">
                                    <span class="book book-1"></span>
                                    <span class="book book-2"></span>
                                    <span class="book-shadow"></span>
                                </div>
                                <div class="text-content">
                                    <h3 class="card-title">HKDSE English Language Paper 2</h3>
                                    <p class="question-title">{exam.title || 'Untitled Question'}</p>
                                </div>
                                <div class="card-footer">
                                    <span class="view-details">View Details →</span>
                                </div>
                            </div>
                        </div>
                    {/each}
                {/if}
            </div>
        </UnderscoreDiv>
    </div>
</main>

<style lang="scss">
    main {
        position: relative;
        height: 100%;
        width: 100%;
        background-color: var(--clr-content-background);
    }

    .container {
        padding: 1.25rem 2.5rem;
        max-width: 1440px;
        margin: 0 auto;
    }

    .exam-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 2rem;
        padding: 2rem;
    }

    .exam-card {
        background: linear-gradient(135deg, #e9b8d4 0%, #93c5fd 100%);
        border-radius: 1.25rem;
        padding: 2rem;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        cursor: pointer;
        position: relative;
        overflow: hidden;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);

        &::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(
                rgba(255, 255, 255, 0.1),
                rgba(255, 255, 255, 0.05)
            );
            opacity: 0;
            transition: opacity 0.3s ease;
        }

        &:hover {
            transform: translateY(-8px);
            box-shadow: 0 12px 20px rgba(0, 0, 0, 0.15);

            &::before {
                opacity: 1;
            }

            .book-shadow {
                transform: translateY(5px) scaleX(1.1);
                opacity: 0.3;
            }

            .view-details {
                transform: translateX(5px);
            }
        }

        &:focus {
            outline: none;
            box-shadow: 0 0 0 3px rgba(147, 197, 253, 0.5);
        }
    }

    .card-content {
        position: relative;
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 1.5rem;
    }

    .exam-badge {
        position: absolute;
        top: -1rem;
        right: -1rem;
        background: rgba(255, 255, 255, 0.9);
        color: #93c5fd;
        padding: 0.5rem 1rem;
        border-radius: 999px;
        font-weight: 600;
        font-size: 0.875rem;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }

    .book-icon {
        position: relative;
        width: 80px;
        height: 80px;
        margin: 0.5rem 0;
    }

    .book {
        position: absolute;
        background: white;
        border-radius: 4px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        transition: all 0.3s ease;

        &.book-1 {
            width: 50px;
            height: 65px;
            transform: rotate(-15deg);
            left: 5px;
            bottom: 0;
            z-index: 2;
        }

        &.book-2 {
            width: 50px;
            height: 65px;
            transform: rotate(15deg);
            right: 5px;
            bottom: 0;
            z-index: 1;
        }
    }

    .book-shadow {
        position: absolute;
        bottom: -10px;
        left: 50%;
        transform: translateX(-50%);
        width: 70px;
        height: 10px;
        background: rgba(0, 0, 0, 0.2);
        border-radius: 50%;
        filter: blur(4px);
        transition: all 0.3s ease;
    }

    .text-content {
        text-align: center;
    }

    .card-title {
        font-size: 1.25rem;
        font-weight: 700;
        color: white;
        margin-bottom: 0.75rem;
        text-shadow: 0 1px 2px rgba(0, 0, 0, 0.1);
    }

    .question-title {
        color: rgba(255, 255, 255, 0.9);
        font-size: 1rem;
        font-weight: 500;
        line-height: 1.5;
        overflow: hidden;
        text-overflow: ellipsis;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        max-width: 100%;
    }

    .card-footer {
        margin-top: auto;
        width: 100%;
        text-align: right;
    }

    .view-details {
        color: rgba(255, 255, 255, 0.9);
        font-size: 0.875rem;
        font-weight: 500;
        transition: transform 0.3s ease;
        display: inline-block;
    }

    .loading-skeleton {
        display: contents;

        .skeleton-card {
            background: #f3f4f6;
            border-radius: 1.25rem;
            padding: 2rem;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 1.5rem;
        }

        .skeleton-icon {
            width: 80px;
            height: 80px;
            background: linear-gradient(110deg, #ececec 8%, #f5f5f5 18%, #ececec 33%);
            border-radius: 8px;
            background-size: 200% 100%;
            animation: shimmer 1.5s linear infinite;
        }

        .skeleton-year {
            width: 60px;
            height: 24px;
            background: linear-gradient(110deg, #ececec 8%, #f5f5f5 18%, #ececec 33%);
            border-radius: 999px;
            background-size: 200% 100%;
            animation: shimmer 1.5s linear infinite;
        }

        .skeleton-title {
            width: 80%;
            height: 24px;
            background: linear-gradient(110deg, #ececec 8%, #f5f5f5 18%, #ececec 33%);
            border-radius: 4px;
            background-size: 200% 100%;
            animation: shimmer 1.5s linear infinite;
        }

        .skeleton-subtitle {
            width: 60%;
            height: 16px;
            background: linear-gradient(110deg, #ececec 8%, #f5f5f5 18%, #ececec 33%);
            border-radius: 4px;
            background-size: 200% 100%;
            animation: shimmer 1.5s linear infinite;
        }
    }

    @keyframes shimmer {
        0% { background-position: 200% 0; }
        100% { background-position: -200% 0; }
    }

    @media (max-width: 768px) {
        .container {
            padding: 1rem 1.5rem;
        }

        .exam-grid {
            padding: 1rem;
            gap: 1.5rem;
        }

        .exam-card {
            padding: 1.5rem;
        }
    }
</style>