import type { PageLoad } from './$types';

export const ssr = false;

export const load: PageLoad = async ({ params }) => {
    return {
        examId: params.examId,
        resultId: params.resultID
    };
};