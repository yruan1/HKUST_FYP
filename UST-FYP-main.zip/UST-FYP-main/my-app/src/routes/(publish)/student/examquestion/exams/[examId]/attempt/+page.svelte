<script lang="ts">
	import { onMount } from 'svelte';
	import { db } from '$lib/firebase';
	import { doc, getDoc, addDoc, collection, query, getDocs, where } from 'firebase/firestore';
	import { page } from '$app/stores';
	import { goto } from '$app/navigation';
	import Loading from '$lib/components/loadingPage.svelte';

	let isSubmitting = false;
	interface QuestionContent {
		content: string;
		part: number;
	}

	interface ExamDocument {
		createdAt: string;
		questions: {
			[key: string]: QuestionContent;
		};
		year: number;
	}

	interface ExamResult {
		answers: {
			[key: number]: string;
		};
		comment: {
			comments: { [key: number]: string };
			grammar: { [key: number]: string };
			vocabularies: { [key: number]: string };
		};
		exams: string;
		grade: string;
		submittedAt: string;
		userID: string;
	}

	interface Question {
		title: string;
		instructions: string;
		questionText: string;
	}

	interface Questions {
		[key: number]: Question;
	}

	let timeLeft = 60 * 60; // 60 minutes
	let wordCount = 0;
	let currentPart = 1;
	let loading = true;
	let examDoc: ExamDocument | null = null;
	let showConfirmModal = false;

	interface Answers {
		[key: number]: string;
	}

	let answers: Answers = {};
	let questions: Questions = {};

	function getInstructions(partNumber: number): string {
		return partNumber === 1
			? 'You should spend about 20 minutes on this task. Write at least 150 words.'
			: 'You should spend about 40 minutes on this task. Write at least 250 words.';
	}

	async function fetchExamQuestions() {
		try {
			const examId = $page.params.examId;
			const examRef = doc(db, 'exams', examId);
			const examSnapshot = await getDoc(examRef);

			if (examSnapshot.exists()) {
				examDoc = examSnapshot.data() as ExamDocument;

				if (examDoc.questions) {
					questions = {};
					answers = {};

					Object.entries(examDoc.questions)
						.sort((a, b) => a[1].part - b[1].part)
						.forEach(([_, value]) => {
							const partNumber = value.part;
							questions[partNumber] = {
								title: `Part ${partNumber}`,
								instructions: getInstructions(partNumber),
								questionText: value.content
							};
							answers[partNumber] = '';
						});

					// Set initial part to the first part number
					const parts = Object.keys(questions).map(Number);
					if (parts.length > 0) {
						currentPart = parts[0];
					}
				}
			}
		} catch (err) {
			console.error('Error fetching exam questions:', err);
		} finally {
			loading = false;
		}
	}

	const formatTime = (seconds: number): string => {
		const minutes = Math.floor(seconds / 60);
		const remainingSeconds = seconds % 60;

		if (minutes < 1) {
			return `${minutes}:${remainingSeconds.toString().padStart(2, '0')} seconds left`;
		}

		return `${minutes} minutes left`;
	};

	const updateWordCount = (text: string) => {
		const words = text.trim().split(/\s+/);
		wordCount = text.trim() === '' ? 0 : words.length;
	};

	const handleInput = (event: Event) => {
		const target = event.target as HTMLTextAreaElement;
		answers[currentPart] = target.value;
		updateWordCount(answers[currentPart]);
	};

	const handlePartClick = (part: number, e: MouseEvent) => {
		e.preventDefault();
		currentPart = part;
		updateWordCount(answers[part] || '');
	};

	const handleDirectionClick = () => {
		const parts = Object.keys(questions)
			.map(Number)
			.sort((a, b) => a - b);
		const currentIndex = parts.indexOf(currentPart);

		if (currentIndex < parts.length - 1) {
			currentPart = parts[currentIndex + 1];
		} else {
			currentPart = parts[0];
		}
		updateWordCount(answers[currentPart] || '');
	};

	const handleExit = async () => {
		const examId = $page.params.examId;
		goto(`/student/examquestion/exams/${examId}`);
	};

	const handleSubmit = () => {
		showConfirmModal = true;
	};

	const closeModal = () => {
		showConfirmModal = false;
	};

	const confirmSubmit = async () => {
		try {
			showConfirmModal = false;
			isSubmitting = true;

			const examId = $page.params.examId;
			let userId = '';

			if (typeof document !== 'undefined') {
				// Split by semicolon first to handle multiple cookies
				const cookies = document.cookie.split(';');
				for (const cookie of cookies) {
					const [name, value] = cookie.trim().split('=');
					if (name.trim() === 'uid') {
						// Get clean UID without any trailing text
						userId = value.split(';')[0].trim();
						break;
					}
				}
			}

			if (!userId) {
				alert('User not authenticated');
				return;
			}

			const submissionAnswers: { [key: number]: string } = {};
			Object.entries(answers).forEach(([part, answer]) => {
				if (answer?.trim()) {
					submissionAnswers[Number(part)] = answer;
				}
			});

			const comment = {
				comments: {},
				grammar: {},
				vocabularies: {}
			};

			Object.keys(submissionAnswers).forEach((part) => {
				const partNum = Number(part);
				comment.comments[partNum] = 'pending';
				comment.grammar[partNum] = 'pending';
				comment.vocabularies[partNum] = 'pending';
			});

			const docRef = await addDoc(collection(db, 'examResult'), {
				answers: submissionAnswers,
				comment,
				exams: examId,
				grade: 'Pending',
				submittedAt: new Date().toISOString(),
				userID: userId // This will now be clean without the "; uid" suffix
			});

			const gradingResponse = await fetch('/api/grade-exam', {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json'
				},
				body: JSON.stringify({
					resultId: docRef.id,
					answers: submissionAnswers,
					questions: Object.entries(questions).reduce(
						(acc, [part, q]) => {
							acc[part] = q.questionText;
							return acc;
						},
						{} as { [key: string]: string }
					)
				})
			});

			if (!gradingResponse.ok) {
				console.error('Grading process failed:', await gradingResponse.text());
			}

			goto(`/student/examquestion/exams/${examId}/result/${docRef.id}`);
		} catch (err) {
			console.error('Error submitting exam:', err);
			alert('Failed to submit exam');
		} finally {
			isSubmitting = false;
			showConfirmModal = false;
		}
	};

	// Modify the onMount function
	// Modify the onMount function
	onMount(async () => {
		// Only keep timer and questions fetching
		await fetchExamQuestions();
		const interval = setInterval(() => {
			if (timeLeft > 0) {
				timeLeft--;
			} else {
				confirmSubmit();
			}
		}, 1000);

		return () => clearInterval(interval);
	});
</script>

<main class="exam-interface">
	<header class="exam-header">
		<button class="nav-btn exit-btn" on:click={handleExit}>
			<svg
				xmlns="http://www.w3.org/2000/svg"
				width="20"
				height="20"
				viewBox="0 0 24 24"
				fill="none"
				stroke="currentColor"
				stroke-width="2"
				stroke-linecap="round"
				stroke-linejoin="round"
			>
				<path d="M19 12H5M12 19l-7-7 7-7" />
			</svg>
			<span>Exit</span>
		</button>

		<div class="timer">
			<svg
				xmlns="http://www.w3.org/2000/svg"
				width="16"
				height="16"
				viewBox="0 0 24 24"
				fill="none"
				stroke="currentColor"
				stroke-width="2"
				stroke-linecap="round"
				stroke-linejoin="round"
			>
				<circle cx="12" cy="12" r="10" />
				<polyline points="12 6 12 12 16 14" />
			</svg>
			<span>{formatTime(timeLeft)}</span>
		</div>

		<button class="nav-btn submit-btn" on:click={handleSubmit}>
			<span>Submit</span>
			<svg
				xmlns="http://www.w3.org/2000/svg"
				width="20"
				height="20"
				viewBox="0 0 24 24"
				fill="none"
				stroke="currentColor"
				stroke-width="2"
				stroke-linecap="round"
				stroke-linejoin="round"
			>
				<path d="M5 12h14M12 5l7 7-7 7" />
			</svg>
		</button>
	</header>

	<div class="exam-content">
		<div class="question-section">
			<div class="question-card">
				{#if loading}
					<div class="loading">Loading questions...</div>
				{:else}
					<h2>{questions[currentPart]?.title || ''}</h2>
					<p class="instructions">
						{questions[currentPart]?.instructions || ''}
					</p>
					<p class="question-text">
						{questions[currentPart]?.questionText || ''}
					</p>
				{/if}
			</div>
		</div>

		<div class="answer-section">
			<div class="answer-card">
				<textarea
					placeholder="Write here."
					on:input={handleInput}
					bind:value={answers[currentPart]}
					disabled={loading}
				></textarea>
				<div class="word-count">Word Count: {wordCount}</div>
			</div>
		</div>
	</div>

	<footer class="exam-footer">
		<div class="part-navigation">
			{#each Object.keys(questions) as part}
				{@const partNum = Number(part)}
				<a
					href="#"
					class="part-btn {currentPart === partNum ? 'active' : ''}"
					on:click={(e) => handlePartClick(partNum, e)}
				>
					Part {partNum}
					<span class="part-number">{partNum}</span>
				</a>
			{/each}
		</div>
		<button class="next-btn" on:click={handleDirectionClick}>
			{currentPart === Math.max(...Object.keys(questions).map(Number)) ? '←' : '→'}
		</button>
	</footer>
</main>

{#if showConfirmModal}
	<div class="modal-overlay">
		<div class="modal-container">
			<div class="modal-content">
				<h2 class="modal-title">Confirm Submission</h2>
				<div class="modal-body">
					<p>Are you sure you want to submit your exam?</p>
					<div class="submission-details">
						{#each Object.keys(questions) as part}
							{@const partNum = Number(part)}
							<div class="detail-item">
								<span class="label">Part {partNum} Word Count:</span>
								<span class="value">
									{(answers[partNum] || '')
										.trim()
										.split(/\s+/)
										.filter((word) => word.length > 0).length} words
								</span>
							</div>
						{/each}
						<div class="detail-item">
							<span class="label">Time Remaining:</span>
							<span class="value">{formatTime(timeLeft)}</span>
						</div>
					</div>
					{#each Object.entries(questions) as [part, question]}
						{@const partNum = Number(part)}
						{@const minWords = partNum === 1 ? 150 : 250}
						{@const wordCount = (answers[partNum] || '')
							.trim()
							.split(/\s+/)
							.filter((word) => word.length > 0).length}
						{#if wordCount < minWords}
							<div class="warning-message">
								<svg
									xmlns="http://www.w3.org/2000/svg"
									class="warning-icon"
									viewBox="0 0 24 24"
									fill="none"
									stroke="currentColor"
									stroke-width="2"
								>
									<path
										d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"
									/>
									<line x1="12" y1="9" x2="12" y2="13" />
									<line x1="12" y1="17" x2="12.01" y2="17" />
								</svg>
								<span>
									Warning: Minimum word count not met for Part {partNum} (minimum {minWords} words)
								</span>
							</div>
						{/if}
					{/each}
				</div>
				<div class="modal-actions">
					<button class="cancel-btn" on:click={closeModal}>Cancel</button>
					<button class="submit-confirm-btn" on:click={confirmSubmit}>Confirm Submission</button>
				</div>
			</div>
		</div>
	</div>
{/if}

{#if isSubmitting}
	<Loading />
{/if}

<style>
	:global(html, body) {
		margin: 0;
		padding: 0;
		width: 100%;
		height: 100%;
		background-color: #f5f5f5;
		font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
	}

	.exam-interface {
		height: 100vh;
		display: flex;
		flex-direction: column;
		background-color: #f5f5f5;
	}

	/* Optimized Header Styles */
	.exam-header {
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding: 0 16px;
		background-color: #18181b;
		height: 56px;
		box-shadow: 0 1px 0 rgba(0, 0, 0, 0.2);
	}

	.nav-btn {
		display: flex;
		align-items: center;
		gap: 8px;
		padding: 6px 12px;
		border-radius: 6px;
		font-size: 14px;
		font-weight: 500;
		cursor: pointer;
		transition: background-color 0.2s ease;
	}

	.exit-btn {
		color: #ffffff;
		background-color: rgba(255, 255, 255, 0.1);
		border: none;
	}

	.exit-btn:hover {
		background-color: rgba(255, 255, 255, 0.15);
	}

	.submit-btn {
		background-color: #4f46e5;
		color: white;
		border: none;
		padding: 8px 16px;
	}

	.submit-btn:hover {
		background-color: #4338ca;
	}

	.timer {
		display: flex;
		align-items: center;
		gap: 6px;
		padding: 6px 12px;
		background-color: rgba(255, 255, 255, 0.1);
		border-radius: 6px;
	}

	.timer svg {
		color: #fbbf24;
	}

	.timer span {
		color: #fbbf24;
		font-size: 14px;
		font-weight: 500;
		letter-spacing: 0.5px;
	}

	/* Content Area Styles */
	.exam-content {
		display: flex;
		flex: 1;
		padding: 1.5rem;
		gap: 1.5rem;
		height: calc(100vh - 56px);
		box-sizing: border-box;
	}

	.question-section,
	.answer-section {
		flex: 1;
		display: flex;
		flex-direction: column;
		min-width: 0; /* Prevents flex items from overflowing */
	}

	.question-card,
	.answer-card {
		background: white;
		border-radius: 12px;
		padding: 1.5rem;
		box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
		height: 100%;
		overflow: hidden;
		display: flex;
		flex-direction: column;
	}

	.loading {
		display: flex;
		justify-content: center;
		align-items: center;
		height: 100%;
		color: #6b7280;
	}

	h2 {
		font-size: 1.25rem;
		color: #111827;
		margin: 0 0 1rem 0;
		font-weight: 600;
	}

	.instructions {
		color: #6b7280;
		margin-bottom: 1rem;
		line-height: 1.5;
		font-size: 0.875rem;
	}

	.question-text {
		line-height: 1.6;
		color: #374151;
		font-size: 0.9375rem;
		flex-grow: 1;
		overflow-y: auto;
	}

	textarea {
		width: 100%;
		height: 100%;
		padding: 0.75rem;
		border: 1px solid #e5e7eb;
		border-radius: 6px;
		resize: none;
		font-size: 0.9375rem;
		line-height: 1.6;
		color: #374151;
		background: #fff;
		flex-grow: 1;
		margin-bottom: 0.5rem;
	}

	textarea:focus {
		outline: none;
		border-color: #4f46e5;
		box-shadow: 0 0 0 2px rgba(79, 70, 229, 0.1);
	}

	textarea:disabled {
		background-color: #f9fafb;
		cursor: not-allowed;
	}

	.word-count {
		color: #6b7280;
		font-size: 0.875rem;
		text-align: right;
		padding-top: 0.5rem;
		border-top: 1px solid #e5e7eb;
	}

	/* Footer Navigation Styles */
	.exam-footer {
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding: 0.75rem 1.5rem;
		background-color: white;
		border-top: 1px solid #e5e7eb;
	}

	.part-navigation {
		display: flex;
		gap: 1.25rem;
	}

	.part-btn {
		display: flex;
		align-items: center;
		gap: 0.5rem;
		color: #6b7280;
		text-decoration: none;
		font-size: 0.875rem;
		font-weight: 500;
		transition: color 0.2s ease;
	}

	.part-btn.active {
		color: #4f46e5;
	}

	.part-number {
		display: inline-flex;
		align-items: center;
		justify-content: center;
		width: 24px;
		height: 24px;
		border-radius: 50%;
		background-color: #f3f4f6;
		color: #6b7280;
		font-size: 0.875rem;
		font-weight: 500;
		transition: all 0.2s ease;
	}

	.part-btn.active .part-number {
		background-color: #4f46e5;
		color: white;
	}

	.next-btn {
		width: 32px;
		height: 32px;
		border: none;
		background-color: #f3f4f6;
		color: #6b7280;
		border-radius: 6px;
		cursor: pointer;
		display: flex;
		align-items: center;
		justify-content: center;
		font-size: 1rem;
		transition: all 0.2s ease;
	}

	.next-btn:hover {
		background-color: #e5e7eb;
		color: #4f46e5;
	}

	/* Modal Styles */
	.modal-overlay {
		position: fixed;
		top: 0;
		left: 0;
		right: 0;
		bottom: 0;
		background-color: rgba(0, 0, 0, 0.5);
		display: flex;
		justify-content: center;
		align-items: center;
		z-index: 50;
	}

	.modal-container {
		background-color: white;
		border-radius: 12px;
		width: 90%;
		max-width: 480px;
		padding: 1.5rem;
		box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
		animation: modal-appear 0.2s ease-out;
	}

	@keyframes modal-appear {
		from {
			opacity: 0;
			transform: translateY(10px);
		}
		to {
			opacity: 1;
			transform: translateY(0);
		}
	}

	.modal-title {
		font-size: 1.25rem;
		font-weight: 600;
		color: #111827;
		margin: 0 0 1rem 0;
	}

	.modal-body {
		margin-bottom: 1.5rem;
	}

	.modal-body p {
		color: #6b7280;
		margin-bottom: 1rem;
	}

	.submission-details {
		background-color: #f9fafb;
		border-radius: 8px;
		padding: 1rem;
		margin-bottom: 1rem;
	}

	.detail-item {
		display: flex;
		justify-content: space-between;
		margin-bottom: 0.5rem;
		font-size: 0.875rem;
	}

	.detail-item:last-child {
		margin-bottom: 0;
	}

	.detail-item .label {
		color: #6b7280;
	}

	.detail-item .value {
		font-weight: 500;
		color: #111827;
	}

	.warning-message {
		display: flex;
		align-items: center;
		gap: 0.5rem;
		padding: 0.75rem;
		background-color: #fef3c7;
		border: 1px solid #fcd34d;
		border-radius: 6px;
		color: #92400e;
		margin-top: 0.75rem;
		font-size: 0.875rem;
	}

	.warning-icon {
		width: 18px;
		height: 18px;
		stroke: currentColor;
	}

	.modal-actions {
		display: flex;
		justify-content: flex-end;
		gap: 0.75rem;
	}

	.cancel-btn {
		padding: 0.5rem 1rem;
		border: 1px solid #e5e7eb;
		border-radius: 6px;
		background-color: white;
		color: #374151;
		font-size: 0.875rem;
		font-weight: 500;
		cursor: pointer;
		transition: all 0.2s ease;
	}

	.cancel-btn:hover {
		background-color: #f9fafb;
	}

	.submit-confirm-btn {
		padding: 0.5rem 1rem;
		border: none;
		border-radius: 6px;
		background-color: #4f46e5;
		color: white;
		font-size: 0.875rem;
		font-weight: 500;
		cursor: pointer;
		transition: all 0.2s ease;
	}

	.submit-confirm-btn:hover {
		background-color: #4338ca;
	}

	/* Responsive Styles */
	@media (max-width: 768px) {
		.exam-content {
			flex-direction: column;
			padding: 1rem;
		}

		.question-card,
		.answer-card {
			padding: 1rem;
		}
	}

	@media (max-width: 640px) {
		.nav-btn span {
			display: none;
		}

		.nav-btn {
			padding: 8px;
		}

		.timer {
			padding: 4px 8px;
		}

		.modal-container {
			width: 95%;
			padding: 1rem;
		}

		.modal-actions {
			flex-direction: column-reverse;
			gap: 0.5rem;
		}

		.cancel-btn,
		.submit-confirm-btn {
			width: 100%;
		}

		.part-btn span:first-child {
			display: none;
		}
	}

	/* Custom Scrollbar */
	.question-text::-webkit-scrollbar,
	textarea::-webkit-scrollbar {
		width: 4px;
	}

	.question-text::-webkit-scrollbar-track,
	textarea::-webkit-scrollbar-track {
		background: #f1f1f1;
		border-radius: 2px;
	}

	.question-text::-webkit-scrollbar-thumb,
	textarea::-webkit-scrollbar-thumb {
		background: #d1d5db;
		border-radius: 2px;
	}

	.question-text::-webkit-scrollbar-thumb:hover,
	textarea::-webkit-scrollbar-thumb:hover {
		background: #9ca3af;
	}
</style>
