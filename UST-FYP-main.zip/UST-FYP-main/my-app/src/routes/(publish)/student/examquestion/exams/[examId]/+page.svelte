<script lang="ts">
	import SearchHeader from '$lib/components/SearchHeader.svelte';
	import SubheadingBar from '$lib/components/SubheadingBar.svelte';
	import UnderscoreDiv from '$lib/components/UnderscoreDiv.svelte';
	import ExamNavigation from '$lib/components/Exam/ExamNavigation.svelte';
	import { onMount } from 'svelte';
	import { db } from '$lib/firebase';
	import { collection, query, where, getDocs, doc, getDoc } from 'firebase/firestore';
	import { page } from '$app/stores';
	import { goto } from '$app/navigation';

	let currentUserId: string | null = null;
	let x: string[] = [];

	// Update your examData interface to include startDate
	let examData: {
		startDate: { seconds: number; nanoseconds: number };
		dueDate: { seconds: number; nanoseconds: number };
		maxAttempts: number;
		title: string;
	} | null = null;

	function initializeUserId() {
		if (typeof document !== 'undefined') {
			const cookieString = document.cookie;
			// Split by semicolon first in case there are multiple cookies
			const cookies = cookieString.split(';');
			for (const cookie of cookies) {
				const [name, value] = cookie.trim().split('=');
				if (name === 'uid') {
					currentUserId = value;
					console.log('Current User ID:', currentUserId);
					break;
				}
			}
		}
	}

	function getUserIdFromCookie(): string | null {
		return currentUserId;
	}

	// Add at the top of the script section:
	let userRole: string | null = null;

	// Add this function to check user role
	async function getUserRole() {
		try {
			const uid = document.cookie
				.split('; ')
				.find((row) => row.startsWith('uid='))
				?.split('=')[1];

			if (uid) {
				const response = await fetch('/api/auth/getUserRole?uid=' + uid);
				if (!response.ok) {
					throw new Error('Failed to fetch user role');
				}
				const data = await response.json();
				return data.role.toLowerCase();
			}
			return null;
		} catch (error) {
			console.error('Error fetching user role:', error);
			return null;
		}
	}

	interface Task {
		title: string;
		resultId: string;
		submittedAt: { seconds: number; nanoseconds: number } | string;
	}

	let tasks: Task[] = [];
	let loading = false;
	let error: string | null = null;
	let examYear: string = '';
	let examContent: string = '';

	// Computed value for remaining attempts
	$: remainingAttempts = examData && tasks ? Math.max(0, examData.maxAttempts - tasks.length) : 0;

	function formatDueDate(
		startDate: { seconds: number; nanoseconds: number } | undefined,
		dueDate: { seconds: number; nanoseconds: number } | undefined
	): string {
		if (!startDate || !dueDate) return 'Dates not set';

		const start = new Date(startDate.seconds * 1000);
		const end = new Date(dueDate.seconds * 1000);

		const formatDate = (date: Date) => {
			return date
				.toLocaleString('en-US', {
					month: 'short',
					day: 'numeric',
					year: 'numeric',
					hour: 'numeric',
					minute: '2-digit',
					hour12: true
				})
				.replace(',', '');
		};

		return `Available ${formatDate(start)} - ${formatDate(end)}`;
	}

	function formatDate(dateString: string | { seconds: number; nanoseconds: number }): string {
		try {
			let date;
			if (typeof dateString === 'object' && 'seconds' in dateString) {
				date = new Date(dateString.seconds * 1000);
			} else if (typeof dateString === 'string') {
				date = new Date(dateString);
			} else {
				return 'Invalid Date';
			}

			if (isNaN(date.getTime())) {
				return 'Invalid Date';
			}

			return date.toLocaleString('en-US', {
				year: 'numeric',
				month: 'long',
				day: 'numeric',
				hour: '2-digit',
				minute: '2-digit',
				second: '2-digit',
				hour12: true
			});
		} catch (error) {
			console.error('Error formatting date:', error);
			return 'Invalid Date';
		}
	}

	function isExamAvailable(
		startDate: { seconds: number; nanoseconds: number } | undefined,
		dueDate: { seconds: number; nanoseconds: number } | undefined
	): boolean {
		if (!startDate || !dueDate) return false;

		const now = new Date().getTime();
		const start = new Date(startDate.seconds * 1000).getTime();
		const end = new Date(dueDate.seconds * 1000).getTime();

		return now >= start && now <= end;
	}

	async function fetchUserExamResults() {
		try {
			loading = true;
			const examId = $page.params.examId;

			if (!currentUserId) {
				initializeUserId();
			}

			const userId = getUserIdFromCookie();
			console.log('Attempting to fetch with userId:', userId);

			if (!userId) {
				throw new Error('User ID not found in cookies');
			}

			console.log('Fetching results for:', { examId, userId });

			const examResultRef = collection(db, 'examResult');
			const fullQuery = query(examResultRef, where('userID', '==', userId));

			const querySnapshot = await getDocs(fullQuery);
			console.log('Query snapshot size:', querySnapshot.size);

			const filteredDocs = querySnapshot.docs.filter((doc) => {
				const data = doc.data();
				return data.exams === examId;
			});

			tasks = filteredDocs
				.map((doc) => {
					const data = doc.data();
					return {
						title: `Attempt`,
						resultId: doc.id,
						submittedAt: data.submittedAt
					};
				})
				.sort((a, b) => {
					const timeA =
						typeof a.submittedAt === 'object' && 'seconds' in a.submittedAt
							? a.submittedAt.seconds * 1000
							: new Date(a.submittedAt as string).getTime();
					const timeB =
						typeof b.submittedAt === 'object' && 'seconds' in b.submittedAt
							? b.submittedAt.seconds * 1000
							: new Date(b.submittedAt as string).getTime();
					return timeB - timeA;
				})
				.map((doc, index, array) => ({
					...doc,
					title: `Attempt ${array.length - index}`
				}));
		} catch (err) {
			console.error('Error fetching exam results:', err);
			error = 'Error loading exam results';
		} finally {
			loading = false;
		}
	}

	async function handleNewAttempt() {
		try {
			const examId = $page.params.examId;
			if (!currentUserId) {
				alert('User not authenticated');
				return;
			}
			if (!examId) {
				alert('Exam ID not found');
				return;
			}

			// Check if attempt count exceeds maxAttempts
			if (remainingAttempts <= 0) {
				alert('Maximum attempts reached');
				return;
			}

			goto(`/student/examquestion/exams/${examId}/attempt`);
		} catch (err) {
			console.error('Error starting new attempt:', err);
			alert(err instanceof Error ? err.message : 'Error starting new attempt');
		}
	}

	function handleViewFeedback(resultId: string) {
		const examId = $page.params.examId;
		goto(`/student/examquestion/exams/${examId}/result/${resultId}`);
	}

	async function fetchExamDetails() {
		try {
			const examId = $page.params.examId;
			const examRef = doc(db, 'exams', examId);
			const examDoc = await getDoc(examRef);

			if (examDoc.exists()) {
				const data = examDoc.data();
				examData = {
					startDate: data.startDate,
					dueDate: data.dueDate,
					maxAttempts: data.maxAttempts,
					title: data.title
				};
				examYear = data.year || '';
				examContent = data.questions?.[0]?.content || '';
			}
		} catch (err) {
			console.error('Error fetching exam details:', err);
			error = 'Error loading exam details';
		}
	}

	// Modify the onMount function:
	onMount(async () => {
		initializeUserId();
		userRole = await getUserRole();

		if (userRole === 'teacher') {
			const currentPath = $page.url.pathname;
			goto(`${currentPath}/people`);
			return;
		}

		// Only proceed with these if not a teacher
		fetchExamDetails();
		fetchUserExamResults();
	});
</script>

<ExamNavigation>
	<div class="container">
		<UnderscoreDiv>
			<div class="exam-info-bar">
				<span class="bold-text">
					{examData ? formatDueDate(examData.startDate, examData.dueDate) : 'Loading...'}
				</span>
				<span class="max-attempts bold-text">
					{#if examData}
						Allowed Attempts {remainingAttempts} remaining
					{:else}
						Allowed Attempts ...
					{/if}
				</span>
			</div>
			<div class="header-section">
				<span class="section-title">{examData ? examData.title : 'Loading...'}</span>
				<button
					class="attempt-button {examData && !isExamAvailable(examData.startDate, examData.dueDate)
						? 'disabled'
						: ''}"
					on:click={examData && !isExamAvailable(examData.startDate, examData.dueDate)
						? handleClose
						: handleNewAttempt}
					title={examData && !isExamAvailable(examData.startDate, examData.dueDate)
						? 'Exam is closed'
						: ''}
				>
					<div class="button-content">
						{#if examData && !isExamAvailable(examData.startDate, examData.dueDate)}
							<svg
								xmlns="http://www.w3.org/2000/svg"
								class="icon"
								viewBox="0 0 24 24"
								fill="none"
								stroke="currentColor"
								stroke-width="2"
								stroke-linecap="round"
								stroke-linejoin="round"
							>
								<path d="M18 6L6 18" />
								<path d="M6 6l12 12" />
							</svg>
							<span>Close</span>
						{:else}
							<svg
								xmlns="http://www.w3.org/2000/svg"
								class="icon"
								viewBox="0 0 24 24"
								fill="none"
								stroke="currentColor"
								stroke-width="2"
								stroke-linecap="round"
								stroke-linejoin="round"
							>
								<path d="M12 20h9" />
								<path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z" />
							</svg>
							<span>New Attempt</span>
						{/if}
					</div>
				</button>
			</div>
		</UnderscoreDiv>

		<UnderscoreDiv>
			<SubheadingBar title={'Recommendation'} checkShow={false} />
			<div class="task-list">
				<div class="task-header">
					<span>Title</span>
					<span>Action</span>
				</div>
				{#if loading}
					<div class="loading">Loading...</div>
				{:else if error}
					<div class="error">{error}</div>
				{:else if tasks.length === 0}
					<div class="no-data">No attempts yet</div>
				{:else}
					{#each tasks as task}
						<div class="task-item">
							<span class="task-title">{task.title}</span>
							<div class="action-column">
								<button
									class="view-feedback-button"
									on:click={() => handleViewFeedback(task.resultId)}
								>
									View Feedback
								</button>
								<span class="submission-time">{formatDate(task.submittedAt)}</span>
							</div>
						</div>
					{/each}
				{/if}
			</div>
		</UnderscoreDiv>
	</div>
</ExamNavigation>

<style lang="scss">
	.container {
		padding: 10px 40px;
	}

	.header-section {
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding: 0 1rem;
	}

	.section-title {
		font-size: 1.25rem;
		color: #333;
		font-weight: 500;
		margin-left: -6px;
	}

	.task-list {
		background-color: #f8f9fa;
		border-radius: 0.5rem;
	}

	.task-header {
		display: grid;
		grid-template-columns: 1fr auto;
		padding: 1rem;
		border-bottom: 1px solid #e9ecef;
		font-weight: 500;
		color: #666;
	}

	.task-item {
		display: grid;
		grid-template-columns: 1fr auto;
		align-items: center;
		padding: 1rem;
		border-bottom: 1px solid #e9ecef;

		&:last-child {
			border-bottom: none;
		}
	}

	.action-column {
		display: flex;
		flex-direction: column;
		align-items: flex-end;
		width: 100%;
		gap: 0.25rem;
	}

	.submission-time {
		color: #666;
		font-size: 0.75rem;
		white-space: nowrap;
		text-align: right;
		width: 100%;
	}

	.loading,
	.error,
	.no-data {
		padding: 1rem;
		text-align: center;
		color: var(--clr-text-primary);
	}

	.error {
		color: #ef4444;
	}

	.no-data {
		color: #666;
	}

	.attempt-button {
		background: linear-gradient(135deg, #e9b8d4 0%, #93c5fd 100%);
		color: white;
		border: none;
		border-radius: 0.75rem;
		padding: 0.75rem 1.5rem;
		font-weight: 600;
		cursor: pointer;
		transition: all 0.2s ease;

		&:hover {
			transform: translateY(-2px);
			box-shadow: 0 4px 12px rgba(147, 197, 253, 0.3);
		}

		&.disabled {
			background: #d1d5db;
			cursor: not-allowed;
			&:hover {
				transform: none;
				box-shadow: none;
			}
		}
	}

	.view-feedback-button {
		background: transparent;
		color: #4986e8;
		border: none;
		padding: 0;
		font-weight: 500;
		cursor: pointer;
		transition: all 0.2s ease;
		width: fit-content;
		text-align: right;

		&:hover {
			text-decoration: underline;
		}
	}

	.button-content {
		display: flex;
		align-items: center;
		gap: 0.5rem;
	}

	.icon {
		width: 1.25rem;
		height: 1.25rem;
		stroke: currentColor;
	}

	.exam-info-bar {
		display: flex;
		justify-content: space-between;
		padding: 0.75rem 1rem;
		border-bottom: 1px solid #e5e7eb;
		color: #4b5563;
		font-size: 0.875rem;
		margin-bottom: 1rem;
	}

	.bold-text {
		font-weight: 600;
	}

	.max-attempts {
		margin-left: auto;
	}

	@media (max-width: 768px) {
		.container {
			padding: 10px 20px;
		}

		.header-section {
			flex-direction: column;
			gap: 1rem;
			align-items: flex-start;
		}

		.attempt-button {
			width: 100%;
			justify-content: center;
		}

		.exam-info-bar {
			flex-direction: column;
			gap: 0.5rem;
		}

		.max-attempts {
			margin-left: 0;
		}
	}
</style>
