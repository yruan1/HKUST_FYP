import { redirect } from '@sveltejs/kit';
import type { LayoutLoad } from './$types';
import { db } from '$lib/firebase';
import { doc, getDoc, collection, query, where, getDocs, deleteDoc } from 'firebase/firestore';

export const load: LayoutLoad = async ({ params }) => {
    const examId = params.examId;
    
    try {
        const examRef = doc(db, 'exams', examId);
        const examSnapshot = await getDoc(examRef);

        if (examSnapshot.exists()) {
            const examData = examSnapshot.data();
            const now = new Date().getTime();
            const dueDate = new Date(examData.dueDate.seconds * 1000).getTime();
            const startDate = new Date(examData.startDate.seconds * 1000).getTime();

            // If time expired or hasn't started, delete all attempts for this exam
            if (now < startDate || now > dueDate) {
                // Query all attempts for this exam
                const attemptsRef = collection(db, 'examAttempts');
                const q = query(attemptsRef, where('examId', '==', examId));
                const querySnapshot = await getDocs(q);

                // Delete each attempt document
                const deletePromises = querySnapshot.docs.map(doc => 
                    deleteDoc(doc.ref)
                );
                
                // Wait for all deletions to complete
                await Promise.all(deletePromises);

                throw redirect(303, `/student/examquestion/exams/${examId}`);
            }
        }

        return {};
    } catch (error) {
        console.error('Error in layout load:', error);
        throw redirect(303, `/student/examquestion/exams/${examId}`);
    }
};