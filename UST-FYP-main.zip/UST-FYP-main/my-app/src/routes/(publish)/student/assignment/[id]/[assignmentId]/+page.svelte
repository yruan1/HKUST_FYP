<script lang="ts">
    import { page } from '$app/stores';
    import { onMount } from 'svelte';
    import { db } from '$lib/firebase';
    import { doc, getDoc, collection, getDocs, addDoc, updateDoc, serverTimestamp, where, query } from 'firebase/firestore';
    import SearchHeader from '$lib/components/SearchHeader.svelte';
    import { getCurrentUserIdFromCookie } from '$lib/utils/auth';
    const courseId = $page.params.id || 'missing-course-id';
    const assignmentId = $page.params.assignmentId || 'missing-assignment-id';
    const urlUserId = $page.url.searchParams.get('userId') || null;
    
    let isTeacher = false; 
    let userRole = 'student';
    let userLoading = true;
    let userId = null;
    
    let editingFeedback = false;
    let editableFeedback = '';
    let editableGrade = '';
    let savingFeedback = false;
    let feedbackSaveError = '';
    let feedbackSaveSuccess = false;
    
    let assignmentDetails = {
        title: "",
        question: "",
        dueDate: "",
        maxAttempts: 5, 
        wordLimit: 500, 
        publishDate: "",
        state: "active"
    };
    
    let usedAttempts = 0;
    let attemptsRemaining = 0;
    let canResubmit = false;
    
    let inNewAttempt = false;
    
    let answers = { q1: "" };
    let feedback = {}; 
    let loading = { q1: false };
    let submitting = false;
    let submitSuccess = false;
    let submitError = "";
    let totalScores = { q1: 0 };
    let activeQuestion: string | null = null;
    let aiTyping = false;
    let currentTip = "";
    let activeTab = 'assistant';
    let autoSaveEnabled = true;
    let loadingSubmission = false;
    let lastSavedTime = "";
    
    let teacherFeedback = null;
    let teacherGrade = null;
    let loadingTeacherFeedback = false;
    let latestSubmissionId = null;
    
    function formatAIResponse(text) {
        if (!text) return "";
        
        let formattedText = text.replace(/\n/g, '<br>');
        
        formattedText = formattedText.replace(/(\d+\.\s)/g, '<strong>$1</strong>');
        
        formattedText = formattedText.replace(/("([^"]+)")/g, '<em class="highlighted-text" onclick="window.highlightTextInResponse(\'$2\')">$1</em>');
        
        return formattedText;
    }
    
    function highlightTextInResponse(textToHighlight) {
        if (!activeQuestion || !answers[activeQuestion]) return;
        
        const textarea = document.querySelector(`textarea[name="${activeQuestion}"]`);
        if (!textarea) return;
        
        const studentText = answers[activeQuestion];
        const startIndex = studentText.indexOf(textToHighlight);
        
        if (startIndex >= 0) {
            textarea.focus();
            
            textarea.setSelectionRange(startIndex, startIndex + textToHighlight.length);
            
            const lineHeight = parseInt(getComputedStyle(textarea).lineHeight);
            const lines = studentText.substr(0, startIndex).split('\n').length - 1;
            textarea.scrollTop = lines * lineHeight;
        }
    }
    
    async function checkUserRole() {
        try {
            userLoading = true;
            const uid = urlUserId || getCurrentUserIdFromCookie();
            
            if (!uid) {
                console.warn("No user ID found in URL or cookie");
                isTeacher = false;
                userRole = 'guest';
                return;
            }
            
            userId = uid;
            console.log("Checking role for user ID:", userId);
            
            const userRef = doc(db, 'users', uid);
            const userSnap = await getDoc(userRef);
            
            if (userSnap.exists()) {
                const userData = userSnap.data();
                console.log("User data:", userData);
                
                userRole = userData.role || 'student';
                
                isTeacher = userRole === 'teacher' || userRole === 'admin';
                
                const viewMode = $page.url.searchParams.get('mode');
                if (viewMode === 'teacher') {
                    isTeacher = true;
                }
                
                console.log(`User role: ${userRole}, Is teacher: ${isTeacher}`);
            } else {
                console.warn("User document not found");
                isTeacher = false;
                userRole = 'student';
            }
        } catch (error) {
            console.error("Error checking user role:", error);
            isTeacher = false;
            userRole = 'student';
        } finally {
            userLoading = false;
        }
    }
  
    function getWordCount(text:string) {
        return text.trim() ? text.trim().split(/\s+/).length : 0;
    }
    
    async function fetchAttempts() {
        if (!courseId || !assignmentId || !userId) return;
        
        try {
            const submissionsQuery = query(
                collection(db, 'assignmentResult'),
                where('assignmentId', '==', assignmentId),
                where('courseId', '==', courseId),
                where('userId', '==', userId) 
            );
            
            const submissionSnapshot = await getDocs(submissionsQuery);
            
            usedAttempts = submissionSnapshot.size;
            
            attemptsRemaining = Math.max(0, assignmentDetails.maxAttempts - usedAttempts);
            
            canResubmit = attemptsRemaining > 0 && 
                          assignmentDetails.state !== "closed" && 
                          !isDeadlinePassed(assignmentDetails.dueDate);
            
            console.log(`Used attempts: ${usedAttempts}, Remaining: ${attemptsRemaining}, Can resubmit: ${canResubmit}`);
            
            return submissionSnapshot;
        } catch (error) {
            console.error("Error fetching attempts:", error);
            return null;
        }
    }
    
    async function fetchPreviousSubmission() {
        if (!courseId || !assignmentId || !userId) return;
        
        loadingSubmission = true;
        try {
            let submissionsQuery;
            
            if (isTeacher && !urlUserId) {
                submissionsQuery = query(
                    collection(db, 'assignmentResult'),
                    where('assignmentId', '==', assignmentId),
                    where('courseId', '==', courseId)
                );
            } else {
                submissionsQuery = query(
                    collection(db, 'assignmentResult'),
                    where('assignmentId', '==', assignmentId),
                    where('courseId', '==', courseId),
                    where('userId', '==', userId)
                );
            }
            
            const submissionSnapshot = await getDocs(submissionsQuery);
            
            if (!submissionSnapshot.empty) {
                let mostRecentDoc = null;
                let mostRecentTime: string | null = null;
                
                submissionSnapshot.forEach(doc => {
                    const data = doc.data();
                    if (data.submittedAt && (!mostRecentTime || data.submittedAt > mostRecentTime)) {
                        mostRecentTime = data.submittedAt;
                        mostRecentDoc = data;
                        latestSubmissionId = doc.id;
                    }
                });
                
                if (mostRecentDoc) {
                    answers.q1 = mostRecentDoc.answer || "";
                    
                    if (mostRecentDoc.teacherFeedback) {
                        teacherFeedback = mostRecentDoc.teacherFeedback;
                        editableFeedback = mostRecentDoc.teacherFeedback;
                    }
                    
                    if (mostRecentDoc.teacherGrade) {
                        teacherGrade = mostRecentDoc.teacherGrade;
                        editableGrade = mostRecentDoc.teacherGrade;
                    }
                    
                    if (!inNewAttempt) {
                        submitSuccess = true;
                    }
                }
                
                usedAttempts = submissionSnapshot.size;
                attemptsRemaining = Math.max(0, assignmentDetails.maxAttempts - usedAttempts);
                canResubmit = attemptsRemaining > 0 && 
                              assignmentDetails.state !== "closed" && 
                              !isDeadlinePassed(assignmentDetails.dueDate);
            }
        } catch (error) {
            console.error("Error fetching submission:", error);
        } finally {
            loadingSubmission = false;
        }
    }
    
    function startNewAttempt() {
        inNewAttempt = true;
        submitSuccess = false;
        answers.q1 = "";
        submitError = "";
        feedback = {};
        totalScores = { q1: 0 };
        
        localStorage.setItem(`newAttempt_${courseId}_${assignmentId}_${userId}`, "true");
        
        localStorage.removeItem(`assignmentDraft_${courseId}_${assignmentId}_${userId}`);
        
        window.location.reload();
    }

    function isDeadlinePassed(dueDate:string) {
        if (!dueDate) return false;
        return new Date() > new Date(dueDate);
    }
    
    async function updateAssignmentStatus(assignmentId, dueDate) {
        try {
            if (!assignmentId) return;
            
            const newStatus = isDeadlinePassed(dueDate) ? 'closed' : 'completed';
            const assignmentRef = doc(db, 'assignments', assignmentId);
            
            await updateDoc(assignmentRef, {
                status: newStatus,
                lastUpdated: serverTimestamp()
            });
            
            return newStatus;
        } catch (error) {
            console.error("Error updating status:", error);
            throw error;
        }
    }
  
    async function checkArticle(questionKey) {
        if (!answers[questionKey].trim()) {
            feedback[questionKey] = [{ category: "Error", score: 0, feedback: "Please write something before checking." }];
            return;
        }
  
        const wordCount = getWordCount(answers[questionKey]);
        if (wordCount < 50) {
            feedback[questionKey] = [{ category: "Warning", score: 0, feedback: "Your response is too short. Please write at least 50 words for a proper analysis." }];
            return;
        }
  
        loading[questionKey] = true;
        
        try {
            const systemPrompt = `You are an expert writing coach analyzing academic writing. Analyze the following text as a response to the question: "${assignmentDetails.question}"
            
            Provide detailed analysis in these categories:
            1. Grammar - Evaluate grammatical accuracy and sentence structure
            2. Spelling - Check for spelling errors and typos
            3. Style - Assess clarity, coherence, and organization
            4. Vocabulary - Evaluate word choice, vocabulary richness and appropriateness
            
            For each category:
            - Provide a numerical score from 0-100
            - Identify 2-3 specific examples from the text with suggestions for improvement
            - For each example, include the original text in quotes (❌ "problematic text") and a corrected version (✓ "improved text")
            - Explain why the correction improves the writing
            
            Format your response as a valid JSON object like this:
            {
              "grammar": {
                "score": 85, 
                "feedback": "Your grammar is generally good, but there are some issues to address.",
                "examples": [
                  {
                    "original": "The student they went to school.",
                    "corrected": "The student went to school.",
                    "explanation": "Remove the unnecessary pronoun 'they' for proper subject-verb agreement."
                  },
                  {
                    "original": "When writing essays should use proper structure.",
                    "corrected": "When writing essays, you should use proper structure.",
                    "explanation": "This sentence is missing a subject. Adding 'you' and a comma makes it grammatically complete."
                  }
                ]
              },
              "spelling": {
                "score": 90,
                "feedback": "I found only minor spelling issues.",
                "examples": [...]
              },
              "style": {
                "score": 75,
                "feedback": "Your writing style could be more cohesive.",
                "examples": [...]
              },
              "vocabulary": {
                "score": 80,
                "feedback": "Your vocabulary use is good but could be more varied.",
                "examples": [...]
              }
            }`;
            
            const userPrompt = `Here is my response to analyze:\n\n${answers[questionKey]}`;
  
            const response = await fetch("/api/chat", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ systemPrompt, userPrompt })
            });
  
            if (!response.ok) throw new Error(`Server error: ${response.status}`);
  
            const result = await response.json();
            if (result.error) throw new Error(result.error);
  
            let analysisData;
            try {
                if (typeof result.response === 'string') {
                    analysisData = JSON.parse(result.response);
                } else if (result.response && typeof result.response === 'object') {
                    analysisData = result.response;
                } else {
                    throw new Error("Invalid response format");
                }
            } catch (e) {
                const jsonMatch = result.response.match(/\{[\s\S]*\}/);
                if (jsonMatch) {
                    analysisData = JSON.parse(jsonMatch[0]);
                } else {
                    throw new Error("Could not parse AI response");
                }
            }
  
            const categories = [
                { key: "grammar", label: "Grammar" },
                { key: "spelling", label: "Spelling" },
                { key: "style", label: "Style" },
                { key: "vocabulary", label: "Vocabulary" }
            ];
  
            feedback[questionKey] = categories.map(category => ({
                category: category.label,
                score: analysisData[category.key]?.score ?? 0,
                feedback: analysisData[category.key]?.feedback ?? "No feedback available.",
                examples: analysisData[category.key]?.examples ?? []
            }));
  
            totalScores[questionKey] = Math.round(
                feedback[questionKey].reduce((sum, item) => sum + item.score, 0) / feedback[questionKey].length
            );
            
            activeTab = 'analysis';
        } catch (error) {
            console.error("Analysis error:", error);
            feedback[questionKey] = [{ 
                category: "Error", 
                score: 0, 
                feedback: "Error analyzing your text. Please try again or contact support if the problem persists."
            }];
        } finally {
            loading[questionKey] = false;
        }
    }

    async function submitAssignment() {
        if (!answers.q1.trim()) {
            submitError = "Please write something before submitting.";
            return;
        }

        if (!userId) {
            submitError = "Cannot identify user. Please refresh the page and try again.";
            return;
        }

        const wordCount = getWordCount(answers.q1);
        
        if (wordCount < 150) {
            submitError = "Your response is too short. Please write at least 150 words before submitting.";
            return;
        }
        
        if (wordCount > assignmentDetails.wordLimit) {
            submitError = `Your response exceeds the ${assignmentDetails.wordLimit} word limit. Please edit your response to be within the limit.`;
            return;
        }
        
        if (attemptsRemaining <= 0) {
            submitError = "You have used all your allowed attempts for this assignment.";
            return;
        }

        submitting = true;
        submitError = "";
        
        try {
            const submissionData = {
                userId: userId, 
                courseId,
                assignmentId,
                answer: answers.q1,
                wordCount: getWordCount(answers.q1),
                submittedAt: new Date().toISOString(),
                status: 'submitted',
                attemptNumber: usedAttempts + 1
            };
            
            const assignmentResultCollection = collection(db, 'assignmentResult');
            const docRef = await addDoc(assignmentResultCollection, submissionData);
            latestSubmissionId = docRef.id;
            
            teacherFeedback = null;
            teacherGrade = null;
            
            submitSuccess = true;
            inNewAttempt = false;
            
            usedAttempts++;
            attemptsRemaining = Math.max(0, assignmentDetails.maxAttempts - usedAttempts);
            canResubmit = attemptsRemaining > 0 && 
                          assignmentDetails.state !== "closed" && 
                          !isDeadlinePassed(assignmentDetails.dueDate);
            
            localStorage.removeItem(`assignmentDraft_${courseId}_${assignmentId}_${userId}`);
            localStorage.removeItem(`newAttempt_${courseId}_${assignmentId}_${userId}`);
        }
        catch (error) {
            console.error("Submission error:", error);
            submitError = "There was an error submitting your assignment. Please try again.";
        }
        finally {
            submitting = false;
        }
    }

    async function getAIHelp() {
        if (!activeQuestion) return;
        
        aiTyping = true;
        
        try {
            const questionText = assignmentDetails.question;
            const currentText = answers[activeQuestion] || "";
            
            const systemPrompt = `You are a helpful writing assistant for students completing an assignment. 
            Your goal is to provide practical, specific writing guidance.
            
            When providing suggestions:
            1. Format your response as numbered points
            2. Be specific and reference parts of the student's writing directly
            3. Use quote marks to highlight specific phrases when applicable
            4. Provide specific improvement suggestions for each point
            5. Keep suggestions concise and actionable`;
            
            const userPrompt = `I'm writing a response to this question: "${questionText}"
            
            ${currentText.length > 0 ? `Here's what I have so far: 
            
            ${currentText}
            
            ` : "I haven't started writing yet."}
            
            What should I do next to improve my response? Please provide 3-4 specific, actionable suggestions in a numbered list.`;
            
            const response = await fetch("/api/chat", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ systemPrompt, userPrompt })
            });
            
            if (!response.ok) throw new Error(`Server error: ${response.status}`);
            
            const result = await response.json();
            if (result.error) throw new Error(result.error);
            
            currentTip = result.response || "I couldn't generate suggestions at this time. Please try again.";
        } catch (error) {
            console.error("AI help error:", error);
            currentTip = "Sorry, I encountered an error while generating suggestions. Please try again.";
        } finally {
            aiTyping = false;
        }
    }
    
    async function checkForTeacherFeedback() {
        if (!latestSubmissionId) return;
        
        loadingTeacherFeedback = true;
        try {
            const submissionRef = doc(db, 'assignmentResult', latestSubmissionId);
            const submissionSnap = await getDoc(submissionRef);
            
            if (submissionSnap.exists()) {
                const data = submissionSnap.data();
                if (data.teacherFeedback) {
                    teacherFeedback = data.teacherFeedback;
                    editableFeedback = data.teacherFeedback;
                }
                if (data.teacherGrade) {
                    teacherGrade = data.teacherGrade;
                    editableGrade = data.teacherGrade;
                }
            }
        } catch (error) {
            console.error("Error fetching teacher feedback:", error);
        } finally {
            loadingTeacherFeedback = false;
        }
    }
    
    async function saveTeacherFeedback() {
        if (!isTeacher || !latestSubmissionId) return;
        
        savingFeedback = true;
        feedbackSaveError = '';
        feedbackSaveSuccess = false;
        
        try {
            const submissionRef = doc(db, 'assignmentResult', latestSubmissionId);
            
            if (editableGrade) {
                const numericGrade = parseFloat(editableGrade);
                if (isNaN(numericGrade) || numericGrade < 0 || numericGrade > 100) {
                    throw new Error("Grade must be a number between 0 and 100");
                }
            }
            
            await updateDoc(submissionRef, {
                teacherFeedback: editableFeedback || '',
                teacherGrade: editableGrade || null,
                gradedAt: new Date().toISOString(),
                gradedBy: userId,
                updatedAt: serverTimestamp()
            });
            
            teacherFeedback = editableFeedback;
            teacherGrade = editableGrade;
            editingFeedback = false;
            feedbackSaveSuccess = true;
            
            setTimeout(() => {
                feedbackSaveSuccess = false;
            }, 3000);
            
        } catch (error) {
            console.error("Error saving teacher feedback:", error);
            feedbackSaveError = error.message || "Failed to save feedback. Please try again.";
        } finally {
            savingFeedback = false;
        }
    }
    
    function toggleEditingFeedback() {
        if (!isTeacher) return;
        
        if (!editingFeedback) {
            editableFeedback = teacherFeedback || '';
            editableGrade = teacherGrade || '';
            editingFeedback = true;
        } else {
            editingFeedback = false;
            feedbackSaveError = '';
        }
    }
  
    function getBorderClass(score) {
        return score >= 90 ? "success" : score >= 60 ? "warning" : "danger";
    }
    
    function getGradeColor(grade) {
        if (!grade) return "";
        const numericGrade = parseFloat(grade);
        if (isNaN(numericGrade)) return "";
        
        if (numericGrade >= 90) return "grade-a";
        if (numericGrade >= 80) return "grade-b";
        if (numericGrade >= 70) return "grade-c";
        if (numericGrade >= 60) return "grade-d";
        return "grade-f";
    }
  
    function getOverallRating(score) {
        if (score >= 90) return "Excellent";
        if (score >= 80) return "Very Good";
        if (score >= 70) return "Good";
        if (score >= 60) return "Satisfactory";
        if (score >= 50) return "Needs Improvement";
        return "Requires Significant Revision";
    }
  
    function toggleAutoSave() {
        autoSaveEnabled = !autoSaveEnabled;
        if (autoSaveEnabled) saveDrafts();
    }
    
    function saveDrafts() {
        if (!autoSaveEnabled || !inNewAttempt && submitSuccess) return;
        
        localStorage.setItem(`assignmentDraft_${courseId}_${assignmentId}_${userId}`, JSON.stringify(answers));
        
        const now = new Date();
        lastSavedTime = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}:${now.getSeconds().toString().padStart(2, '0')}`;
    }
  
    function setActiveQuestion(questionKey) {
        activeQuestion = questionKey;
        if (!currentTip) activeTab = 'assistant';
    }
    
    function setActiveTab(tab) {
        activeTab = tab;
        
        if (tab === 'teacher-feedback' && submitSuccess) {
            checkForTeacherFeedback();
        }
    }
  
    function hasFeedback() {
        return (!!feedback.q1 && !loading.q1);
    }
  
    async function fetchAssignmentDetails() {
        try {
            if (!assignmentId) {
                return;
            }
            
            const assignmentRef = doc(db, 'assignments', assignmentId);
            const assignmentSnap = await getDoc(assignmentRef);
            
            if (assignmentSnap.exists()) {
                const data = assignmentSnap.data();
                
                assignmentDetails = {
                    title: data.title || "Untitled Assignment",
                    question: data.question || "No question provided",
                    dueDate: data.dueDate || "No due date set",
                    maxAttempts: parseInt(data.maxAttempts) || 5, 
                    wordLimit: parseInt(data.wordLimit) || 500, 
                    publishDate: data.publishDate || "No publish date set",
                    state: data.status || "active"
                };
                
                console.log(`Assignment maxAttempts: ${assignmentDetails.maxAttempts}, wordLimit: ${assignmentDetails.wordLimit}`);
            }
        } catch (error) {
            console.error("Error fetching details:", error);
        }
    }
  
    onMount(async () => {
        await checkUserRole();
        
        await fetchAssignmentDetails();
        
        inNewAttempt = localStorage.getItem(`newAttempt_${courseId}_${assignmentId}_${userId}`) === "true";
        
        if (inNewAttempt) {
            submitSuccess = false;
        }
        
        await fetchAttempts();
        
        if (inNewAttempt) {
            answers.q1 = "";
            
            const savedDraft = localStorage.getItem(`assignmentDraft_${courseId}_${assignmentId}_${userId}`);
            if (savedDraft) {
                try {
                    const parsed = JSON.parse(savedDraft);
                    answers.q1 = parsed.q1 || "";
                } catch (e) {
                    console.error("Error loading draft:", e);
                }
            }
        } else if (assignmentDetails.state === 'completed' || assignmentDetails.state === 'closed') {
            await fetchPreviousSubmission();
        } else {
            const savedDraft = localStorage.getItem(`assignmentDraft_${courseId}_${assignmentId}_${userId}`);
            if (savedDraft) {
                try {
                    const parsed = JSON.parse(savedDraft);
                    answers.q1 = parsed.q1 || "";
                } catch (e) {
                    console.error("Error loading draft:", e);
                }
            } else {
                await fetchPreviousSubmission();
            }
        }
        
        setActiveQuestion('q1');
        
        window.highlightTextInResponse = highlightTextInResponse;
    });
</script>
  
<div class="container">
    
    
    <div class="content">
        <div class="left">
            <div class="questionnaire">
                <div class="assignment-header-area">
                    <h2 class="assignment-title">{assignmentDetails.title}</h2>
                    
                    <div class="assignment-meta">
                        <div class="meta-item">
                            <span class="meta-label">Due</span>
                            <span class="meta-value">{assignmentDetails.dueDate}</span>
                        </div>
                        <div class="meta-item">
                            <span class="meta-label">Max attempts</span>
                            <span class="meta-value">{assignmentDetails.maxAttempts}</span>
                        </div>
                        <div class="meta-item">
                            <span class="meta-label">Word limit</span>
                            <span class="meta-value">{assignmentDetails.wordLimit}</span>
                        </div>
                        <div class="meta-item">
                            <span class="meta-label">Attempts remaining</span>
                            <span class="meta-value attempts-badge {attemptsRemaining > 0 ? 'available' : 'depleted'}">
                                {attemptsRemaining} of {assignmentDetails.maxAttempts}
                            </span>
                        </div>
                        <div class="meta-item">
                            <span class="meta-label">Status</span>
                            <span class="meta-value status-badge {assignmentDetails.state}">
                                {assignmentDetails.state.toUpperCase()}
                            </span>
                        </div>
                        {#if teacherGrade}
                        <div class="meta-item">
                            <span class="meta-label">Grade</span>
                            <span class="meta-value grade-badge {getGradeColor(teacherGrade)}">
                                {teacherGrade}
                            </span>
                        </div>
                        {/if}
                        {#if isTeacher}
                        <div class="meta-item">
                            <span class="teacher-badge">TEACHER VIEW</span>
                        </div>
                        {/if}
                        {#if urlUserId && urlUserId !== userId}
                        <div class="meta-item">
                            <span class="viewing-badge">VIEWING STUDENT ID: {urlUserId}</span>
                        </div>
                        {/if}
                    </div>
                </div>
                
                <div class="question-divider"></div>
                
                <div class="question-block">
                    <div class="question-header">
                        <p class="question-text"><strong>Question:</strong> {assignmentDetails.question}</p>
                    </div>
                    
                    {#if loadingSubmission}
                        <div class="loading-submission">
                            <p>Loading submission...</p>
                            <div class="loading-spinner small"></div>
                        </div>
                    {/if}
                    
                    <textarea 
                        name="q1"
                        id="response-textarea"
                        bind:value={answers.q1} 
                        class="answer-box {isTeacher ? 'read-only' : ''}" 
                        placeholder={isTeacher ? "Viewing student's submission (read-only)" : "Write your response here..."}
                        on:input={saveDrafts}
                        on:focus={() => setActiveQuestion('q1')}
                        disabled={isTeacher || submitSuccess || assignmentDetails.state === "closed" || (attemptsRemaining <= 0 && !inNewAttempt)}
                        readonly={isTeacher}
                    ></textarea>
                    
                    <div class="question-footer">
                        <div class="footer-left">
                            <p class="word-count {getWordCount(answers.q1) < 150 || getWordCount(answers.q1) > assignmentDetails.wordLimit ? 'warning-text' : ''}">
                                Word count: {getWordCount(answers.q1)}/{assignmentDetails.wordLimit}
                            </p>
                            
                            {#if !isTeacher}
                            <div class="autosave-wrapper">
                                <label class="autosave-toggle">
                                    <input 
                                        type="checkbox" 
                                        checked={autoSaveEnabled} 
                                        on:change={toggleAutoSave}
                                        disabled={assignmentDetails.state === "closed" || (submitSuccess && !canResubmit && !inNewAttempt)}
                                    >
                                    <span class="toggle-label">Autosave</span>
                                </label>
                                {#if lastSavedTime}
                                    <span class="last-saved">Last saved at {lastSavedTime}</span>
                                {/if}
                            </div>
                            {/if}
                        </div>
                        
                        <div class="footer-right">
                            {#if !isTeacher}
                                <!-- Only show these buttons for students -->
                                <button 
                                    class="check-btn" 
                                    on:click={() => checkArticle("q1")} 
                                    disabled={loading.q1 || submitting || !submitSuccess || assignmentDetails.state === "closed"}
                                >
                                    {loading.q1 ? "Analyzing..." : "Analyze Response"}
                                </button>

                                <button 
                                    class="submit-btn" 
                                    on:click={submitAssignment} 
                                    disabled={submitting || submitSuccess || assignmentDetails.state === "closed" || attemptsRemaining <= 0}
                                >
                                    {#if submitting}
                                        <span class="btn-spinner"></span> Submitting...
                                    {:else if submitSuccess}
                                        ✓ Submitted
                                    {:else}
                                        Submit
                                    {/if}
                                </button>
                            {:else}
                                <button 
                                    class="feedback-btn" 
                                    on:click={() => setActiveTab('teacher-feedback')}
                                >
                                    Provide Feedback
                                </button>
                            {/if}
                        </div>
                    </div>
                    
                    {#if submitError}
                        <div class="submit-error">
                            {submitError}
                        </div>
                    {/if}
                    
                    {#if submitSuccess && !inNewAttempt && !isTeacher}
                    <div class="submit-success">
                        <p>Your assignment has been submitted successfully!</p>
                        <p>Status: <span class="status-badge {assignmentDetails.state}">
                            {assignmentDetails.state.toUpperCase()}
                        </span></p>
                        
                        <div class="attempts-info">
                            <p>You have used <strong>{usedAttempts}</strong> of <strong>{assignmentDetails.maxAttempts}</strong> allowed attempts.</p>
                            {#if canResubmit}
                                <p>You have <strong>{attemptsRemaining}</strong> {attemptsRemaining === 1 ? 'attempt' : 'attempts'} remaining.</p>
                                <button class="new-attempt-btn" on:click={startNewAttempt}>
                                    Start New Attempt
                                </button>
                            {:else}
                                {#if attemptsRemaining <= 0}
                                    <p class="no-attempts">You have used all allowed attempts for this assignment.</p>
                                {:else if isDeadlinePassed(assignmentDetails.dueDate)}
                                    <p class="deadline-passed">The deadline has passed. No more attempts are allowed.</p>
                                {/if}
                            {/if}
                        </div>
                        
                        <div class="navigation-options">
                            <button class="go-back-btn" on:click={() => window.history.back()}>
                                ← Go Back
                            </button>
                        </div>
                    </div>
                    {:else if submitSuccess && isTeacher}
                    <div class="teacher-submission-view">
                        <p>This is a submitted assignment that you can grade.</p>
                        <p>Click on "Provide Feedback" to grade this submission.</p>
                        
                        <div class="navigation-options">
                            <button class="go-back-btn" on:click={() => window.history.back()}>
                                ← Back to Assignments
                            </button>
                        </div>
                    </div>
                    {:else if assignmentDetails.state === "closed" && !isTeacher}
                    <div class="deadline-notice">
                        <p>This assignment is closed because the deadline has passed.</p>
                        <button class="go-back-btn" on:click={() => window.history.back()}>
                            ← Go Back
                        </button>
                    </div>
                    {:else if assignmentDetails.state === "completed" && !inNewAttempt && !canResubmit && !isTeacher}
                    <div class="submit-success">
                        <p>This assignment has been completed.</p>
                        <p>Status: <span class="status-badge completed">COMPLETED</span></p>
                        
                        <div class="attempts-info">
                            <p>You have used <strong>{usedAttempts}</strong> of <strong>{assignmentDetails.maxAttempts}</strong> allowed attempts.</p>
                            {#if attemptsRemaining > 0}
                                <p>You have <strong>{attemptsRemaining}</strong> {attemptsRemaining === 1 ? 'attempt' : 'attempts'} remaining.</p>
                                <button class="new-attempt-btn" on:click={startNewAttempt}>
                                    Start New Attempt
                                </button>
                            {:else}
                                <p class="no-attempts">You have used all allowed attempts for this assignment.</p>
                            {/if}
                        </div>
                        
                        <div class="navigation-options">
                            <button class="go-back-btn" on:click={() => window.history.back()}>
                                ← Go Back
                            </button>
                        </div>
                    </div>
                    {/if}

                    {#if inNewAttempt && !isTeacher}
                    <div class="current-attempt">
                        <p>You are currently working on a new attempt.</p>
                        <p>Attempts remaining after this submission: <strong>{attemptsRemaining - 1}</strong></p>
                    </div>
                    {/if}
                    
                    {#if isTeacher}
                    <div class="teacher-instruction">
                        <div class="instruction-icon">👨‍🏫</div>
                        <div class="instruction-content">
                            <h3>Teacher View</h3>
                            <p>You are viewing this assignment as a teacher. You can:</p>
                            <ul>
                                <li>Review student submissions</li>
                                <li>Provide feedback and grades</li>
                                <li>View assignment details</li>
                            </ul>
                            <p>The text area is read-only. Use the "Provide Feedback" button to review and grade this work.</p>
                        </div>
                    </div>
                    {/if}
                </div>
            </div>
        </div>
  
        <div class="right">
            <div class="tab-nav">
                <button 
                    class="tab-btn {activeTab === 'assistant' ? 'active' : ''}" 
                    on:click={() => setActiveTab('assistant')}
                    disabled={isTeacher}
                >
                    Writing Assistant
                </button>
                <button 
                    class="tab-btn {activeTab === 'analysis' ? 'active' : ''}" 
                    on:click={() => setActiveTab('analysis')}
                    disabled={isTeacher}
                >
                    AI Analysis
                    {#if loading.q1}
                        <span class="loading-dot"></span>
                    {/if}
                </button>
                <button 
                    class="tab-btn {activeTab === 'teacher-feedback' ? 'active' : ''}" 
                    on:click={() => setActiveTab('teacher-feedback')}
                >
                    Teacher Feedback
                    {#if teacherFeedback && !loadingTeacherFeedback}
                        <span class="feedback-dot"></span>
                    {/if}
                </button>
            </div>
            
            {#if activeTab === 'assistant'}
                <div class="helper-section">
                    {#if isTeacher}
                        <div class="teacher-only-message">
                            <p>Writing assistant is only available to students.</p>
                            <p>Please use the Teacher Feedback tab to provide feedback and grading.</p>
                        </div>
                    {:else if activeQuestion}
                        <div class="chat-container">
                            <div class="chat-messages">
                                <div class="chat-message user">
                                    <div class="message-bubble">
                                        What should I do next?
                                    </div>
                                </div>
                                
                                {#if aiTyping}
                                    <div class="chat-message ai">
                                        <div class="message-bubble typing">
                                            AI is typing...
                                        </div>
                                    </div>
                                {:else if currentTip}
                                    <div class="chat-message ai">
                                        <div class="message-bubble">
                                            {@html formatAIResponse(currentTip)}
                                        </div>
                                    </div>
                                {:else}
                                    <div class="chat-message ai">
                                        <div class="message-bubble">
                                            I can help you with your response to the question. Click the button below to get suggestions for your next steps.
                                        </div>
                                    </div>
                                {/if}
                            </div>
                            
                            <button 
                                class="help-btn" 
                                on:click={getAIHelp}
                                disabled={assignmentDetails.state === "closed" || (!inNewAttempt && submitSuccess && !canResubmit)}
                            >
                                What should I do next?
                            </button>
                        </div>
                    {:else}
                        <div class="no-question-selected">
                            <p>Click on the question's text area to get writing assistance.</p>
                        </div>
                    {/if}
                </div>
            {:else if activeTab === 'analysis'}
                <div class="analysis-section">
                    {#if isTeacher}
                        <div class="teacher-only-message">
                            <p>AI Analysis is only available to students.</p>
                            <p>Please use the Teacher Feedback tab to provide feedback and grading.</p>
                        </div>
                    {:else if loading.q1}
                        <div class="loading-container">
                            <p>Analyzing your writing...</p>
                            <div class="loading-spinner"></div>
                        </div>
                    {:else if feedback.q1 && !loading.q1}
                        <div class="feedback-section" id="q1-feedback">
                            <div class="feedback-header-main">
                                <h4>Analysis Results</h4>
                                {#if totalScores.q1 > 0}
                                    <div class="total-score {getBorderClass(totalScores.q1)}">
                                        <span class="score-value">{totalScores.q1}</span>
                                        <span class="score-label">{getOverallRating(totalScores.q1)}</span>
                                    </div>
                                {/if}
                            </div>
                            
                            {#each feedback.q1 as item}
                                <div class="feedback-box {getBorderClass(item.score)}">
                                    <div class="feedback-header">
                                        <strong>{item.category}</strong>
                                        <span class="score">{item.score}/100</span>
                                    </div>
                                    <p class="feedback-text">{item.feedback}</p>
                                    
                                    {#if item.examples && item.examples.length > 0}
                                        <div class="examples-section">
                                            {#each item.examples as example, index}
                                                <div class="grammar-section">
                                                    <button 
                                                        class="section-title" 
                                                        on:click={() => {
                                                            if (example.original) {
                                                                const answerText = document.querySelector('#response-textarea');
                                                                if (answerText) {
                                                                    const text = answers.q1;
                                                                    const startIndex = text.indexOf(example.original);
                                                                    
                                                                    if (startIndex !== -1) {
                                                                        answerText.focus();
                                                                        answerText.setSelectionRange(
                                                                            startIndex, 
                                                                            startIndex + example.original.length
                                                                        );
                                                                        
                                                                        const lineHeight = parseInt(getComputedStyle(answerText).lineHeight);
                                                                        const lines = text.substr(0, startIndex).split('\n').length - 1;
                                                                        answerText.scrollTop = lines * lineHeight;
                                                                    }
                                                                }
                                                            }
                                                        }}
                                                    >
                                                        {index + 1}. Issue: ❌ "{example.original}"
                                                    </button>
                                                    <div class="section-content">
                                                        <p>
                                                            <span class="correction-label">Correction:</span> 
                                                            <span class="correction-text">✓ "{example.corrected}"</span>
                                                        </p>
                                                        <p class="explanation">
                                                            <span class="explanation-label">Why:</span> {example.explanation}
                                                        </p>
                                                    </div>
                                                </div>
                                            {/each}
                                        </div>
                                    {/if}
                                </div>
                            {/each}
                        </div>
                    {:else if !feedback.q1 && !loading.q1}
                        <div class="placeholder-info">
                            <p>Click "Analyze Response" to get AI-powered feedback on your writing.</p>
                            <ul>
                                <li>Grammar and spelling check</li>
                                <li>Style and coherence analysis</li>
                                <li>Vocabulary evaluation</li>
                                <li>Suggestions for improvement</li>
                            </ul>
                        </div>
                    {/if}
                </div>
            {:else if activeTab === 'teacher-feedback'}
                <div class="teacher-feedback-section">
                    {#if loadingTeacherFeedback}
                        <div class="loading-container">
                            <p>Loading teacher feedback...</p>
                            <div class="loading-spinner"></div>
                        </div>
                    {:else if isTeacher && latestSubmissionId}
                        <!-- Teacher view - can edit feedback -->
                        <div class="teacher-feedback teacher-edit-mode">
                            <div class="feedback-header">
                                <h4>Teacher Feedback {editingFeedback ? '(Editing)' : ''}</h4>
                                <div class="feedback-actions">
                                    {#if editingFeedback}
                                        <button class="cancel-btn" on:click={toggleEditingFeedback}>Cancel</button>
                                        <button 
                                            class="save-btn" 
                                            on:click={saveTeacherFeedback}
                                            disabled={savingFeedback}
                                        >
                                            {savingFeedback ? 'Saving...' : 'Save Feedback'}
                                        </button>
                                    {:else}
                                        <button class="edit-btn" on:click={toggleEditingFeedback}>
                                            {teacherFeedback ? 'Edit Feedback' : 'Add Feedback'}
                                        </button>
                                    {/if}
                                </div>
                            </div>
                            
                            {#if editingFeedback}
                                <div class="feedback-edit-form">
                                    <div class="form-group">
                                        <label for="teacher-grade">Grade (0-100):</label>
                                        <input 
                                            type="number" 
                                            id="teacher-grade" 
                                            bind:value={editableGrade}
                                            min="0"
                                            max="100"
                                            placeholder="Enter grade (0-100)"
                                        />
                                    </div>
                                    <div class="form-group">
                                        <label for="teacher-feedback">Feedback:</label>
                                        <textarea 
                                            id="teacher-feedback"
                                            bind:value={editableFeedback}
                                            rows="8"
                                            placeholder="Enter your feedback for the student..."
                                        ></textarea>
                                    </div>
                                    
                                    {#if feedbackSaveError}
                                        <div class="feedback-error-message">
                                            {feedbackSaveError}
                                        </div>
                                    {/if}
                                    
                                    {#if feedbackSaveSuccess}
                                        <div class="feedback-success-message">
                                            Feedback saved successfully!
                                        </div>
                                    {/if}
                                </div>
                            {:else}
                                <div class="feedback-content">
                                    {#if teacherGrade}
                                        <div class="grade-display {getGradeColor(teacherGrade)}">
                                            <span class="grade-value">{teacherGrade}</span>
                                        </div>
                                    {:else}
                                        <div class="grade-pending">
                                            <span>No Grade Yet</span>
                                        </div>
                                    {/if}
                                    
                                    {#if teacherFeedback}
                                        <p>{teacherFeedback}</p>
                                    {:else}
                                        <p class="no-feedback-yet">No feedback has been provided yet.</p>
                                    {/if}
                                </div>
                            {/if}
                        </div>
                    {:else if teacherFeedback}
                        <div class="teacher-feedback">
                            <div class="feedback-header">
                                <h4>Teacher Feedback</h4>
                                {#if teacherGrade}
                                    <div class="grade-display {getGradeColor(teacherGrade)}">
                                        <span class="grade-value">{teacherGrade}</span>
                                    </div>
                                {:else}
                                    <div class="grade-pending">
                                        <span>Pending</span>
                                    </div>
                                {/if}
                            </div>
                            <div class="feedback-content">
                                <p>{teacherFeedback}</p>
                            </div>
                            <div class="feedback-meta">
                                <button class="refresh-btn" on:click={checkForTeacherFeedback}>
                                    Refresh Feedback
                                </button>
                            </div>
                        </div>
                    {:else if submitSuccess}
                        <div class="awaiting-feedback">
                            <div class="status-icon pending-icon"></div>
                            <h4>Awaiting Teacher Feedback</h4>
                            <p>Your submission has been received and is waiting for teacher review.</p>
                            <p>Check back later to see your grade and feedback.</p>
                            <button class="refresh-btn" on:click={checkForTeacherFeedback}>
                                Check for Updates
                            </button>
                            
                            {#if isTeacher}
                                <div class="teacher-actions">
                                    <button class="add-feedback-btn" on:click={toggleEditingFeedback}>
                                        Add Feedback
                                    </button>
                                </div>
                            {/if}
                        </div>
                    {:else if isTeacher && !latestSubmissionId}
                        <div class="teacher-no-submission">
                            <div class="status-icon no-submission-icon"></div>
                            <h4>No Submission to Review</h4>
                            <p>There is no submission for this assignment yet.</p>
                            <p>Check back later when students have submitted their work.</p>
                        </div>
                    {:else}
                        <div class="no-submission">
                            <div class="status-icon no-submission-icon"></div>
                            <h4>No Submission Yet</h4>
                            <p>You haven't submitted this assignment yet.</p>
                            <p>Submit your work to receive teacher feedback.</p>
                        </div>
                    {/if}
                </div>
            {/if}
        </div>
    </div>
</div>

<style lang="scss">
.container {
    width: 100%;
    height: 100vh;
    background: white;
    padding: 20px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    display: flex;
    flex-direction: column;
}

.content {
    display: flex;
    gap: 20px;
    flex-grow: 1;
}

.left {
    width: 70%;
    display: flex;
    flex-direction: column;
}

.right {
    width: 30%;
    background: #f8f9fa;
    padding: 15px;
    border-left: 2px solid #ddd;
    overflow-y: auto;
    border-radius: 5px;
    max-height: calc(100vh - 100px);
    display: flex;
    flex-direction: column;
}

.teacher-badge, .viewing-badge {
    display: inline-block;
    padding: 3px 8px;
    background-color: #4a89dc;
    color: white;
    font-size: 12px;
    font-weight: 600;
    border-radius: 4px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
}

.viewing-badge {
    background-color: #9b59b6;
}

/* Teacher instruction */
.teacher-instruction {
    margin-top: 20px;
    padding: 15px;
    background-color: #e3f2fd;
    border-radius: 8px;
    display: flex;
    gap: 15px;
    align-items: flex-start;
}

.instruction-icon {
    font-size: 24px;
    flex-shrink: 0;
}

.instruction-content {
    flex-grow: 1;
}

.instruction-content h3 {
    margin: 0 0 10px 0;
    color: #1565c0;
}

.instruction-content p {
    margin: 0 0 10px 0;
    color: #333;
}

.instruction-content ul {
    margin: 0 0 10px 0;
    padding-left: 20px;
}

.instruction-content li {
    margin-bottom: 5px;
}

.teacher-only-message {
    padding: 20px;
    background-color: #e3f2fd;
    border-radius: 8px;
    text-align: center;
    margin-bottom: 15px;
}

.teacher-only-message p {
    margin: 0 0 10px 0;
    color: #1565c0;
    font-size: 14px;
}

.teacher-only-message p:last-child {
    margin-bottom: 0;
}

.answer-box.read-only {
    background-color: #f8f9fa;
    cursor: default;
    border-color: #e2e8f0;
}

.teacher-submission-view {
    margin-top: 15px;
    padding: 15px;
    background-color: #e3f2fd;
    border-left: 4px solid #1565c0;
    border-radius: 4px;
}

.teacher-submission-view p {
    margin: 0 0 10px 0;
    color: #1565c0;
}

.teacher-no-submission {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    text-align: center;
    height: 100%;
    gap: 15px;
    padding: 20px;
}

.teacher-no-submission h4 {
    margin: 0;
    color: #2c3e50;
    font-size: 18px;
}

.teacher-no-submission p {
    margin: 5px 0;
    color: #7f8c8d;
    font-size: 14px;
}

/* Feedback button for teachers */
.feedback-btn {
    padding: 8px 16px;
    background-color: #6c5ce7;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 14px;
    min-width: 140px;
    transition: background-color 0.3s;
}

.feedback-btn:hover {
    background-color: #5649c0;
}

.questionnaire {
    border: 2px solid #ddd;
    border-radius: 5px;
    padding: 20px;
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
    gap: 15px;
    overflow-y: auto;
    background-color: #fff;
}

.assignment-header-area {
    margin-bottom: 15px;
}

.assignment-title {
    font-size: 1.5rem;
    font-weight: 600;
    color: #111827;
    margin: 0 0 10px 0;
}

.assignment-meta {
    display: flex;
    gap: 30px;
    color: #555;
    font-size: 15px;
    flex-wrap: wrap;
}

.meta-item {
    display: flex;
    gap: 5px;
}

.meta-label {
    font-weight: 600;
    color: #444;
}

.status-badge {
    padding: 2px 8px;
    border-radius: 12px;
    font-size: 12px;
    font-weight: 600;
    text-transform: uppercase;
}

.status-badge.active { background-color: #e3f2fd; color: #1565c0; }
.status-badge.completed { background-color: #e8f5e9; color: #2e7d32; }
.status-badge.closed { background-color: #ffebee; color: #c62828; }

.grade-badge {
    padding: 2px 8px;
    border-radius: 12px;
    font-size: 12px;
    font-weight: 600;
}

.grade-a { background-color: #e8f5e9; color: #2e7d32; }
.grade-b { background-color: #e3f2fd; color: #1565c0; }
.grade-c { background-color: #fff3e0; color: #e65100; }
.grade-d { background-color: #feeed7; color: #ef6c00; }
.grade-f { background-color: #ffebee; color: #c62828; }

/* Attempts badge */
.attempts-badge {
    padding: 2px 8px;
    border-radius: 12px;
    font-size: 12px;
    font-weight: 600;
}

.attempts-badge.available { background-color: #e8f5e9; color: #2e7d32; }
.attempts-badge.depleted { background-color: #ffebee; color: #c62828; }

.question-divider {
    height: 1px;
    background-color: #eee;
    width: 100%;
    margin: 5px 0 15px 0;
}

.question-text {
    font-size: 1.05rem;
    margin: 0;
    color: #2c3e50;
    line-height: 1.5;
}

.loading-submission {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 10px;
    font-size: 14px;
    color: #666;
}

.loading-spinner.small {
    width: 16px;
    height: 16px;
    border: 2px solid #f3f3f3;
    border-top: 2px solid #3498db;
    border-radius: 50%;
    animation: spin 1s linear infinite;
}

/* Text area */
.answer-box {
    width: 100%;
    height: 240px;
    border: 1px solid #ddd;
    border-radius: 5px;
    padding: 12px;
    font-size: 16px;
    resize: vertical;
    font-family: Arial, sans-serif;
    line-height: 1.5;
    transition: border-color 0.3s;
}

.answer-box:disabled {
    background-color: #f9f9f9;
    color: #333;
    cursor: not-allowed;
    opacity: 0.9;
}

.answer-box:focus {
    outline: none;
    border-color: #4a89dc;
    box-shadow: 0 0 0 2px rgba(74, 137, 220, 0.2);
}

.answer-box::selection {
    background-color: rgba(255, 255, 0, 0.3);
}

.question-footer {
    display: flex;
    justify-content: space-between;
    margin-top: 10px;
    flex-wrap: wrap;
    gap: 10px;
}

.footer-left { display: flex; flex-direction: column; gap: 5px; }
.footer-right { display: flex; gap: 10px; }

.word-count {
    font-size: 14px;
    color: #555;
    margin: 0;
}

.warning-text { color: #f39c12; }

.autosave-wrapper {
    display: flex;
    align-items: center;
    gap: 10px;
    font-size: 12px;
    color: #777;
}

.autosave-toggle {
    display: flex;
    align-items: center;
    cursor: pointer;
}

.autosave-toggle input { margin-right: 5px; }
.toggle-label { font-size: 12px; color: #666; }
.last-saved { font-style: italic; }

.submit-btn, .refresh-btn, .edit-btn, .save-btn, .cancel-btn, .add-feedback-btn {
    padding: 8px 16px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    color: white;
    font-size: 14px;
    transition: background-color 0.3s;
}

.check-btn {
    padding: 8px 16px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 14px;
    min-width: 140px;
    transition: all 0.3s ease;
}

.check-btn:disabled {
    background-color: #cccccc;
    color: #666666;
    cursor: not-allowed;
}

.check-btn:not(:disabled) {
    background-color: #4caf50; 
    color: white;
    font-weight: 500;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
    animation: pulse-border 2s infinite;
}

.check-btn:not(:disabled):hover {
    background-color: #388e3c;
    box-shadow: 0 3px 7px rgba(0, 0, 0, 0.3);
}

@keyframes pulse-border {
    0% {
        box-shadow: 0 0 0 0 rgba(76, 175, 80, 0.7);
    }
    70% {
        box-shadow: 0 0 0 5px rgba(76, 175, 80, 0);
    }
    100% {
        box-shadow: 0 0 0 0 rgba(76, 175, 80, 0);
    }
}

.submit-btn {
    background: #27ae60;
    min-width: 100px;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 5px;
}

.submit-btn:hover { background: #219a52; }

.refresh-btn, .add-feedback-btn {
    background: #6c5ce7;
    margin-top: 15px;
    display: inline-block;
}

.refresh-btn:hover, .add-feedback-btn:hover { background: #5649c0; }

.edit-btn {
    background: #6c5ce7;
}

.edit-btn:hover { background: #5649c0; }

.save-btn {
    background: #27ae60;
}

.save-btn:hover { background: #219a52; }

.cancel-btn {
    background: #7f8c8d;
}

.cancel-btn:hover { background: #6c7a7d; }

.submit-btn:disabled, .refresh-btn:disabled, .edit-btn:disabled, .save-btn:disabled {
    background: #95a5a6;
    cursor: not-allowed;
}

.go-back-btn {
    margin-top: 10px;
    padding: 8px 16px;
    background-color: #4267b2;
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 14px;
    display: flex;
    align-items: center;
    gap: 8px;
}

.go-back-btn:hover { background-color: #365899; }

.new-attempt-btn {
    margin-top: 10px;
    padding: 8px 16px;
    background-color: #27ae60;
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 14px;
    display: inline-flex;
    align-items: center;
    gap: 8px;
}

.new-attempt-btn:hover { background-color: #219a52; }

.submit-success {
    margin-top: 15px;
    padding: 15px;
    background-color: #e8f6e9;
    border-left: 4px solid #2e7d32;
    border-radius: 4px;
}

.submit-success p {
    margin: 0 0 10px 0;
    color: #1e8449;
}

.attempts-info {
    margin: 15px 0;
    padding: 10px;
    background-color: #f8f9fa;
    border-radius: 4px;
}

.attempts-info p {
    margin: 5px 0;
}

.current-attempt {
    margin-top: 15px;
    padding: 10px 15px;
    background-color: #e3f2fd;
    border-left: 4px solid #1565c0;
    border-radius: 4px;
}

.current-attempt p {
    margin: 0 0 5px 0;
    color: #1565c0;
}

.no-attempts {
    color: #c62828;
    font-weight: 500;
}

.deadline-passed {
    color: #c62828;
    font-weight: 500;
}

.deadline-notice {
    margin-top: 15px;
    padding: 10px 15px;
    background-color: #ffebee;
    border-left: 4px solid #c62828;
    border-radius: 4px;
}

.deadline-notice p {
    margin: 0 0 10px 0;
    color: #c62828;
}

.submit-error {
    margin-top: 15px;
    padding: 10px 15px;
    background-color: #fdecea;
    border-left: 4px solid #e74c3c;
    border-radius: 4px;
    color: #c0392b;
}

.feedback-error-message {
    margin-top: 10px;
    padding: 10px;
    background-color: #fdecea;
    border-radius: 4px;
    color: #c0392b;
}

.feedback-success-message {
    margin-top: 10px;
    padding: 10px;
    background-color: #e8f6e9;
    border-radius: 4px;
    color: #2e7d32;
}

.navigation-options {
    display: flex;
    gap: 10px;
    margin-top: 15px;
}

.btn-spinner {
    width: 16px;
    height: 16px;
    border: 2px solid rgba(255,255,255,0.3);
    border-radius: 50%;
    border-top-color: #fff;
    animation: btn-spin 1s linear infinite;
}

.tab-nav {
    display: flex;
    margin-bottom: 15px;
    border-bottom: 2px solid #ddd;
}

.tab-btn {
    flex: 1;
    padding: 12px 5px;
    background: none;
    border: none;
    border-bottom: 3px solid transparent;
    font-size: 13px;
    font-weight: 600;
    color: #7f8c8d;
    cursor: pointer;
    position: relative;
}

.tab-btn.active {
    color: #3498db;
    border-bottom-color: #3498db;
}

.tab-btn:hover:not(.active):not(:disabled) {
    color: #2980b9;
    background-color: rgba(52, 152, 219, 0.05);
}

.tab-btn:disabled {
    opacity: 0.5;
    cursor: not-allowed;
}

.loading-dot, .feedback-dot {
    position: absolute;
    top: 8px;
    right: 8px;
    width: 8px;
    height: 8px;
    border-radius: 50%;
}

.loading-dot {
    background-color: #e74c3c;
    animation: pulse 1.5s infinite;
}

.feedback-dot {
    background-color: #2ecc71;
}

.helper-section, .analysis-section, .teacher-feedback-section {
    background: white;
    border-radius: 8px;
    padding: 15px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    flex-grow: 1;
    display: flex;
    flex-direction: column;
}

.teacher-feedback {
    display: flex;
    flex-direction: column;
    flex-grow: 1;
}

.feedback-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 15px;
    padding-bottom: 10px;
    border-bottom: 1px solid #eee;
}

.feedback-header h4 {
    margin: 0;
    color: #2c3e50;
    font-size: 18px;
}

.feedback-actions {
    display: flex;
    gap: 10px;
}

.grade-display {
    padding: 5px 15px;
    border-radius: 8px;
    font-weight: bold;
    font-size: 20px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    margin-bottom: 15px;
    display: inline-block;
}

.grade-pending {
    padding: 5px 15px;
    background-color: #f3f5f7;
    color: #7f8c8d;
    border-radius: 8px;
    font-size: 16px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    font-style: italic;
    margin-bottom: 15px;
    display: inline-block;
}

.feedback-content {
    flex-grow: 1;
    background-color: #f8f9fa;
    padding: 15px;
    border-radius: 8px;
    margin-bottom: 15px;
    white-space: pre-line;
    line-height: 1.6;
}

.feedback-content p {
    margin: 0;
    color: #333;
}

.feedback-meta {
    display: flex;
    justify-content: flex-end;
}

.feedback-edit-form {
    background-color: #f8f9fa;
    padding: 15px;
    border-radius: 8px;
    margin-bottom: 15px;
}

.form-group {
    margin-bottom: 15px;
}

.form-group label {
    display: block;
    margin-bottom: 5px;
    font-weight: 500;
    color: #2c3e50;
}

.form-group input[type="number"] {
    width: 100%;
    padding: 8px 12px;
    border: 1px solid #ddd;
    border-radius: 4px;
    font-size: 16px;
}

.form-group textarea {
    width: 100%;
    padding: 12px;
    border: 1px solid #ddd;
    border-radius: 4px;
    font-size: 16px;
    resize: vertical;
    font-family: Arial, sans-serif;
    line-height: 1.5;
}

.no-feedback-yet {
    color: #7f8c8d;
    font-style: italic;
}

.teacher-actions {
    margin-top: 20px;
    display: flex;
    justify-content: center;
}

.awaiting-feedback, .no-submission {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    text-align: center;
    height: 100%;
    gap: 15px;
    padding: 20px;
}

.status-icon {
    width: 60px;
    height: 60px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 15px auto;
}

.pending-icon {
    background-color: rgba(52, 152, 219, 0.1);
    border: 2px solid #3498db;
    position: relative;
}

.pending-icon::before {
    content: "";
    position: absolute;
    width: 30px;
    height: 30px;
    border: 3px solid #3498db;
    border-radius: 50%;
    border-top-color: transparent;
    animation: spin 1.5s linear infinite;
}

.no-submission-icon {
    background-color: rgba(149, 165, 166, 0.1);
    border: 2px solid #95a5a6;
    position: relative;
}

.no-submission-icon::before {
    content: "!";
    font-size: 30px;
    font-weight: bold;
    color: #95a5a6;
}

.awaiting-feedback h4, .no-submission h4 {
    margin: 0;
    color: #2c3e50;
    font-size: 18px;
}

.awaiting-feedback p, .no-submission p {
    margin: 5px 0;
    color: #7f8c8d;
    font-size: 14px;
}

.container div.s-EHBj4WKrFB0h,
.container div[title="Add new exam"] {
    display: none !important;
}
.chat-container {
    display: flex;
    flex-direction: column;
    gap: 12px;
    flex-grow: 1;
}

.chat-messages {
    display: flex;
    flex-direction: column;
    gap: 10px;
    margin-bottom: 10px;
    flex-grow: 1;
    overflow-y: auto;
    min-height: 200px; /* Add minimum height to ensure good spacing */
}

.chat-message {
    display: flex;
    width: 100%;
}

.chat-message.user { justify-content: flex-end; }
.chat-message.ai { justify-content: flex-start; }

.message-bubble {
    max-width: 80%;
    padding: 10px 15px;
    border-radius: 18px;
    font-size: 14px;
    line-height: 1.4;
    word-break: break-word;
}

.chat-message.user .message-bubble {
    background-color: #4a89dc;
    color: white;
    border-bottom-right-radius: 4px;
}

.chat-message.ai .message-bubble {
    background-color: #e9f0fb;
    color: #333;
    border-bottom-left-radius: 4px;
}

.message-bubble.typing {
    background-color: #f1f1f1;
}

.message-bubble em {
    background-color: rgba(255, 255, 0, 0.2);
    padding: 1px 2px;
    font-style: italic;
    cursor: pointer;
    border-radius: 3px;
    transition: background-color 0.2s;
}

.message-bubble em:hover {
    background-color: rgba(255, 255, 0, 0.4);
}

.message-bubble strong {
    color: #1565c0;
    font-weight: 600;
}

.highlighted-text {
    background-color: rgba(255, 255, 0, 0.2);
    padding: 1px 2px;
    font-style: italic;
    border-radius: 3px;
    cursor: pointer;
}

.highlighted-text:hover {
    background-color: rgba(255, 255, 0, 0.4);
}

.help-btn {
    background-color: #4a89dc;
    color: white;
    border: none;
    border-radius: 20px;
    padding: 10px 20px;
    font-size: 16px;
    font-weight: bold;
    cursor: pointer;
    align-self: center;
    margin-top: 20px;
    transition: all 0.3s ease;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    min-width: 200px;
    text-align: center;
}

.help-btn:hover { 
    background-color: #3a70c2; 
    box-shadow: 0 6px 8px rgba(0, 0, 0, 0.15);
    transform: translateY(-2px);
}

.help-btn:active {
    transform: translateY(0);
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.help-btn:disabled { 
    background-color: #95a5a6; 
    cursor: not-allowed;
    transform: none;
    box-shadow: none;
}

.no-question-selected {
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 30px 20px;
    background-color: #f8f9fa;
    border-radius: 8px;
    text-align: center;
    flex-grow: 1;
}

.no-question-selected p {
    color: #7f8c8d;
    font-size: 15px;
    margin: 0;
}

/* Analysis feedback */
.feedback-section {
    padding: 15px;
    background: white;
    border-radius: 5px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    margin-bottom: 15px;
}

.feedback-header-main {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 10px;
}

.total-score {
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 5px 10px;
    border-radius: 5px;
    background: #e8f5e9;
}

.score-value { font-size: 1.2rem; font-weight: bold; }
.score-label { font-size: 0.8rem; }

.feedback-box {
    padding: 12px;
    border-radius: 5px;
    font-size: 14px;
    border-left: 5px solid;
    background: #fff;
    margin-bottom: 10px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
}

.feedback-box.success { border-left-color: #27ae60; background: #e8f5e9; }
.feedback-box.warning { border-left-color: #f39c12; background: #fff3cd; }
.feedback-box.danger { border-left-color: #e74c3c; background: #f8d7da; }

.feedback-header {
    display: flex;
    justify-content: space-between;
    margin-bottom: 5px;
}

.loading-container {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: 20px;
    background: white;
    border-radius: 5px;
    margin-bottom: 15px;
}

.loading-spinner {
    border: 4px solid #f3f3f3;
    border-top: 4px solid #3498db;
    border-radius: 50%;
    width: 30px;
    height: 30px;
    animation: spin 1s linear infinite;
    margin-top: 15px;
}

.placeholder-info {
    padding: 15px;
    background: #e8f4fc;
    border-radius: 5px;
}

.examples-section {
    margin-top: 15px;
    border-top: 1px solid rgba(0,0,0,0.1);
    padding-top: 10px;
}

.grammar-section {
    margin-bottom: 15px;
}

.section-title {
    width: 100%;
    text-align: left;
    padding: 8px 12px;
    margin-bottom: 8px;
    border-radius: 6px;
    background: transparent;
    border: none;
    color: #e74c3c;
    font-weight: 600;
    font-size: 14px;
    cursor: pointer;
    transition: all 0.2s ease;
    border-left: 3px solid transparent;
}

.section-title:hover {
    background-color: rgba(231, 76, 60, 0.1);
    border-left-color: #e74c3c;
}

.section-content {
    padding-left: 15px;
    margin-bottom: 10px;
}

.correction-label, .explanation-label {
    font-weight: 600;
    color: #2c3e50;
    margin-right: 5px;
}

.correction-text {
    color: #27ae60;
    font-weight: 500;
}

.explanation {
    font-size: 13px;
    color: #555;
    margin-top: 5px;
    line-height: 1.4;
}

@keyframes btn-spin {
    to { transform: rotate(360deg); }
}

@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}

@keyframes pulse {
    0% { opacity: 0.4; transform: scale(1); }
    50% { opacity: 1; transform: scale(1.2); }
    100% { opacity: 0.4; transform: scale(1); }
}

@media (max-width: 768px) {
    .content { flex-direction: column; }
    .left, .right { width: 100%; }
    .right { margin-top: 20px; border-left: none; border-top: 2px solid #ddd; }
    .assignment-meta { flex-direction: column; gap: 10px; }
    .footer-left, .footer-right { width: 100%; }
}

</style>