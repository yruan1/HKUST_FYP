<script lang="ts">
    import { page } from '$app/stores';
    import SearchHeader from '$lib/components/SearchHeader.svelte';
    import SubheadingBar from '$lib/components/SubheadingBar.svelte';
    import UnderscoreDiv from '$lib/components/UnderscoreDiv.svelte';
    import { onMount } from 'svelte';
    import { db } from '$lib/firebase';
    import { collection, query, where, getDocs, doc, getDoc } from 'firebase/firestore';
    import { goto } from '$app/navigation';
    import { getCurrentUserIdFromCookie } from '$lib/utils/auth';
    const courseId = $page.params.id || 'default-course';
    
    let userClass = ""; // Store the user's class
    let userLoading = true;
    let userId: string | null = null;

    interface Assignment {
        id: string;
        title: string;
        description: string;
        dueDate: string;
        publishDate: string;
        status: 'completed' | 'in-progress' | 'not-started' | 'closed';
        maxAttempts?: number;
        class?: string;
    }

    interface Course {
        id: string;
        title: string;
        institution: string;
        year: number;
    }

    let assignments: Assignment[] = [];
    let filteredAssignments: Assignment[] = [];
    let course: Course | null = null;
    let loading = true;

    // Function to filter assignments based on user's class
    function filterAssignments() {
        // Students only see assignments for their class or assignments with no class specified
        filteredAssignments = assignments.filter(assignment => 
            !assignment.class || // Assignments with no class specified are visible to all
            assignment.class === userClass // Assignments for the student's class
        );
        
        // Sort by due date (most recent first)
        filteredAssignments.sort((a, b) => {
            return new Date(b.dueDate).getTime() - new Date(a.dueDate).getTime();
        });
    }



    // Get user information and class
    async function getUserInfo() {
        try {
            userLoading = true;
            const uid = getCurrentUserIdFromCookie();
            
            if (!uid) {
                return;
            }
            
            userId = uid;
            
            // Get user data from Firestore
            const userRef = doc(db, 'users', uid);
            const userSnap = await getDoc(userRef);
            
            if (userSnap.exists()) {
                const userData = userSnap.data();
                
                // Store the user's class
                userClass = userData.class || "";
            }
        } catch (error) {
            console.error("Error fetching user data:", error);
        } finally {
            userLoading = false;
        }
    }

    function determineAssignmentStatus(publishDate: string, dueDate: string): 'not-started' | 'in-progress' | 'closed' {
        const now = new Date();
        const publish = new Date(publishDate);
        const due = new Date(dueDate);
        
        if (now > due) {
            return 'closed';
        } else if (now >= publish && now <= due) {
            return 'in-progress';
        } else {
            return 'not-started';
        }
    }

    async function fetchCourseDetails() {
        try {
            assignments = [];
            filteredAssignments = [];
            
            const courseRef = doc(db, 'assignmentCourses', courseId);
            const courseSnap = await getDoc(courseRef);
            
            if (courseSnap.exists()) {
                const data = courseSnap.data();
                course = {
                    id: courseSnap.id,
                    title: data.title || 'Untitled Course',
                    institution: data.institution || 'Institution',
                    year: data.year || 2025
                };
            } else {
                course = {
                    id: courseId,
                    title: courseId === 'english-lang' 
                        ? 'HKDSE English Language' 
                        : courseId === 'mathematics'
                        ? 'HKDSE Mathematics'
                        : 'HKDSE Biology',
                    institution: courseId === 'english-lang'
                        ? 'Tanochology'
                        : courseId === 'mathematics'
                        ? 'Learning Hong Kong Special'
                        : 'HK Education Center',
                    year: 2025
                };
            }
            
            const assignmentsQuery = query(
                collection(db, 'assignments'),
                where('courseId', '==', courseId)
            );
            
            const assignmentsSnap = await getDocs(assignmentsQuery);
            if (!assignmentsSnap.empty) {
                assignments = assignmentsSnap.docs.map((doc) => {
                    const data = doc.data();
                    const publishDate = data.publishDate || new Date().toISOString().split('T')[0];
                    const dueDate = data.dueDate || '2025-04-30';
                    
                    const status = data.status === 'completed' 
                        ? 'completed' 
                        : determineAssignmentStatus(publishDate, dueDate);
                    
                    return {
                        id: doc.id,
                        title: data.title || 'Untitled Assignment',
                        description: data.description || 'No description provided',
                        dueDate: dueDate,
                        publishDate: publishDate,
                        status: status,
                        maxAttempts: data.maxAttempts || 3, 
                        class: data.class || "", 
                    };
                });
                
                filterAssignments();
            } else {
                assignments = [];
                filteredAssignments = [];
            }
            
            loading = false;
        } catch (error) {
            console.error('Error fetching course details:', error);
            loading = false;
            
            course = {
                id: courseId,
                title: 'Course',
                institution: 'Institution',
                year: 2025
            };
            
            assignments = [];
            filteredAssignments = [];
        }
    }

    function handleAssignmentClick(assignmentId: string) {
        if (courseId) {
            if (userId) {
                goto(`/student/assignment/${courseId}/${assignmentId}?userId=${userId}`);
            } else {
                goto(`/student/assignment/${courseId}/${assignmentId}`);
            }
        } else {
            console.error('Course ID is undefined');
            goto(`/student/assignment/default-course/${assignmentId}`);
        }
    }

    function getStatusColor(status: string): string {
        switch (status) {
            case 'completed':
                return '#22c55e'; 
            case 'in-progress':
                return '#f59e0b'; 
            case 'closed':
                return '#ef4444'; 
            case 'not-started':
            default:
                return '#6b7280'; 
        }
    }

    function formatDate(dateString: string): string {
        if (!dateString) return "No date";
        const date = new Date(dateString);
        return date.toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
    }

    function getDaysRemaining(dueDate: string): number {
        const today = new Date();
        const due = new Date(dueDate);
        const diffTime = due.getTime() - today.getTime();
        return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    }

    onMount(async () => {
        await getUserInfo();
        
        await fetchCourseDetails();
    });
</script>

<main>
   
    <div class="container">
        <UnderscoreDiv>
            <div class="header-container">
                <SubheadingBar title="Assignment" />
                
                <div class="header-actions">
                    {#if userLoading}
                        <div class="role-checking">
                            <span class="loading-spinner-tiny"></span> Loading...
                        </div>
                    {:else}
                        <div class="role-badge student">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M12 14l9-5-9-5-9 5 9 5z"></path>
                                <path d="M12 14l6.16-3.422a12 12 0 01.665 1.88m-12 0a12 12 0 00-.665-1.88L12 14"></path>
                                <path d="M12 14v10"></path>
                            </svg>
                            Student View - Class: {userClass || 'None'}
                        </div>
                    {/if}
                </div>
            </div>
        </UnderscoreDiv>

        <UnderscoreDiv>
            {#if loading}
                <div class="loading-container">
                    <div class="loading-spinner"></div>
                    <p>Loading assignments...</p>
                </div>
            {:else if filteredAssignments.length === 0}
                <div class="empty-state">
                    <div class="empty-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                            <rect x="2" y="4" width="20" height="16" rx="2" ry="2"></rect>
                            <path d="M6 8h.01"></path>
                            <path d="M6 12h.01"></path>
                            <path d="M6 16h.01"></path>
                            <path d="M10 8h8"></path>
                            <path d="M10 12h8"></path>
                            <path d="M10 16h8"></path>
                        </svg>
                    </div>
                    <h3>No Assignments</h3>
                    <p>
                        {#if userClass}
                            There are no assignments for your class ({userClass}) in this course.
                        {:else}
                            There are no assignments for this course yet.
                        {/if}
                    </p>
                </div>
            {:else}
                <div class="assignments-container">
                    <div class="assignments-list">
                        {#each filteredAssignments as assignment}
                            <div 
                                class="assignment-card" 
                                on:click={() => handleAssignmentClick(assignment.id)}
                                on:keydown={(e) => e.key === 'Enter' && handleAssignmentClick(assignment.id)}
                                role="button"
                                tabindex="0"
                            >
                                <div class="status-indicator" style="background-color: {getStatusColor(assignment.status)}"></div>
                                <div class="assignment-content">
                                    <div class="assignment-header">
                                        <h3 class="assignment-title">
                                            {assignment.title}
                                        </h3>
                                        <div class="assignment-badges">
                                            {#if assignment.class}
                                                <span class="class-badge">
                                                    {assignment.class}
                                                </span>
                                            {/if}
                                            
                                            <div class="status-badge" style="background-color: {getStatusColor(assignment.status)}">
                                                {assignment.status === 'completed' ? 'Completed' : 
                                                assignment.status === 'in-progress' ? 'In Progress' : 
                                                assignment.status === 'closed' ? 'Closed' : 'Not Started'}
                                            </div>
                                        </div>
                                    </div>
                                    <p class="assignment-description">{assignment.description}</p>
                                    <div class="assignment-footer">
                                        <div class="assignment-details">
                                            <div class="assignment-dates">
                                                <div class="publish-date">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                                        <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                                                        <line x1="16" y1="2" x2="16" y2="6"></line>
                                                        <line x1="8" y1="2" x2="8" y2="6"></line>
                                                        <line x1="3" y1="10" x2="21" y2="10"></line>
                                                    </svg>
                                                    <span>Published: {formatDate(assignment.publishDate)}</span>
                                                </div>
                                                <div class="due-date">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                                        <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                                                        <line x1="16" y1="2" x2="16" y2="6"></line>
                                                        <line x1="8" y1="2" x2="8" y2="6"></line>
                                                        <line x1="3" y1="10" x2="21" y2="10"></line>
                                                    </svg>
                                                    <span>
                                                        Due: {formatDate(assignment.dueDate)}
                                                        {#if getDaysRemaining(assignment.dueDate) > 0}
                                                            <span class="days-remaining">
                                                                ({getDaysRemaining(assignment.dueDate)} days remaining)
                                                            </span>
                                                        {:else if getDaysRemaining(assignment.dueDate) === 0}
                                                            <span class="days-remaining today">
                                                                (Due today)
                                                            </span>
                                                        {:else}
                                                            <span class="days-remaining overdue">
                                                                (Overdue by {Math.abs(getDaysRemaining(assignment.dueDate))} days)
                                                            </span>
                                                        {/if}
                                                    </span>
                                                </div>
                                            </div>
                                            <div class="max-attempts">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                                    <path d="M12 2v4m0 12v4M4.93 4.93l2.83 2.83m8.48 8.48l2.83 2.83M2 12h4m12 0h4M4.93 19.07l2.83-2.83m8.48-8.48l2.83-2.83"></path>
                                                </svg>
                                                <span>Max attempts: {assignment.maxAttempts || 3}</span>
                                            </div>
                                        </div>
                                        <span class="view-button">View Assignment →</span>
                                    </div>
                                </div>
                            </div>
                        {/each}
                    </div>
                </div>
            {/if}
        </UnderscoreDiv>
    </div>
</main>

<style lang="scss">
    main {
        position: relative;
        height: 100%;
        width: 100%;
        background-color: var(--clr-content-background);
    }

    :global(div.s-EHBj4WKrFE0n),
    :global(div[title="Add new exam"]) {
        display: none !important;
    }

    .container {
        padding: 1.25rem 2.5rem;
        max-width: 1440px;
        margin: 0 auto;
    }
    
    .header-container {
        display: flex;
        justify-content: space-between;
        align-items: center;
        width: 100%;
    }
    
    .header-actions {
        display: flex;
        align-items: center;
        gap: 10px;
    }
    
    .role-checking {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        color: #6b7280;
        font-size: 0.875rem;
    }
    
    .loading-spinner-tiny {
        display: inline-block;
        width: 12px;
        height: 12px;
        border: 2px solid rgba(0, 0, 0, 0.1);
        border-radius: 50%;
        border-left-color: #93c5fd;
        animation: spin 1s linear infinite;
    }
    
    .role-badge {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        padding: 0.375rem 0.75rem;
        border-radius: 0.375rem;
        font-size: 0.875rem;
        font-weight: 500;
        
        &.student {
            background-color: #f3f4f6;
            color: #4b5563;
        }
        
        svg {
            color: currentColor;
        }
    }

    .loading-container {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        padding: 3rem;
        gap: 1rem;
        text-align: center;
    }

    .loading-spinner {
        width: 2.5rem;
        height: 2.5rem;
        border: 4px solid rgba(0, 0, 0, 0.1);
        border-radius: 50%;
        border-left-color: #93c5fd;
        animation: spin 1s linear infinite;
    }

    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }

    .empty-state {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        padding: 4rem;
        gap: 1rem;
        text-align: center;

        .empty-icon {
            color: #9ca3af;
            margin-bottom: 1rem;
        }

        h3 {
            font-size: 1.25rem;
            font-weight: 600;
            color: #111827;
            margin: 0;
        }

        p {
            color: #6b7280;
            max-width: 24rem;
        }
    }

    .assignments-container {
        padding: 2rem;
    }

    /* Assignments list styles */
    .assignments-list {
        display: flex;
        flex-direction: column;
        gap: 1rem;
    }

    .assignment-card {
        display: flex;
        background-color: white;
        border-radius: 0.75rem;
        overflow: hidden;
        box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        transition: transform 0.2s, box-shadow 0.2s;
        cursor: pointer;

        &:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);

            .view-button {
                transform: translateX(3px);
            }
        }
    }

    .status-indicator {
        width: 8px;
        flex-shrink: 0;
    }

    .assignment-content {
        flex-grow: 1;
        padding: 1.25rem;
    }

    .assignment-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 0.75rem;
    }

    .assignment-title {
        font-size: 1.125rem;
        font-weight: 600;
        color: #111827;
        margin: 0;
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .assignment-badges {
        display: flex;
        gap: 0.5rem;
        align-items: center;
    }

    .status-badge {
        padding: 0.25rem 0.5rem;
        border-radius: 9999px;
        font-size: 0.75rem;
        font-weight: 500;
        color: white;
    }

    .class-badge {
        padding: 0.25rem 0.5rem;
        border-radius: 9999px;
        font-size: 0.75rem;
        font-weight: 500;
        background-color: #e5e7eb;
        color: #374151;
    }

    .assignment-description {
        color: #6b7280;
        line-height: 1.5;
        margin-bottom: 1.25rem;
        overflow: hidden;
        text-overflow: ellipsis;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
    }

    .assignment-footer {
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .assignment-details {
        display: flex;
        flex-direction: column;
        gap: 0.5rem;
    }

    .assignment-dates {
        display: flex;
        flex-direction: column;
        gap: 0.5rem;
    }

    .publish-date, .due-date, .max-attempts {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        color: #6b7280;
        font-size: 0.875rem;

        svg {
            color: #9ca3af;
        }
    }
    
    .due-date {
        .days-remaining {
            margin-left: 0.25rem;
            
            &.today {
                color: #f59e0b;
                font-weight: 500;
            }
            
            &.overdue {
                color: #ef4444;
                font-weight: 500;
            }
        }
    }

    .view-button {
        color: #6d8efb;
        font-size: 0.875rem;
        font-weight: 500;
        transition: transform 0.2s;
    }

    @media (max-width: 768px) {
        .container {
            padding: 1rem 1.5rem;
        }

        .assignments-container {
            padding: 1rem;
        }

        .assignment-header {
            flex-direction: column;
            align-items: flex-start;
            gap: 0.5rem;
        }

        .assignment-footer {
            flex-direction: column;
            align-items: flex-start;
            gap: 0.75rem;
        }
        
        .header-container {
            flex-direction: column;
            align-items: flex-start;
            gap: 1rem;
        }
        
        .header-actions {
            width: 100%;
            flex-direction: column;
            gap: 8px;
            
            .role-badge {
                width: 100%;
                justify-content: center;
            }
        }
    }
</style>