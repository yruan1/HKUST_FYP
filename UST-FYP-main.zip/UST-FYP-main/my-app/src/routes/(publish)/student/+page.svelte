<script lang="ts">
	import ChatBotWidget from '$lib/components/ChatBotWidget.svelte';
	import ProgressCard from '$lib/components/ProgressCard.svelte';
	import SearchHeader from '$lib/components/SearchHeader.svelte';
	import AnnouncementCard from '$lib/components/AnnouncementCard.svelte';
	export let data;
	$: sortedAnnouncements = data.announcements
		? [...data.announcements].sort((a, b) => b.createdAt.seconds - a.createdAt.seconds)
		: [];
</script>

<main>
	<ChatBotWidget></ChatBotWidget>

	<div class="content-container">
		<div><h1>Announcement</h1></div>
		<div class="announcements-container">
			{#each sortedAnnouncements as announcement}
				<AnnouncementCard
					title={announcement.title}
					content={announcement.content}
					author={announcement.author}
					createdAt={announcement.createdAt}
				/>
			{/each}
		</div>
	</div>
</main>

<style lang="scss">
	main {
		height: 100%;
		width: 100%;
		background-color: var(--clr-content-background);
	}

	.content-container {
		padding: 2rem;
		max-width: 800px;
		margin: 0 auto;
	}

	.announcements-container {
		margin-top: 2rem;
	}

	#postbtn {
		height: 40px;
		width: 120px;
		margin-bottom: 1rem;
	}
</style>
