<script lang="ts">
    import { onMount } from 'svelte';
    import { db } from '$lib/firebase';
    import { collection, getDocs, query, where } from 'firebase/firestore';
    import { goto } from '$app/navigation';

    import StatNavigation from '$lib/components/statistics/StatNavigation.svelte';
    import UnderscoreDiv from '$lib/components/UnderscoreDiv.svelte';
    import SubheadingBar from '$lib/components/SubheadingBar.svelte';
    import Graph from '$lib/components/statistics/Graph.svelte';
    import { getCurrentUserIdFromCookie } from '$lib/utils/auth';
    interface ExamResult {
        userID: string;
        exams: string;
        submittedAt: string;
        gradedAt: string;
        grade: string;
        teacherComments?: {
            1: string;
        };
        organization: {
            1: {
                score: string;
            }
        };
        grammarAnalysis: {
            analysis: string;
            analyzedAt: string;
            originalText: string;
        };
    }

    let examResults: { id: string; data: ExamResult }[] = [];
    let filteredResults: { id: string; data: ExamResult }[] = [];
    let loading = true;
    let error: string | null = null;
    let searchQuery = '';
    let currentUserId: string = '';
    let graphData: { date: string; count: number }[] = [];

    function processDataForGraph(results: { id: string; data: ExamResult }[]) {
        const dateMap = new Map();
        
        results.forEach(result => {
            const date = new Date(result.data.submittedAt).toLocaleDateString();
            dateMap.set(date, (dateMap.get(date) || 0) + 1);
        });

        return Array.from(dateMap.entries())
            .map(([date, count]) => ({
                date,
                count
            }))
            .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    }

    // function getCurrentUserIdFromCookie() {
    //     if (typeof document !== 'undefined') {
    //         const match = document.cookie.match(/uid=(.*?)(?:;|$)/);
    //         return match ? match[1] : null;
    //     }
    //     return null;
    //}

    function navigateToExamResult(examId: string, resultId: string) {
        goto(`/student/examquestion/exams/${examId}/result/${resultId}`);
    }

    function getGradeStatuses(result: ExamResult) {
        return {
            teacher: {
                status: result.teacherComments?.['1'] ? 'graded' : 'Pending',
                className: result.teacherComments?.['1'] ? 'graded' : 'pending'
            },
            ai: {
                status: result.grade || 'Pending', // Using the grade field for AI status
                className: result.grade ? 'graded' : 'pending'
            }
        };
    }

    $: {
        filteredResults = examResults.filter(
            (result) =>
                result.data.userID.toLowerCase().includes(searchQuery.toLowerCase()) ||
                result.data.grammarAnalysis?.originalText?.toLowerCase().includes(searchQuery.toLowerCase())
        );
        graphData = processDataForGraph(filteredResults);
    }

    async function fetchAllExamResults() {
        try {
            loading = true;
            error = null;
            currentUserId = getCurrentUserIdFromCookie();

            if (!currentUserId) {
                throw new Error('No user ID found in cookie');
            }

            const examResultsRef = collection(db, 'examResult');
            const q = query(examResultsRef, where('userID', '==', currentUserId));
            const querySnapshot = await getDocs(q);

            examResults = querySnapshot.docs
                .map((doc) => ({
                    id: doc.id,
                    data: doc.data() as ExamResult
                }))
                .sort(
                    (a, b) => new Date(b.data.submittedAt).getTime() - new Date(a.data.submittedAt).getTime()
                );

            filteredResults = examResults;
            graphData = processDataForGraph(examResults);
        } catch (err) {
            console.error('Error:', err);
            error = 'Failed to fetch exam results';
        } finally {
            loading = false;
        }
    }

    onMount(fetchAllExamResults);
</script>

<StatNavigation>
    <UnderscoreDiv>
        {#if !loading && !error && graphData.length > 0}
            <Graph {graphData} />
        {/if}
        <SubheadingBar title={'Exam Results'} checkShow={false} />
        <div class="container">
            <div class="search-container">
                <input
                    type="text"
                    placeholder="Search by content"
                    bind:value={searchQuery}
                    class="search-input"
                />
            </div>

            {#if loading}
                <div class="loading">Loading exam results...</div>
            {:else if error}
                <div class="error">{error}</div>
            {:else if filteredResults.length === 0}
                <div class="no-results">No results found</div>
            {:else}
                <div class="results-list">
                    {#each filteredResults as result}
                        {@const gradeStatuses = getGradeStatuses(result.data)}
                        <div 
                            class="result-item"
                            on:click={() => navigateToExamResult(result.data.exams, result.id)}
                            role="button"
                            tabindex="0"
                            on:keydown={(e) => e.key === 'Enter' && navigateToExamResult(result.data.exams, result.id)}
                        >
                            <div class="result-content">
                                <div class="grades-container">
                                    <div class="grade-status">
                                        <span class="grade-label">Teacher Grade:</span>
                                        <span class="status-badge {gradeStatuses.teacher.className}">
                                            {gradeStatuses.teacher.status}
                                        </span>
                                    </div>
                                    <div class="grade-status">
                                        <span class="grade-label">AI Grade:</span>
                                        <span class="status-badge {gradeStatuses.ai.className}">
                                            {gradeStatuses.ai.status}
                                        </span>
                                    </div>
                                </div>
                                <div class="text-content">
                                    <div class="text-label">Original Text:</div>
                                    <div class="text-value">
                                        {(result.data.answers?.['1'] || 'No content').slice(0, 80)}
                                        {result.data.answers?.['1']?.length > 150 ? '...' : ''}
                                    </div>
                                </div>
                                
                                <div class="timestamps">
                                    <div class="submitted">
                                        Submitted: {new Date(result.data.submittedAt).toLocaleString()}
                                    </div>
                                    {#if result.data.gradedAt}
                                        <div class="graded-time">
                                            AI Graded: {new Date(result.data.gradedAt).toLocaleString()}
                                        </div>
                                    {/if}
                                </div>
                            </div>
                        </div>
                    {/each}
                </div>
            {/if}
        </div>
    </UnderscoreDiv>
</StatNavigation>

<style lang="scss">
    .container {
        padding: 1rem;
    }

    .search-container {
        margin-bottom: 1.5rem;
    }

    .search-input {
        width: 100%;
        max-width: 300px;
        padding: 0.5rem;
        border: 1px solid #e2e8f0;
        border-radius: 0.375rem;
        font-size: 0.875rem;

        &:focus {
            outline: none;
            border-color: #3b82f6;
            box-shadow: 0 0 0 1px #3b82f6;
        }
    }

    .results-list {
        display: flex;
        flex-direction: column;
        gap: 0.75rem;
    }

    .result-item {
        background: white;
        border: 1px solid #e2e8f0;
        border-radius: 0.5rem;
        padding: 1rem;
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        cursor: pointer;
        transition: all 0.2s ease-in-out;

        &:hover {
            background-color: #f8fafc;
            transform: translateY(-1px);
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
        }

        &:focus {
            outline: 2px solid #3b82f6;
            outline-offset: 2px;
        }
    }

    .result-content {
        display: flex;
        flex-direction: column;
        gap: 0.5rem;
        flex: 1;
    }

    .grades-container {
        display: flex;
        gap: 1rem;
        flex-wrap: wrap;
        margin-bottom: 0.5rem;
    }

    .grade-status {
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }

    .grade-label {
        font-weight: 500;
        color: #4b5563;
        font-size: 0.875rem;
    }

    .text-content {
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
    
    .text-label {
        font-weight: 500;
        color: #4b5563;
        font-size: 0.875rem;
    }

    .text-value {
        color: #1f2937;
        white-space: pre-wrap;
        line-height: 1.5;
        font-size: 0.875rem;
        background-color: #f8fafc;
        padding: 0.75rem;
        border-radius: 0.375rem;
        border: 1px solid #e2e8f0;
    }
}

    .timestamps {
        display: flex;
        flex-wrap: wrap;
        gap: 1rem;
        margin-top: 0.5rem;
    }

    .submitted, .graded-time {
        color: #6b7280;
        font-size: 0.875rem;
    }

    .status-badge {
        padding: 0.25rem 0.75rem;
        border-radius: 1rem;
        font-size: 0.75rem;
        font-weight: 500;

        &.pending {
            background-color: #fef3c7;
            color: #92400e;
        }

        &.graded {
            background-color: #dcfce7;
            color: #166534;
        }
    }

    .loading, .error, .no-results {
        text-align: center;
        color: #6b7280;
        padding: 2rem;
    }

    .error {
        color: #dc2626;
    }

    @media (max-width: 640px) {
        .container {
            padding: 1rem;
        }

        .result-item {
            flex-direction: column;
            gap: 1rem;
        }

        .grades-container {
            flex-direction: column;
            gap: 0.5rem;
        }

        .timestamps {
            flex-direction: column;
            gap: 0.25rem;
        }
    }
</style>