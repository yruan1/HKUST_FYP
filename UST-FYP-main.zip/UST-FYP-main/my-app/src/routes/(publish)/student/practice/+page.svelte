<script lang="ts">
  import { onMount, onDestroy } from 'svelte';
  import { db } from '$lib/firebase';
  import { collection, query, where, onSnapshot, doc, updateDoc } from 'firebase/firestore';
  import SearchHeader from '$lib/components/SearchHeader.svelte';
  import SubheadingBar from '$lib/components/SubheadingBar.svelte';
  import UnderscoreDiv from '$lib/components/UnderscoreDiv.svelte';
  import { getCurrentUserIdFromCookie } from '$lib/utils/auth';
  interface GrammarSubmission {
      id: string;
      gradedAt: string;
      userID: string;
      grade: string;
      comment?: { 
          content?: { [key: string]: string },
          grammarAnalysis?: {
              [key: string]: {
                  analysis: string;
              }
          }
      };
      practiceQuestions?: string;
      questionsGeneratedAt?: string;
      topic?: string;
  }

  interface PracticeQuestion {
      id: string;
      question: string;
      options: string[];
      correctAnswer: number; // Index of correct option
      explanation: string;
      isPlaceholder?: boolean;
  }

  let grammarSubmissions: GrammarSubmission[] = [];
  let loading = true;
  let userId: string | null = null;
  let unsubscribe: () => void;
  let generatingQuestions: { [key: string]: boolean } = {};
  
  // Track student answers and whether questions have been answered
  let studentAnswers: { [key: string]: { [questionId: string]: number | null } } = {};
  let questionsAnswered: { [key: string]: { [questionId: string]: boolean } } = {};
  
  // Error handling and status messages
  let generationError: { [key: string]: string } = {};
  let generationStatus: { [key: string]: string } = {};
  
  // Pagination and navigation
  let currentQuestionIndex: { [key: string]: number } = {};
  
  // Grammar topics for display
  const defaultTopic = "General Grammar";
  
  // Function to generate questions using GPT API
  async function generateQuestions(submission: GrammarSubmission) {
    try {
        generatingQuestions[submission.id] = true;
        generationStatus[submission.id] = "Analyzing your grammar errors...";
        
        // Extract grammar analysis from the appropriate field
        let grammarAnalysis = '';
        
        // Try to get it from comment.grammarAnalysis structure shown in the image
        if (submission.comment && submission.comment.grammarAnalysis) {
            // Log what we're extracting from
            console.log("Found grammarAnalysis field:", submission.comment.grammarAnalysis);
            
            // It appears to be an object with nested structure
            if (typeof submission.comment.grammarAnalysis === 'object') {
                // Extract from the "analysis" field shown in the image
                const analysisEntries = Object.entries(submission.comment.grammarAnalysis)
                    .filter(([key, value]) => value && typeof value === 'object' && 'analysis' in value);
                
                grammarAnalysis = analysisEntries
                    .map(([key, value]) => value.analysis)
                    .filter(Boolean)
                    .join('\n\n');
                
                console.log("Extracted grammar analysis from comment.grammarAnalysis:", grammarAnalysis);
            }
        }
        
        // Fallback to comment.content if grammarAnalysis is not available
        if (!grammarAnalysis && submission.comment && submission.comment.content) {
            console.log("Falling back to content field");
            const contentValues = Object.values(submission.comment.content);
            grammarAnalysis = contentValues
                .filter(text => typeof text === 'string')
                .join('\n\n');
            
            console.log("Extracted grammar analysis from comment.content:", grammarAnalysis);
        }
        
        if (!grammarAnalysis) {
            console.warn("No grammar analysis found in submission:", submission);
        }
        
        generationStatus[submission.id] = "Creating personalized practice questions...";
        
        // Determine the most relevant grammar topic from the analysis
        const topicKeywords = {
            "Verb Tenses": ["present tense", "past tense", "future tense", "perfect tense", "continuous", "tense"],
            "Prepositions": ["preposition", "in", "on", "at", "for", "with", "by", "about", "under", "over"],
            "Articles": ["article", "a", "an", "the", "definite article", "indefinite article"],
            "Pronouns": ["pronoun", "he", "she", "it", "they", "we", "you", "I", "me", "him", "her", "them", "us"],
            "Subject-Verb Agreement": ["agreement", "subject verb", "singular", "plural", "matches"],
            "Word Order": ["word order", "sentence structure", "syntax", "arrangement"],
            "Conjunctions": ["conjunction", "and", "but", "or", "because", "although", "however"],
            "Adjectives and Adverbs": ["adjective", "adverb", "describe", "modify", "qualifier", "comparative", "superlative"]
        };
        
        let detectedTopic = defaultTopic;
        let highestMatchCount = 0;
        
        if (grammarAnalysis) {
            const lowercaseAnalysis = grammarAnalysis.toLowerCase();
            
            for (const [topic, keywords] of Object.entries(topicKeywords)) {
                const matchCount = keywords.reduce((count, keyword) => {
                    // Count how many times this keyword appears in the analysis
                    const regex = new RegExp('\\b' + keyword + '\\b', 'gi');
                    const matches = lowercaseAnalysis.match(regex);
                    return count + (matches ? matches.length : 0);
                }, 0);
                
                if (matchCount > highestMatchCount) {
                    highestMatchCount = matchCount;
                    detectedTopic = topic;
                }
            }
        }
        
        const response = await fetch('/api/practice', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                resultId: submission.id,
                grammarAnalysis: grammarAnalysis,
                enhancedExplanations: true, // Request more detailed explanations
                topic: detectedTopic
            })
        });

        if (!response.ok) {
            const errorText = await response.text();
            console.error("API Error:", errorText);
            throw new Error(`Failed to generate questions: ${errorText}`);
        }

        const data = await response.json();
        console.log("API response:", data);
        
        if (data.success) {
            // Initialize student answers for this submission
            studentAnswers[submission.id] = {};
            questionsAnswered[submission.id] = {};
            currentQuestionIndex[submission.id] = 0;
            
            // Save to Firestore
            generationStatus[submission.id] = "Saving your practice set...";
            try {
                const submissionRef = doc(db, 'examResult', submission.id);
                await updateDoc(submissionRef, {
                    practiceQuestions: data.questions,
                    questionsGeneratedAt: new Date().toISOString(),
                    topic: detectedTopic
                });
                console.log("Questions saved to Firestore");
                
                // Update local submission
                submission.topic = detectedTopic;
                
            } catch (err) {
                console.error("Failed to update Firestore:", err);
            }
            
            generationStatus[submission.id] = "";
            return data.questions;
        } else {
            throw new Error(data.error || 'Failed to generate questions');
        }
    } catch (error) {
        console.error('Error generating questions:', error);
        generationError[submission.id] = error.message || "Failed to generate questions. Please try again.";
        return null;
    } finally {
        generatingQuestions[submission.id] = false;
        generationStatus = {...generationStatus};
        generationError = {...generationError};
    }
  }
  
  // Extract grammar analysis from either data structure
  function extractGrammarAnalysis(submission: GrammarSubmission): string {
      if (!submission.comment) {
          return '';
      }
      
      // Try to extract from grammarAnalysis field first (as shown in your image)
      if (submission.comment.grammarAnalysis) {
          try {
              const analysisEntries = Object.entries(submission.comment.grammarAnalysis)
                  .filter(([key, value]) => value && typeof value === 'object' && 'analysis' in value);
              
              if (analysisEntries.length > 0) {
                  return analysisEntries
                      .map(([key, value]) => value.analysis)
                      .filter(Boolean)
                      .join('\n\n');
              }
          } catch (err) {
              console.error("Error extracting from grammarAnalysis:", err);
          }
      }
      
      // Fallback to content field
      if (submission.comment.content) {
          return Object.values(submission.comment.content)
              .map(text => typeof text === 'string' ? text.replace(/\*\*Score.*?\*\*/i, '').trim() : '')
              .filter(Boolean)
              .join('\n\n');
      }
      
      return '';
  }
  
  // Parse stored questions 
  function parseQuestions(questionsString: string): PracticeQuestion[] {
      if (!questionsString) {
          return [];
      }
      
      try {
          const questions = JSON.parse(questionsString);
          if (Array.isArray(questions)) {
              return questions.map((q, index) => ({
                  id: q.id || `q${index}`,
                  question: q.question || "Missing question text",
                  options: Array.isArray(q.options) ? q.options : ["Option A", "Option B", "Option C", "Option D"],
                  correctAnswer: typeof q.correctAnswer === 'number' ? q.correctAnswer : 0,
                  explanation: q.explanation || `The correct answer is ${q.options?.[q.correctAnswer] || "Option A"}.`,
                  grammarRule: q.grammarRule || "",
                  detailedExplanation: q.detailedExplanation || "",
                  examples: Array.isArray(q.examples) ? q.examples : []
              }));
          }
          return [];
      } catch (error) {
          console.error("Error parsing questions:", error);
          return [];
      }
  }
  
  // Navigate to a specific question
  function navigateToQuestion(submissionId: string, questionIndex: number) {
      if (questionIndex >= 0 && questionIndex < parseQuestions(grammarSubmissions.find(s => s.id === submissionId)?.practiceQuestions || "").length) {
          currentQuestionIndex[submissionId] = questionIndex;
          currentQuestionIndex = {...currentQuestionIndex};
      }
  }
  
  // Handle student selecting an answer
  function selectAnswer(submissionId: string, questionId: string, answerIndex: number) {
      if (questionsAnswered[submissionId]?.[questionId]) {
          return; // Don't allow changing answer after submission
      }
      
      if (!studentAnswers[submissionId]) {
          studentAnswers[submissionId] = {};
      }
      
      studentAnswers[submissionId][questionId] = answerIndex;
      
      // Force reactivity
      studentAnswers = {...studentAnswers};
  }

  // Submit the student's answer
  function submitAnswer(submissionId: string, questionId: string) {
      if (!questionsAnswered[submissionId]) {
          questionsAnswered[submissionId] = {};
      }
      
      questionsAnswered[submissionId][questionId] = true;
      
      // Force reactivity
      questionsAnswered = {...questionsAnswered};
  }

  // Get user ID from cookie
  function getUserIdFromCookie(): string | null {
      if (typeof document !== 'undefined') {
          const cookies = document.cookie.split(';');
          let target = cookies.filter((data) => data.includes('uid='));
          if (target.length > 0) {
              return target[0].split('=')[1];
          }
      }
      return null;
  }

  // Set up real-time Firestore listener
  function setupRealtimeSubmissions() {
      const examResultCollection = collection(db, 'examResult');
      const userQuery = query(examResultCollection, where('userID', '==', userId));

      unsubscribe = onSnapshot(
          userQuery,
          (snapshot) => {
              grammarSubmissions = snapshot.docs.map((doc) => {
                  const data = doc.data();
                  return {
                      id: doc.id,
                      gradedAt: data.gradedAt || '',
                      userID: data.userID,
                      grade: data.grade || '',
                      comment: data.comment,
                      practiceQuestions: data.practiceQuestions,
                      questionsGeneratedAt: data.questionsGeneratedAt,
                      topic: data.topic || defaultTopic
                  };
              });
              
              // Initialize tracking objects for each submission
              grammarSubmissions.forEach(submission => {
                  if (submission.id && !studentAnswers[submission.id]) {
                      studentAnswers[submission.id] = {};
                  }
                  if (submission.id && !questionsAnswered[submission.id]) {
                      questionsAnswered[submission.id] = {};
                  }
                  if (submission.id && currentQuestionIndex[submission.id] === undefined) {
                      currentQuestionIndex[submission.id] = 0;
                  }
              });
              
              loading = false;
          },
          (error) => {
              console.error('Error fetching submissions:', error);
              loading = false;
          }
      );
  }

  onMount(() => {
      userId = getCurrentUserIdFromCookie();
      if (!userId) {
          console.error('No user ID found in cookie');
          return;
      }
      setupRealtimeSubmissions();
  });

  onDestroy(() => {
      if (unsubscribe) {
          unsubscribe();
      }
  });
</script>

<main>

  <div class="container">
      <UnderscoreDiv>
      </UnderscoreDiv>

      <UnderscoreDiv>
          <div class="practice-grid">
              {#if loading}
                  <div class="loading-skeleton">
                      <div class="skeleton-card" />
                      <div class="skeleton-card" />
                  </div>
              {:else if grammarSubmissions.length === 0}
                  <div class="empty-submissions">
                      <div class="empty-content">
                          <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="empty-icon">
                              <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"></path>
                              <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"></path>
                          </svg>
                          <h3>No Practice Sets Yet</h3>
                          <p>Complete a grammar test to generate personalized practice questions based on your errors.</p>
                      </div>
                  </div>
              {:else}
                  {#each grammarSubmissions as submission}
                      <div class="practice-card">
                          {#if generationStatus[submission.id]}
                              <div class="generation-status">
                                  <div class="status-spinner"></div>
                                  <p>{generationStatus[submission.id]}</p>
                              </div>
                          {/if}
                          
                          {#if generationError[submission.id]}
                              <div class="error-message">
                                  <p>{generationError[submission.id]}</p>
                                  <button class="dismiss-btn" on:click={() => {
                                      generationError[submission.id] = '';
                                      generationError = {...generationError};
                                  }}>Dismiss</button>
                              </div>
                          {/if}
                          
                          <!-- Practice questions section -->
                          {#if submission.practiceQuestions}
                              <div class="practice-content">
                                  <div class="practice-header">
                                      <div class="title-section">
                                          <h2 class="main-title">Practice</h2>
                                      </div>
                                      
                                      <div class="practice-header-content">
                                          <p class="practice-instruction">
                                              Test your understanding of English grammar with these practice questions. Select the most appropriate answer for each question.
                                          </p>
                                          
                                          <button 
                                              class="regenerate-btn"
                                              on:click={async () => {
                                                  if (confirm("This will generate a new set of questions and reset your progress. Are you sure?")) {
                                                      const questions = await generateQuestions(submission);
                                                      if (questions) {
                                                          // Update locally
                                                          submission.practiceQuestions = questions;
                                                          submission.questionsGeneratedAt = new Date().toISOString();
                                                          
                                                          // Force a reactive update
                                                          grammarSubmissions = [...grammarSubmissions];
                                                      }
                                                  }
                                              }}
                                              disabled={generatingQuestions[submission.id]}
                                          >
                                              {#if generatingQuestions[submission.id]}
                                                  <span class="loading-spinner"></span>
                                                  <span>Regenerating...</span>
                                              {:else}
                                                  <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="btn-icon">
                                                      <path d="M21.5 2v6h-6M21.34 15.57a10 10 0 1 1-.57-8.38" />
                                                  </svg>
                                                  <span>Regenerate Questions</span>
                                              {/if}
                                          </button>
                                      </div>
                                  </div>
                                  
                                  {#key currentQuestionIndex[submission.id]}
                                      {#if parseQuestions(submission.practiceQuestions).length > 0}
                                          {@const questions = parseQuestions(submission.practiceQuestions)}
                                          {@const currentIndex = currentQuestionIndex[submission.id] || 0}
                                          {@const currentQuestion = questions[currentIndex]}
                                          
                                          <div class="question-navigation">
                                              <span class="question-counter">Question {currentIndex + 1} of {questions.length}</span>
                                              
                                              <div class="pagination">
                                                  {#each questions as _, i}
                                                      <button 
                                                          class="page-number"
                                                          class:active={i === currentIndex}
                                                          class:answered={questionsAnswered[submission.id]?.[questions[i].id]}
                                                          on:click={() => navigateToQuestion(submission.id, i)}
                                                      >
                                                          {i + 1}
                                                      </button>
                                                  {/each}
                                              </div>
                                          </div>
                                          
                                          <div class="question-container">
                                              <div class="question-label">QUESTION {currentIndex + 1}</div>
                                              <p class="question-text">{currentQuestion.question}</p>
                                              
                                              <div class="options-container">
                                                  {#each currentQuestion.options as option, i}
                                                      <label 
                                                          class="option-label"
                                                          class:selected={studentAnswers[submission.id]?.[currentQuestion.id] === i}
                                                          class:correct={questionsAnswered[submission.id]?.[currentQuestion.id] && currentQuestion.correctAnswer === i}
                                                          class:incorrect={questionsAnswered[submission.id]?.[currentQuestion.id] && studentAnswers[submission.id]?.[currentQuestion.id] === i && currentQuestion.correctAnswer !== i}
                                                      >
                                                          <input 
                                                              type="radio" 
                                                              name={`question-${submission.id}-${currentQuestion.id}`}
                                                              value={i}
                                                              checked={studentAnswers[submission.id]?.[currentQuestion.id] === i}
                                                              on:change={() => selectAnswer(submission.id, currentQuestion.id, i)}
                                                              disabled={questionsAnswered[submission.id]?.[currentQuestion.id]}
                                                          />
                                                          <span class="option-marker">{String.fromCharCode(65 + i)}</span>
                                                          <span class="option-text">{option}</span>
                                                      </label>
                                                  {/each}
                                              </div>
                                              
                                              <!-- Explanation if answered -->
                                              {#if questionsAnswered[submission.id]?.[currentQuestion.id]}
                                                  <div class="explanation-section">
                                                      <div class="explanation-content">
                                                          <h4>Explanation</h4>
                                                          <p>{currentQuestion.explanation}</p>
                                                          
                                                          {#if currentQuestion.grammarRule}
                                                              <div class="grammar-rule">
                                                                  <h5>Grammar Rule:</h5>
                                                                  <p>{currentQuestion.grammarRule}</p>
                                                              </div>
                                                          {/if}
                                                          
                                                          {#if currentQuestion.examples && currentQuestion.examples.length > 0}
                                                              <div class="examples">
                                                                  <h5>Examples:</h5>
                                                                  <ul>
                                                                      {#each currentQuestion.examples as example}
                                                                          <li><span class="example-marker">✓</span> {example}</li>
                                                                      {/each}
                                                                  </ul>
                                                              </div>
                                                          {/if}
                                                      </div>
                                                  </div>
                                              {/if}
                                          </div>
                                          
                                          <div class="navigation-buttons">
                                              <button 
                                                  class="nav-btn prev-btn" 
                                                  disabled={currentIndex === 0}
                                                  on:click={() => navigateToQuestion(submission.id, currentIndex - 1)}
                                              >
                                                  Previous
                                              </button>
                                              
                                              {#if !questionsAnswered[submission.id]?.[currentQuestion.id] && studentAnswers[submission.id]?.[currentQuestion.id] !== undefined}
                                                  <button 
                                                      class="nav-btn submit-btn" 
                                                      on:click={() => submitAnswer(submission.id, currentQuestion.id)}
                                                  >
                                                      Submit Answer
                                                  </button>
                                              {/if}
                                              
                                              {#if currentIndex < questions.length - 1}
                                                  <button 
                                                      class="nav-btn next-btn" 
                                                      on:click={() => navigateToQuestion(submission.id, currentIndex + 1)}
                                                  >
                                                      Next
                                                  </button>
                                              {/if}
                                          </div>
                                      {/if}
                                  {/key}
                              </div>
                          {:else}
                              <div class="generate-container">
                                  <div class="empty-state">
                                      <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                                          <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                                          <polyline points="14 2 14 8 20 8"></polyline>
                                          <line x1="12" y1="18" x2="12" y2="12"></line>
                                          <line x1="9" y1="15" x2="15" y2="15"></line>
                                      </svg>
                                      
                                      <button 
                                          class="generate-btn"
                                          on:click={async () => {
                                              const questions = await generateQuestions(submission);
                                              if (questions) {
                                                  // Update locally
                                                  submission.practiceQuestions = questions;
                                                  submission.questionsGeneratedAt = new Date().toISOString();
                                                  
                                                  // Force a reactive update
                                                  grammarSubmissions = [...grammarSubmissions];
                                              }
                                          }}
                                          disabled={generatingQuestions[submission.id]}
                                      >
                                          {#if generatingQuestions[submission.id]}
                                              <span class="loading-spinner"></span>
                                              <span>Generating...</span>
                                          {:else}
                                              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="btn-icon">
                                                  <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon>
                                              </svg>
                                              <span>Generate Practice Questions</span>
                                          {/if}
                                      </button>
                                  </div>
                              </div>
                          {/if}
                      </div>
                  {/each}
              {/if}
          </div>
      </UnderscoreDiv>
  </div>
</main>

<style lang="scss">
  main {
    position: relative;
    height: 100%;
    width: 100%;
    background-color: var(--clr-content-background);
    font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  }

  .container {
    padding: 10px max(20px, 5%);
    max-width: 1400px;
    margin: 0 auto;
  }

  .practice-grid {
    display: grid;
    grid-template-columns: 1fr;
    gap: 2rem;
    padding: 1.5rem;
  }

  .practice-card {
    background: white;
    border-radius: 12px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
    overflow: hidden;
  }
  
  .practice-content {
    padding: 0;
  }
  
  .practice-header {
    padding: 1.5rem 1.5rem 1rem;
  }
  
  .title-section {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    margin-bottom: 0.75rem;
  }
  
  .practice-header-content {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 1rem;
  }
  
  .main-title {
    font-size: 1.75rem;
    font-weight: 600;
    color: #5747e4;
    margin: 0;
  }
  
  .practice-instruction {
    color: #4b5563;
    font-size: 1rem;
    line-height: 1.5;
    margin: 0;
    flex: 1;
  }
  
  .regenerate-btn {
    background-color: transparent;
    color: #5747e4;
    border: 1px solid #5747e4;
    border-radius: 6px;
    padding: 0.5rem 1rem;
    font-size: 0.85rem;
    font-weight: 500;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 0.4rem;
    white-space: nowrap;
    transition: all 0.2s;
    
    &:hover:not(:disabled) {
      background-color: rgba(87, 71, 228, 0.05);
    }
    
    &:active:not(:disabled) {
      transform: translateY(1px);
    }
    
    &:disabled {
      opacity: 0.5;
      cursor: not-allowed;
    }
    
    .btn-icon {
      flex-shrink: 0;
    }
  }
  
  .question-navigation {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0.75rem 1.5rem;
    border-bottom: 1px solid #f3f4f6;
  }
  
  .question-counter {
    font-size: 0.9rem;
    font-weight: 500;
    color: #374151;
  }
  
  .pagination {
    display: flex;
    gap: 0.5rem;
  }
  
  .page-number {
    width: 32px;
    height: 32px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    font-size: 0.85rem;
    font-weight: 500;
    background-color: #f9fafb;
    color: #6b7280;
    border: none;
    cursor: pointer;
    
    &.active {
      background-color: #5747e4;
      color: white;
    }
    
    &.answered {
      background-color: #dcfce7;
      color: #047857;
    }
    
    &:hover:not(.active) {
      background-color: #f3f4f6;
    }
  }
  
  .question-container {
    padding: 1.5rem;
  }
  
  .question-label {
    font-size: 0.8rem;
    font-weight: 600;
    letter-spacing: 0.05em;
    color: #5747e4;
    margin-bottom: 0.75rem;
  }
  
  .question-text {
    font-size: 1.1rem;
    line-height: 1.5;
    color: #111827;
    margin-bottom: 1.5rem;
  }
  
  .options-container {
    display: flex;
    flex-direction: column;
    gap: 0.75rem;
    margin-bottom: 1.5rem;
  }
  
  .option-label {
    display: flex;
    align-items: center;
    padding: 0.75rem 1rem;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.15s ease;
    
    input[type="radio"] {
      position: absolute;
      opacity: 0;
      width: 0;
      height: 0;
    }
    
    &:hover {
      background-color: #f9fafb;
    }
    
    &.selected {
      border-color: #5747e4;
      background-color: rgba(87, 71, 228, 0.05);
    }
    
    &.correct {
      border-color: #10b981;
      background-color: rgba(16, 185, 129, 0.1);
    }
    
    &.incorrect {
      border-color: #ef4444;
      background-color: rgba(239, 68, 68, 0.1);
    }
  }
  
  .option-marker {
    width: 28px;
    height: 28px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    background-color: #f3f4f6;
    color: #4b5563;
    font-weight: 600;
    font-size: 0.85rem;
    margin-right: 0.75rem;
    
    .selected & {
      background-color: #5747e4;
      color: white;
    }
    
    .correct & {
      background-color: #10b981;
      color: white;
    }
    
    .incorrect & {
      background-color: #ef4444;
      color: white;
    }
  }
  
  .option-text {
    font-size: 1rem;
    color: #374151;
    
    .correct & {
      color: #047857;
    }
    
    .incorrect & {
      color: #b91c1c;
    }
  }
  
  .explanation-section {
    margin-top: 1.5rem;
    padding-top: 1.5rem;
    border-top: 1px solid #f3f4f6;
  }
  
  .explanation-content {
    background-color: #f9fafb;
    padding: 1.25rem;
    border-radius: 8px;
    
    h4 {
      font-size: 1rem;
      font-weight: 600;
      color: #111827;
      margin: 0 0 0.75rem;
    }
    
    p {
      font-size: 0.95rem;
      line-height: 1.6;
      color: #374151;
      margin: 0 0 1rem;
    }
    
    .grammar-rule, .examples {
      margin-top: 1rem;
      padding-top: 1rem;
      border-top: 1px solid #e5e7eb;
      
      h5 {
        font-size: 0.9rem;
        font-weight: 600;
        color: #4b5563;
        margin: 0 0 0.5rem;
      }
      
      p {
        margin-bottom: 0;
      }
    }
    
    .examples {
      ul {
        margin: 0.75rem 0 0;
        padding-left: 0;
        list-style-type: none;
        
        li {
          position: relative;
          padding-left: 1.5rem;
          margin-bottom: 0.5rem;
          font-size: 0.95rem;
          line-height: 1.5;
          color: #374151;
          
          &:last-child {
            margin-bottom: 0;
          }
          
          .example-marker {
            position: absolute;
            left: 0;
            color: #10b981;
          }
        }
      }
    }
  }
  
  .navigation-buttons {
    display: flex;
    justify-content: space-between;
    padding: 1rem 1.5rem 1.5rem;
    
    .nav-btn {
      padding: 0.65rem 1.25rem;
      font-size: 0.95rem;
      font-weight: 500;
      border-radius: 6px;
      cursor: pointer;
      transition: all 0.15s ease;
      border: none;
      
      &:disabled {
        opacity: 0.5;
        cursor: not-allowed;
      }
    }
    
    .prev-btn, .next-btn {
      background-color: #f3f4f6;
      color: #4b5563;
      
      &:hover:not(:disabled) {
        background-color: #e5e7eb;
      }
    }
    
    .submit-btn {
      background-color: #5747e4;
      color: white;
      
      &:hover:not(:disabled) {
        background-color: #4338ca;
      }
    }
  }
  
  .generation-status {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    padding: 0.75rem 1rem;
    background-color: #f0f9ff;
    margin-bottom: 1rem;
    
    p {
      margin: 0;
      color: #0369a1;
      font-size: 0.95rem;
    }
    
    .status-spinner {
      width: 16px;
      height: 16px;
      border: 2px solid #0ea5e9;
      border-radius: 50%;
      border-top-color: transparent;
      animation: spin 1s linear infinite;
    }
  }
  
  .error-message {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0.75rem 1rem;
    background-color: #fef2f2;
    margin-bottom: 1rem;
    
    p {
      margin: 0;
      color: #b91c1c;
      font-size: 0.95rem;
    }
    
    .dismiss-btn {
      background: none;
      border: none;
      color: #b91c1c;
      font-size: 0.85rem;
      cursor: pointer;
      padding: 0.25rem 0.5rem;
      
      &:hover {
        text-decoration: underline;
      }
    }
  }
  
  .generate-container {
    padding: 2rem;
  }

  .empty-state {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 1.5rem;
    padding: 2.5rem 2rem;
    
    svg {
      color: #9ca3af;
    }
  }

  .empty-submissions {
    grid-column: 1 / -1;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 3rem 1rem;
    background-color: #f9fafb;
    border-radius: 0.75rem;
    min-height: 200px;
    border: 1px dashed #e5e7eb;
    
    .empty-content {
      text-align: center;
      max-width: 400px;
      
      .empty-icon {
        color: #94a3b8;
        margin-bottom: 1rem;
      }
      
      h3 {
        color: #475569;
        font-size: 1.25rem;
        margin: 0 0 0.5rem;
      }
      
      p {
        color: #64748b;
        margin: 0;
        font-size: 0.95rem;
        line-height: 1.5;
      }
    }
  }

  .loading-spinner {
    display: inline-block;
    width: 16px;
    height: 16px;
    border: 2px solid rgba(255,255,255,0.3);
    border-radius: 50%;
    border-top-color: #fff;
    animation: spin 1s ease-in-out infinite;
    margin-right: 8px;
  }

  @keyframes spin {
    to { transform: rotate(360deg); }
  }

  .generate-btn {
    background-color: #5747e4;
    color: white;
    padding: 0.75rem 1.5rem;
    border-radius: 6px;
    border: none;
    cursor: pointer;
    font-weight: 500;
    transition: all 0.2s;
    font-size: 0.95rem;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
    min-width: 220px;

    .btn-icon {
      flex-shrink: 0;
    }

    &:hover {
      background-color: #4338ca;
    }

    &:active {
      transform: translateY(1px);
    }

    &:disabled {
      background-color: #9ca3af;
      cursor: not-allowed;
      transform: none;
    }
  }

  .loading-skeleton {
    display: grid;
    grid-template-columns: 1fr;
    gap: 1.5rem;

    .skeleton-card {
      background: linear-gradient(110deg, #f0f0f0 8%, #f9f9f9 18%, #f0f0f0 33%);
      border-radius: 12px;
      height: 550px;
      background-size: 200% 100%;
      animation: shimmer 1.5s linear infinite;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
    }
  }

  @keyframes shimmer {
    0% {
      background-position: 200% 0;
    }
    100% {
      background-position: -200% 0;
    }
  }

  @media (max-width: 768px) {
    .container {
      padding: 10px;
    }

    .practice-grid {
      padding: 1rem 0.5rem;
      gap: 1.25rem;
    }
    
    .practice-header {
      padding: 1.25rem 1rem 0.75rem;
    }
    
    .main-title {
      font-size: 1.5rem;
    }
    
    .practice-header-content {
      flex-direction: column;
      align-items: flex-start;
      
      .practice-instruction {
        margin-bottom: 1rem;
      }
    }
    
    .question-navigation {
      padding: 0.5rem 1rem;
      flex-direction: column;
      gap: 0.5rem;
      align-items: flex-start;
    }
    
    .question-container {
      padding: 1rem;
    }
    
    .navigation-buttons {
      padding: 1rem;
      flex-wrap: wrap;
      gap: 0.5rem;
      
      .nav-btn {
        flex: 1;
        padding: 0.5rem 1rem;
        font-size: 0.9rem;
        min-width: fit-content;
      }
    }
  }
</style>
