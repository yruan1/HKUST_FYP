import { error, json } from '@sveltejs/kit';
import type { PageServerLoad } from './$types';

export const load:PageServerLoad = async({ cookies, fetch }) => {
    let uid = cookies.get('uid');
    let url = '/api/student/announcement';
	const response =  await fetch(url);

    if (!response.ok) {
        throw error(response.status, 'Failed to fetch user data');
    }
    console.log(response);
    const data = await response.json();
    return {announcements : data.announcements}
}