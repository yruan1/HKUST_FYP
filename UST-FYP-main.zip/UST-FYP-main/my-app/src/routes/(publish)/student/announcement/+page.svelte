<script lang="ts">
    import AnnouncementTable from '$lib/components/AnnouncementTable.svelte';
    export let data;
  </script>
  
  <main>
    <h1>Announcement</h1>
    <AnnouncementTable announcements = {Object.values(data.announcements)}/>
  </main>