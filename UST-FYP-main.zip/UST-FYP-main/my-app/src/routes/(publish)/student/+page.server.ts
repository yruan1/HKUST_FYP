import { error } from '@sveltejs/kit';
export async function load({ fetch, parent }) {
    const parentData = await parent();
    const classData = parentData.userInfo.class;
    let url = '/api/teacher/announcement?class=' + classData;
	const response =  await fetch(url);

    if (!response.ok) {
        throw error(response.status, 'Failed to fetch user data');
    }

    const data = await response.json();
    return {
        announcements : data,
    }
}