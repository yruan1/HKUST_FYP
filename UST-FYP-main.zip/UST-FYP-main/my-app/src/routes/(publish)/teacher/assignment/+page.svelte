<script lang="ts">
    import { page } from '$app/stores';
    import SearchHeader from '$lib/components/SearchHeader.svelte';
    import SubheadingBar from '$lib/components/SubheadingBar.svelte';
    import UnderscoreDiv from '$lib/components/UnderscoreDiv.svelte';
    import { onMount } from 'svelte';
    import { db } from '$lib/firebase';
    import { collection, query, where, getDocs, doc, getDoc, addDoc, deleteDoc } from 'firebase/firestore';
    import { goto } from '$app/navigation';
    import { getCurrentUserIdFromCookie } from '$lib/utils/auth';

    const courseId = $page.params.id || 'default-course';
    let courseIdForAssignment = courseId; 

    let userLoading = true;
    let userDetails = null;
    let userId: string | null = null;
    let teacherClass = "";
    let viewMode = "assignments"; 
    let pendingSubmissions = new Map(); 
    let totalPendingSubmissions = 0;
    let loadingSubmissions = false;

    let deletingAssignmentId: string | null = null;
    let showDeleteConfirmation = false;
    let deleteError = "";
    let deleteSuccess = "";
    let currentAssignmentToDelete: Assignment | null = null;

    interface Assignment {
        id: string;
        title: string;
        description: string;
        dueDate: string;
        publishDate: string;
        status: 'completed' | 'in-progress' | 'not-started' | 'closed';
        maxAttempts?: number;
        wordLimit?: number; 
        class?: string;
        pendingCount?: number; 
        totalSubmissions?: number; 
    }

    interface StudentSubmission {
        id: string;
        userId: string;
        userName: string;
        userClass: string;
        assignmentId: string;
        assignmentTitle: string;
        submittedAt: string;
        status: string;
        graded: boolean;
        teacherGrade?: string;
    }

    interface Course {
        id: string;
        title: string;
        institution: string;
        year: number;
    }

    interface NewAssignment {
        title: string;
        description: string;
        publishDate: string;
        dueDate: string;
        question: string;
        maxAttempts: number; 
        wordLimit: number; 
        courseId: string;
        class: string;
    }

    let assignments: Assignment[] = [];
    let filteredAssignments: Assignment[] = [];
    let studentSubmissions: StudentSubmission[] = [];
    let filteredSubmissions: StudentSubmission[] = [];
    let course: Course | null = null;
    let loading = true;
    let showCreateForm = false;
    let creatingAssignment = false;
    let createError = "";
    let createSuccess = false;

    let newAssignment: NewAssignment = {
        title: "",
        description: "",
        publishDate: new Date().toISOString().split('T')[0],
        dueDate: "",
        question: "",
        maxAttempts: 3,
        wordLimit: 500, 
        courseId: courseId,
        class: ""
    };

    $: {
        if (!newAssignment.dueDate) {
            const twoWeeksFromNow = new Date();
            twoWeeksFromNow.setDate(twoWeeksFromNow.getDate() + 14);
            newAssignment.dueDate = twoWeeksFromNow.toISOString().split('T')[0];
        }
    }

    function confirmDeleteAssignment(assignment: Assignment, event: MouseEvent) {
        event.stopPropagation();
        
        currentAssignmentToDelete = assignment;
        showDeleteConfirmation = true;
    }
    
    function cancelDeleteAssignment() {
        currentAssignmentToDelete = null;
        showDeleteConfirmation = false;
    }
    
    async function deleteAssignment() {
        if (!currentAssignmentToDelete) {
            return;
        }
        
        const assignmentId = currentAssignmentToDelete.id;
        deletingAssignmentId = assignmentId;
        deleteError = "";
        deleteSuccess = "";
        
        try {
            const assignmentRef = doc(db, 'assignments', assignmentId);
            
            await deleteDoc(assignmentRef);
            
            const submissionsQuery = query(
                collection(db, 'assignmentResult'),
                where('assignmentId', '==', assignmentId)
            );
            
            const submissionsSnapshot = await getDocs(submissionsQuery);
            
            const deletionPromises = submissionsSnapshot.docs.map(submissionDoc => {
                return deleteDoc(doc(db, 'assignmentResult', submissionDoc.id));
            });
            
            await Promise.all(deletionPromises);
            
            assignments = assignments.filter(a => a.id !== assignmentId);
            
            filterAssignments();
            
            deleteSuccess = `Assignment "${currentAssignmentToDelete.title}" has been successfully deleted.`;
            
            showDeleteConfirmation = false;
            currentAssignmentToDelete = null;
            
            setTimeout(() => {
                deleteSuccess = "";
            }, 3000);
            
        } catch (error) {
            console.error("Error deleting assignment:", error);
            deleteError = "Error deleting assignment. Please try again.";
            
            if (error.message && (error.message.includes("permission-denied") || error.code === "permission-denied")) {
                assignments = assignments.filter(a => a.id !== assignmentId);
                filterAssignments();
                
                deleteSuccess = `Assignment removed from view (Note: Actual deletion from database requires proper permissions)`;
                deleteError = "";
                
                showDeleteConfirmation = false;
                currentAssignmentToDelete = null;
                
                setTimeout(() => {
                    deleteSuccess = "";
                }, 5000);
            }
            
        } finally {
            deletingAssignmentId = null;
        }
    }

    function filterAssignments() {
        if (teacherClass) {
            filteredAssignments = assignments.filter(assignment => 
                assignment.class === teacherClass
            );
        } else {
            filteredAssignments = [...assignments];
        }
        
        filteredAssignments.sort((a, b) => {
            return new Date(b.dueDate).getTime() - new Date(a.dueDate).getTime();
        });
    }
    
    function filterSubmissions() {
        if (teacherClass) {
            filteredSubmissions = studentSubmissions.filter(submission => 
                submission.userClass === teacherClass
            );
        } else {
            filteredSubmissions = [...studentSubmissions];
        }
        
        filteredSubmissions.sort((a, b) => {
            return new Date(b.submittedAt).getTime() - new Date(a.submittedAt).getTime();
        });
    }
    
    function toggleViewMode(mode) {
        viewMode = mode;
        
        if (mode === "submissions") {
            fetchStudentSubmissions();
        }
    }

    function getUserIdFromCookie(): string | null {
        if (typeof document !== 'undefined') {
            const cookies = document.cookie.split('=');
            if (cookies.length >= 2) {
                return cookies[1];
            }
        }
        return null;
    }

    async function checkUserRole() {
        try {
            userLoading = true;
            const uid = getCurrentUserIdFromCookie();
            
            if (!uid) {
                goto('/student/assignment');
                return;
            }
            
            userId = uid;
            
            const userRef = doc(db, 'users', uid);
            const userSnap = await getDoc(userRef);
            
            if (userSnap.exists()) {
                const userData = userSnap.data();
                userDetails = userData;
                
                const userRole = userData.role || 'student';
                const isTeacher = userRole === 'teacher' || userRole === 'admin';
                
                if (!isTeacher) {
                    goto('/student/assignment');
                    return;
                }
                
                teacherClass = userData.class || "";
                console.log("Teacher's class:", teacherClass);
                
                newAssignment.class = teacherClass;
            } else {
                goto('/student/assignment');
            }
        } catch (error) {
            console.error("Error checking user role:", error);
            goto('/student/assignment');
        } finally {
            userLoading = false;
        }
    }

    function determineAssignmentStatus(publishDate: string, dueDate: string): 'not-started' | 'in-progress' | 'closed' {
        const now = new Date();
        const publish = new Date(publishDate);
        const due = new Date(dueDate);
        
        if (now > due) {
            return 'closed';
        } else if (now >= publish && now <= due) {
            return 'in-progress';
        } else {
            return 'not-started';
        }
    }
    
   
async function fetchPendingSubmissionsCount() {
    pendingSubmissions = new Map(); 
    let totalSubmissions = new Map(); 
    totalPendingSubmissions = 0;
    
    try {
        console.log("Fetching submission counts...");
        
        const submissionsQuery = query(
            collection(db, 'assignmentResult'),
            where('courseId', '==', courseIdForAssignment)
        );
        
        console.log("Query parameters:", courseIdForAssignment);
        
        const snapshot = await getDocs(submissionsQuery);
        
        console.log(`Found ${snapshot.size} total submissions`);
        
        if (!snapshot.empty) {
            let userDataCache = new Map();
            
            for (const docSnapshot of snapshot.docs) {
                const data = docSnapshot.data();
                const assignmentId = data.assignmentId;
                const userId = data.userId;
                
                if (!assignmentId) {
                    console.log("Skipping submission with no assignmentId");
                    continue;
                }
                
                if (!userId) {
                    console.log("Skipping submission with no userId");
                    continue;
                }
                
                console.log(`Processing submission for user ${userId}, assignment ${assignmentId}`);
                
                let userClass = null;
                
                if (userDataCache.has(userId)) {
                    userClass = userDataCache.get(userId);
                } else {
                    try {
                        const userRef = doc(db, 'users', userId);
                        const userSnap = await getDoc(userRef);
                        
                        if (userSnap.exists()) {
                            userClass = userSnap.data().class || null;
                            userDataCache.set(userId, userClass);
                            console.log(`User ${userId} has class ${userClass}`);
                        } else {
                            console.log(`User ${userId} not found`);
                        }
                    } catch (e) {
                        console.error("Error fetching user data:", e);
                    }
                }
                
                if (userClass === teacherClass) {
                    console.log(`Counting submission for assignment ${assignmentId} from class ${userClass}`);
                    
                    const currentTotal = totalSubmissions.get(assignmentId) || 0;
                    totalSubmissions.set(assignmentId, currentTotal + 1);
                    
                    if (!data.teacherGrade) {
                        const currentCount = pendingSubmissions.get(assignmentId) || 0;
                        pendingSubmissions.set(assignmentId, currentCount + 1);
                        
                        totalPendingSubmissions++;
                    }
                } else {
                    console.log(`Skipping submission from class ${userClass} (teacher's class is ${teacherClass})`);
                }
            }
            
            console.log("Submission counts by assignment ID:");
            for (const [assignmentId, count] of totalSubmissions.entries()) {
                console.log(`Assignment ${assignmentId}: ${count} submissions, ${pendingSubmissions.get(assignmentId) || 0} pending`);
            }
            
            assignments = assignments.map(assignment => {
                const totalCount = totalSubmissions.get(assignment.id) || 0;
                const pendingCount = pendingSubmissions.get(assignment.id) || 0;
                
                console.log(`Updating assignment ${assignment.id}: ${totalCount} submissions, ${pendingCount} pending`);
                
                return {
                    ...assignment,
                    pendingCount: pendingCount,
                    totalSubmissions: totalCount
                };
            });
            
            console.log("Updated assignments with submission counts:", assignments);
        }
    } catch (error) {
        console.error("Error fetching pending submissions:", error);
    }
}
    
    async function fetchStudentSubmissions() {
        loadingSubmissions = true;
        studentSubmissions = [];
        filteredSubmissions = [];
        
        try {
            const submissionsQuery = query(
                collection(db, 'assignmentResult'),
                where('courseId', '==', courseIdForAssignment)
            );
            
            const submissionsSnapshot = await getDocs(submissionsQuery);
            
            if (!submissionsSnapshot.empty) {
                const userDataCache = new Map();
                const assignmentCache = new Map();
                const uniqueSubmissionKeys = new Set();
                
                for (const submissionDoc of submissionsSnapshot.docs) {
                    const data = submissionDoc.data();
                    
                    if (!data.userId || !data.assignmentId) {
                        continue;
                    }
                    
                    const submissionKey = `${data.userId}-${data.assignmentId}`;
                    
                    if (uniqueSubmissionKeys.has(submissionKey)) {
                        continue;
                    }
                    
                    uniqueSubmissionKeys.add(submissionKey);
                    
                    let userName = "Unknown Student";
                    let userClass = "Unknown Class";
                    
                    if (userDataCache.has(data.userId)) {
                        const cachedUserData = userDataCache.get(data.userId);
                        userName = cachedUserData.name;
                        userClass = cachedUserData.class;
                    } else {
                        try {
                            const userRef = doc(db, 'users', data.userId);
                            const userSnap = await getDoc(userRef);
                            
                            if (userSnap.exists()) {
                                const userData = userSnap.data();
                                userName = `${userData.firstName || ''} ${userData.lastName || ''}`.trim() || "Unknown Student";
                                userClass = userData.class || "Unknown Class";
                                
                                userDataCache.set(data.userId, { 
                                    name: userName, 
                                    class: userClass 
                                });
                            }
                        } catch (e) {
                            console.error("Error fetching user data:", e);
                        }
                    }
                    
                    let assignmentTitle = "Unknown Assignment";
                    
                    if (assignmentCache.has(data.assignmentId)) {
                        assignmentTitle = assignmentCache.get(data.assignmentId);
                    } else {
                        try {
                            const assignmentRef = doc(db, 'assignments', data.assignmentId);
                            const assignmentSnap = await getDoc(assignmentRef);
                            
                            if (assignmentSnap.exists()) {
                                assignmentTitle = assignmentSnap.data().title || "Unknown Assignment";
                                
                                assignmentCache.set(data.assignmentId, assignmentTitle);
                            }
                        } catch (e) {
                            console.error("Error fetching assignment data:", e);
                        }
                    }
                    
                    studentSubmissions.push({
                        id: submissionDoc.id,
                        userId: data.userId,
                        userName: userName,
                        userClass: userClass,
                        assignmentId: data.assignmentId,
                        assignmentTitle: assignmentTitle,
                        submittedAt: data.submittedAt || "",
                        status: data.status || "submitted",
                        graded: !!data.teacherGrade,
                        teacherGrade: data.teacherGrade
                    });
                }
                
                filterSubmissions();
                
                console.log(`Loaded ${studentSubmissions.length} total submissions, ${filteredSubmissions.length} for teacher's class ${teacherClass}`);
            }
        } catch (error) {
            console.error("Error fetching student submissions:", error);
        } finally {
            loadingSubmissions = false;
        }
    }

    async function fetchCourseDetails() {
    try {
        if (!courseId) {
            courseIdForAssignment = 'default-course';
        } else {
            courseIdForAssignment = courseId;
        }
        
        console.log("Fetching course details for course ID:", courseIdForAssignment);
        
        assignments = [];
        filteredAssignments = [];
        
        const courseRef = doc(db, 'assignmentCourses', courseIdForAssignment);
        const courseSnap = await getDoc(courseRef);
        
        if (courseSnap.exists()) {
            const data = courseSnap.data();
            course = {
                id: courseSnap.id,
                title: data.title || 'Untitled Course',
                institution: data.institution || 'Institution',
                year: data.year || 2025
            };
            console.log("Course found:", course.title);
        } else {
            console.log("Course not found, using default values");
            course = {
                id: courseIdForAssignment,
                title: courseIdForAssignment === 'english-lang' 
                    ? 'HKDSE English Language' 
                    : courseIdForAssignment === 'mathematics'
                    ? 'HKDSE Mathematics'
                    : 'HKDSE Biology',
                institution: courseIdForAssignment === 'english-lang'
                    ? 'Tanochology'
                    : courseIdForAssignment === 'mathematics'
                    ? 'Learning Hong Kong Special'
                    : 'HK Education Center',
                year: 2025
            };
        }
        
        const assignmentsQuery = query(
            collection(db, 'assignments'),
            where('courseId', '==', courseIdForAssignment)
        );
        
        const assignmentsSnap = await getDocs(assignmentsQuery);
        console.log(`Found ${assignmentsSnap.size} assignments for this course`);
        
        if (!assignmentsSnap.empty) {
            assignments = assignmentsSnap.docs.map((doc) => {
                const data = doc.data();
                const publishDate = data.publishDate || new Date().toISOString().split('T')[0];
                const dueDate = data.dueDate || '2025-04-30';
                
                const status = data.status === 'completed' 
                    ? 'completed' 
                    : determineAssignmentStatus(publishDate, dueDate);
                
                return {
                    id: doc.id,
                    title: data.title || 'Untitled Assignment',
                    description: data.description || 'No description provided',
                    dueDate: dueDate,
                    publishDate: publishDate,
                    status: status,
                    maxAttempts: data.maxAttempts || 3, 
                    wordLimit: data.wordLimit || 0, 
                    class: data.class || "", 
                    pendingCount: 0, 
                    totalSubmissions: 0 
                };
            });
            
            filterAssignments();
            
            console.log(`Loaded ${assignments.length} total assignments, ${filteredAssignments.length} for teacher's class ${teacherClass}`);
            
            await fetchPendingSubmissionsCount();
            
            filterAssignments();
            
            if (viewMode === "submissions") {
                await fetchStudentSubmissions();
            }
        } else {
            assignments = [];
            filteredAssignments = [];
        }
        
        loading = false;
    } catch (error) {
        console.error('Error fetching course details:', error);
        loading = false;
        
        course = {
            id: courseIdForAssignment,
            title: 'Course',
            institution: 'Institution',
            year: 2025
        };
        
        assignments = [];
        filteredAssignments = [];
    }
}

    function handleAssignmentClick(assignmentId: string) {
        if (courseIdForAssignment) {
            goto(`/teacher/assignment/statistics/?assignment=${assignmentId}`);
        } else {
            console.error('Course ID is undefined');
            goto(`/teacher/assignment/statistics/`);
        }
    }
    
    function viewAssignmentDetails(assignmentId: string, event) {
        event.stopPropagation();
        
        if (courseIdForAssignment) {
            goto(`/student/assignment/${courseIdForAssignment}/${assignmentId}?mode=teacher`);
        } else {
            console.error('Course ID is undefined');
            goto(`/student/assignment/default-course/${assignmentId}?mode=teacher`);
        }
    }
    
    function handleSubmissionClick(submission: StudentSubmission) {
        if (courseIdForAssignment) {
            goto(`/student/assignment/${courseIdForAssignment}/${submission.assignmentId}?mode=teacher&userId=${submission.userId}`);
        }
    }
    
    function toggleCreateForm() {
        showCreateForm = !showCreateForm;
        createError = "";
        createSuccess = false;
        
        if (showCreateForm && teacherClass) {
            newAssignment.class = teacherClass;
        }
    }
    
    function validateAttemptsInput() {
        // Ensure maxAttempts is a positive integer
        newAssignment.maxAttempts = Math.max(1, Math.floor(newAssignment.maxAttempts));
    }
    
    function validateWordLimitInput() {
        // Ensure wordLimit is a positive integer
        newAssignment.wordLimit = Math.max(1, Math.floor(newAssignment.wordLimit));
    }
    
    async function submitNewAssignment() {
        if (!newAssignment.title) {
            createError = "Assignment title is required";
            return;
        }
        
        if (!newAssignment.question) {
            createError = "Assignment question is required";
            return;
        }
        
        if (!newAssignment.dueDate) {
            createError = "Due date is required";
            return;
        }
        
        if (new Date(newAssignment.dueDate) <= new Date(newAssignment.publishDate)) {
            createError = "Due date must be after publish date";
            return;
        }
        
        if (newAssignment.maxAttempts < 1) {
            createError = "Maximum attempts must be at least 1";
            return;
        }
        
        if (newAssignment.wordLimit < 1) {
            createError = "Word limit must be at least 1";
            return;
        }
        
        if (!teacherClass) {
            createError = "You don't have a class assigned. Please contact an administrator.";
            return;
        }
        
        newAssignment.class = teacherClass;
        
        creatingAssignment = true;
        createError = "";
        
        try {
            if (!newAssignment.courseId) {
                newAssignment.courseId = 'default-course';
            }
            
            const initialStatus = determineAssignmentStatus(
                newAssignment.publishDate,
                newAssignment.dueDate
            );
            
            const assignmentData = {
                title: newAssignment.title,
                description: newAssignment.description || "No description provided",
                publishDate: newAssignment.publishDate,
                dueDate: newAssignment.dueDate,
                question: newAssignment.question,
                maxAttempts: newAssignment.maxAttempts,
                wordLimit: newAssignment.wordLimit,
                courseId: newAssignment.courseId,
                class: newAssignment.class, 
                status: initialStatus, 
                createdAt: new Date().toISOString(), 
                createdBy: userId || 'unknown',
                requiresUserId: true, 
                individualTracking: true 
            };
            
            try {
                const assignmentsCollection = collection(db, 'assignments');
                
                const docRef = await addDoc(assignmentsCollection, assignmentData);
                
                const newAssignmentObj: Assignment = {
                    id: docRef.id,
                    title: newAssignment.title,
                    description: newAssignment.description || "No description provided",
                    dueDate: newAssignment.dueDate,
                    publishDate: newAssignment.publishDate,
                    status: initialStatus,
                    maxAttempts: newAssignment.maxAttempts,
                    wordLimit: newAssignment.wordLimit, 
                    class: newAssignment.class,
                    pendingCount: 0,
                    totalSubmissions: 0
                };
                
                assignments = [...assignments, newAssignmentObj];
                
                filterAssignments();
                
                createSuccess = true;
                
                setTimeout(() => {
                    newAssignment = {
                        title: "",
                        description: "",
                        publishDate: new Date().toISOString().split('T')[0],
                        dueDate: "",
                        question: "",
                        maxAttempts: 3,
                        wordLimit: 500, 
                        courseId: courseIdForAssignment, 
                        class: teacherClass 
                    };
                    
                    showCreateForm = false;
                    createSuccess = false;
                }, 2000);
                
            } catch (addDocError) {
                console.error("Error with addDoc:", addDocError);
                throw addDocError; 
            }
            
        } catch (error) {
            console.error('Error creating assignment:', error);
            createError = "Failed to create assignment. Please try again.";
            
            if (error.message && (error.message.includes("permission-denied") || error.code === "permission-denied")) {
                const temporaryId = 'local-' + Date.now();
                const initialStatus = determineAssignmentStatus(
                    newAssignment.publishDate,
                    newAssignment.dueDate
                );

                const localAssignment: Assignment = {
                    id: temporaryId,
                    title: newAssignment.title + " (Local Only)",
                    description: newAssignment.description || "No description provided",
                    dueDate: newAssignment.dueDate,
                    publishDate: newAssignment.publishDate,
                    status: initialStatus,
                    maxAttempts: newAssignment.maxAttempts,
                    wordLimit: newAssignment.wordLimit, 
                    class: newAssignment.class,
                    pendingCount: 0,
                    totalSubmissions: 0
                };
                
                assignments = [...assignments, localAssignment];
                
                filterAssignments();
                
                createSuccess = true;
                createError = "Note: Assignment created in local view only due to Firebase permissions.";
                
                setTimeout(() => {
                    newAssignment = {
                        title: "",
                        description: "",
                        publishDate: new Date().toISOString().split('T')[0],
                        dueDate: "",
                        question: "",
                        maxAttempts: 3,
                        wordLimit: 500, 
                        courseId: courseIdForAssignment,
                        class: teacherClass 
                    };
                    
                    showCreateForm = false;
                    createSuccess = false;
                }, 3000);
            }
        } finally {
            creatingAssignment = false;
        }
    }

    function getStatusColor(status: string): string {
        switch (status) {
            case 'completed':
                return '#22c55e'; // green
            case 'in-progress':
                return '#f59e0b'; // amber
            case 'closed':
                return '#ef4444'; // red
            case 'not-started':
            default:
                return '#6b7280'; // gray
        }
    }

    function formatDate(dateString: string): string {
        if (!dateString) return "No date";
        const date = new Date(dateString);
        return date.toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
    }
    
    function formatDateTime(dateTimeString: string): string {
        if (!dateTimeString) return "No date";
        const date = new Date(dateTimeString);
        return date.toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    function getDaysRemaining(dueDate: string): number {
        const today = new Date();
        const due = new Date(dueDate);
        const diffTime = due.getTime() - today.getTime();
        return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    }
    
    
    function refreshData() {
        
        assignments = [];
        filteredAssignments = [];
        
        fetchCourseDetails();
        
        if (viewMode === "submissions") {
            
            studentSubmissions = [];
            filteredSubmissions = [];
            fetchStudentSubmissions();
        }
    }

    onMount(async () => {
        
        await checkUserRole();
        
        if (!courseId) {
            courseIdForAssignment = 'default-course';
        }
        
        await fetchCourseDetails();
    });
</script>

<main class="teacher-assignment-dashboard">
   
    <div class="container">
        <UnderscoreDiv>
            <div class="header-container">
                <SubheadingBar title="Assignment Management" />
                
                <div class="header-actions">
                    {#if userLoading}
                        <div class="role-checking">
                            <span class="loading-spinner-tiny"></span> Loading...
                        </div>
                    {:else}
                        <div class="teacher-class-badge">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M3 3v18h18"></path>
                                <path d="M3 15L9 9l4 4 8-8"></path>
                            </svg>
                            {teacherClass ? `Class ${teacherClass}` : 'No Class Assigned'}
                        </div>
                        
                        <button class="create-button" on:click={toggleCreateForm} disabled={!teacherClass}>
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <line x1="12" y1="5" x2="12" y2="19"></line>
                                <line x1="5" y1="12" x2="19" y2="12"></line>
                            </svg>
                            {showCreateForm ? 'Cancel' : 'Create Assignment'}
                        </button>
                    {/if}
                </div>
            </div>
        </UnderscoreDiv>

        {#if !teacherClass && !userLoading}
            <UnderscoreDiv>
                <div class="no-class-warning">
                    <div class="warning-icon">⚠️</div>
                    <div class="warning-message">
                        <h3>No Class Assigned</h3>
                        <p>You don't have a class assigned to your account. Please contact an administrator to assign you to a class before creating assignments.</p>
                    </div>
                </div>
            </UnderscoreDiv>
        {/if}

        {#if showDeleteConfirmation}
            <div class="delete-confirmation-overlay">
                <div class="delete-confirmation-dialog">
                    <h3>Confirm Deletion</h3>
                    <p>Are you sure you want to delete the assignment "{currentAssignmentToDelete?.title}"?</p>
                    <p class="delete-warning">This action cannot be undone. All student submissions for this assignment will also be deleted.</p>
                    
                    {#if deleteError}
                        <div class="error-message">{deleteError}</div>
                    {/if}
                    
                    <div class="confirmation-actions">
                        <button class="cancel-button" on:click={cancelDeleteAssignment} disabled={deletingAssignmentId !== null}>
                            Cancel
                        </button>
                        <button class="delete-button" on:click={deleteAssignment} disabled={deletingAssignmentId !== null}>
                            {#if deletingAssignmentId !== null}
                                <span class="loading-spinner-small"></span>
                                Deleting...
                            {:else}
                                Delete Assignment
                            {/if}
                        </button>
                    </div>
                </div>
            </div>
        {/if}

        {#if deleteSuccess}
            <div class="success-toast">
                {deleteSuccess}
            </div>
        {/if}

        {#if showCreateForm && teacherClass}
            <UnderscoreDiv>
                <div class="create-form">
                    <h2>Create New Assignment for Class {teacherClass}</h2>
                    
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="assignment-title">Assignment Name*</label>
                            <input 
                                id="assignment-title"
                                type="text" 
                                bind:value={newAssignment.title}
                                placeholder="Enter assignment title"
                                required
                            />
                        </div>
                        
                        <div class="form-group">
                            <label for="assignment-description">Description</label>
                            <input 
                                id="assignment-description"
                                type="text" 
                                bind:value={newAssignment.description}
                                placeholder="Brief description of the assignment"
                            />
                        </div>
                        
                        <div class="form-group">
                            <label for="publish-date">Publish Date*</label>
                            <input 
                                id="publish-date"
                                type="date" 
                                bind:value={newAssignment.publishDate}
                                required
                            />
                        </div>
                        
                        <div class="form-group">
                            <label for="due-date">Due Date*</label>
                            <input 
                                id="due-date"
                                type="date" 
                                bind:value={newAssignment.dueDate}
                                required
                            />
                        </div>
                        
                        <div class="form-group">
                            <label for="max-attempts">Maximum Attempts*</label>
                            <input 
                                id="max-attempts"
                                type="number" 
                                bind:value={newAssignment.maxAttempts}
                                min="1"
                                step="1"
                                on:change={validateAttemptsInput}
                                required
                            />
                            <small class="field-hint">Number of times students can submit this assignment</small>
                        </div>
                        
                        <div class="form-group">
                            <label for="word-limit">Word Limit*</label>
                            <input 
                                id="word-limit"
                                type="number" 
                                bind:value={newAssignment.wordLimit}
                                min="1"
                                step="1"
                                on:change={validateWordLimitInput}
                                required
                            />
                            <small class="field-hint">Maximum number of words for student submissions</small>
                        </div>
                        
                        <div class="form-group">
                            <label for="assignment-class">Assign to Class</label>
                            <div class="selected-class-display">
                                <span class="class-chip">{teacherClass}</span>
                                <small class="field-hint">This assignment will be automatically assigned to your class</small>
                            </div>
                            <input type="hidden" id="assignment-class" bind:value={newAssignment.class} />
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="assignment-question">Assignment Question*</label>
                        <textarea 
                            id="assignment-question"
                            bind:value={newAssignment.question}
                            placeholder="Enter the assignment question or prompt"
                            rows="4"
                            required
                        ></textarea>
                    </div>
                    
                    <div class="form-group notice-info">
                        <div class="notice">
                            <span class="notice-icon">ℹ️</span>
                            <span class="notice-text">
                                <strong>Individual Student Tracking:</strong> Each student's assignment progress and submissions 
                                will be tracked individually. When one student in a class submits their assignment, it won't affect 
                                the submission status of other students in the same class.
                            </span>
                        </div>
                    </div>
                    
                    {#if createError}
                        <div class="error-message">{createError}</div>
                    {/if}
                    
                    {#if createSuccess}
                        <div class="success-message">Assignment created successfully!</div>
                    {/if}
                    
                    <div class="form-actions">
                        <button class="cancel-button" on:click={toggleCreateForm}>Cancel</button>
                        <button class="submit-button" on:click={submitNewAssignment} disabled={creatingAssignment || !teacherClass}>
                            {#if creatingAssignment}
                                <span class="loading-spinner-small"></span>
                                Creating...
                            {:else}
                                Create Assignment
                            {/if}
                        </button>
                    </div>
                </div>
            </UnderscoreDiv>
        {/if}

        <UnderscoreDiv>
            {#if loading}
                <div class="loading-container">
                    <div class="loading-spinner"></div>
                    <p>Loading assignments...</p>
                </div>
            {:else if filteredAssignments.length === 0}
                <div class="empty-state">
                    <div class="empty-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                            <rect x="2" y="4" width="20" height="16" rx="2" ry="2"></rect>
                            <path d="M6 8h.01"></path>
                            <path d="M6 12h.01"></path>
                            <path d="M6 16h.01"></path>
                            <path d="M10 8h8"></path>
                            <path d="M10 12h8"></path>
                            <path d="M10 16h8"></path>
                        </svg>
                    </div>
                    <h3>No Assignments</h3>
                    <p>
                        {#if teacherClass}
                            There are no assignments for your class ({teacherClass}) in this course.
                        {:else}
                            There are no assignments for this course yet.
                        {/if}
                    </p>
                    {#if teacherClass}
                        <button class="create-button-centered" on:click={toggleCreateForm}>
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <line x1="12" y1="5" x2="12" y2="19"></line>
                                <line x1="5" y1="12" x2="19" y2="12"></line>
                            </svg>
                            Create Assignment
                        </button>
                    {/if}
                </div>
            {:else}
                <div class="assignments-container">
                    <div class="class-info-banner">
                        <div class="class-icon">📚</div>
                        <div class="class-text">
                            Showing assignments for {teacherClass ? `Class ${teacherClass}` : 'All Classes'}
                        </div>
                    </div>
                    
                    <div class="assignments-list">
                        {#each filteredAssignments as assignment}
                            <div 
                                class="assignment-card" 
                                on:click={() => handleAssignmentClick(assignment.id)}
                                on:keydown={(e) => e.key === 'Enter' && handleAssignmentClick(assignment.id)}
                                role="button"
                                tabindex="0"
                            >
                                <div class="status-indicator" style="background-color: {getStatusColor(assignment.status)}"></div>
                                <div class="assignment-content">
                                    <div class="assignment-header">
                                        <h3 class="assignment-title">
                                            {assignment.title}
                                            {#if assignment.pendingCount > 0}
                                                <span class="assignment-badge pending-badge">
                                                    {assignment.pendingCount} pending
                                                </span>
                                            {/if}
                                        </h3>
                                        <div class="assignment-badges">
                                            {#if assignment.class}
                                                <span class="class-badge">
                                                    {assignment.class}
                                                </span>
                                            {/if}
                                            
                                            <div class="status-badge" style="background-color: {getStatusColor(assignment.status)}">
                                                {assignment.status === 'completed' ? 'Completed' : 
                                                assignment.status === 'in-progress' ? 'In Progress' : 
                                                assignment.status === 'closed' ? 'Closed' : 'Not Started'}
                                            </div>
                                            
                                            <button 
                                                class="delete-assignment-btn" 
                                                on:click={(e) => confirmDeleteAssignment(assignment, e)}
                                                title="Delete Assignment"
                                            >
                                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                                    <polyline points="3 6 5 6 21 6"></polyline>
                                                    <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                                                    <line x1="10" y1="11" x2="10" y2="17"></line>
                                                    <line x1="14" y1="11" x2="14" y2="17"></line>
                                                </svg>
                                            </button>
                                        </div>
                                    </div>
                                    <p class="assignment-description">{assignment.description}</p>
                                    <div class="assignment-footer">
                                        <div class="assignment-details">
                                            <div class="assignment-dates">
                                                <div class="publish-date">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                                        <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                                                        <line x1="16" y1="2" x2="16" y2="6"></line>
                                                        <line x1="8" y1="2" x2="8" y2="6"></line>
                                                        <line x1="3" y1="10" x2="21" y2="10"></line>
                                                    </svg>
                                                    <span>Published: {formatDate(assignment.publishDate)}</span>
                                                </div>
                                                <div class="due-date">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                                        <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                                                        <line x1="16" y1="2" x2="16" y2="6"></line>
                                                        <line x1="8" y1="2" x2="8" y2="6"></line>
                                                        <line x1="3" y1="10" x2="21" y2="10"></line>
                                                    </svg>
                                                    <span>
                                                        Due: {formatDate(assignment.dueDate)}
                                                        {#if getDaysRemaining(assignment.dueDate) > 0}
                                                            <span class="days-remaining">
                                                                ({getDaysRemaining(assignment.dueDate)} days remaining)
                                                            </span>
                                                        {:else if getDaysRemaining(assignment.dueDate) === 0}
                                                            <span class="days-remaining today">
                                                                (Due today)
                                                            </span>
                                                        {:else}
                                                            <span class="days-remaining overdue">
                                                                (Overdue by {Math.abs(getDaysRemaining(assignment.dueDate))} days)
                                                            </span>
                                                        {/if}
                                                    </span>
                                                </div>
                                            </div>
                                            <div class="max-attempts">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                                    <path d="M12 2v4m0 12v4M4.93 4.93l2.83 2.83m8.48 8.48l2.83 2.83M2 12h4m12 0h4M4.93 19.07l2.83-2.83m8.48-8.48l2.83-2.83"></path>
                                                </svg>
                                                <span>Max attempts: {assignment.maxAttempts || 3}</span>
                                            </div>
                                            
                                            <div class="word-limit">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                                    <path d="M12 20h9"></path>
                                                    <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"></path>
                                                </svg>
                                                <span>Word limit: {assignment.wordLimit ? assignment.wordLimit : 'None'}</span>
                                            </div>
                                            
                                            <div class="submission-stats">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                                    <path d="M14 2H6a2 2 0 0 0-2 2v16c0 1.1.9 2 2 2h12a2 2 0 0 0 2-2V8l-6-6z"/>
                                                    <path d="M14 3v5h5M16 13H8M16 17H8M10 9H8"/>
                                                </svg>
                                                <div class="stats-details">
                                                    <span>Submissions: {assignment.totalSubmissions || 0}</span>
                                                    {#if assignment.pendingCount > 0}
                                                        <span class="needs-grading">
                                                            (Need grading: {assignment.pendingCount})
                                                        </span>
                                                    {:else if assignment.totalSubmissions > 0}
                                                        <span class="all-graded">
                                                            (All graded)
                                                        </span>
                                                    {/if}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        {/each}
                    </div>
                </div>
            {/if}
        </UnderscoreDiv>
    </div>
</main>

<style lang="scss">
   main {
    position: relative;
    height: 100%;
    width: 100%;
    background-color: var(--clr-content-background);
}

/* Hide the "Add new exam" button */
.teacher-assignment-dashboard :global(div.s-EHBj4WKrFE0n),
.teacher-assignment-dashboard :global(div[title="Add new exam"]) {
    display: none !important;
}

.container {
    padding: 1.25rem 2.5rem;
    max-width: 1440px;
    margin: 0 auto;
}

.header-container {
    display: flex;
    justify-content: space-between;
    align-items: center;
    width: 100%;
}

.header-actions {
    display: flex;
    align-items: center;
    gap: 10px;
}

.teacher-class-badge {
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 6px 12px;
    background-color: #e0f2fe;
    color: #0c4a6e;
    border-radius: 6px;
    font-weight: 500;
    font-size: 14px;
}

.class-info-banner {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 10px 15px;
    background-color: #f0f9ff;
    border-radius: 8px;
    margin-bottom: 20px;
    border-left: 4px solid #3b82f6;
    
    .class-icon {
        font-size: 20px;
    }
    
    .class-text {
        font-size: 14px;
        font-weight: 500;
        color: #1e40af;
    }
}

.no-class-warning {
    display: flex;
    align-items: flex-start;
    gap: 15px;
    padding: 15px;
    background-color: #fff3cd;
    border-radius: 8px;
    border-left: 4px solid #f59e0b;
    
    .warning-icon {
        font-size: 24px;
    }
    
    .warning-message {
        h3 {
            margin: 0 0 8px 0;
            color: #92400e;
            font-size: 16px;
        }
        
        p {
            margin: 0;
            color: #7c3aed;
            font-size: 14px;
        }
    }
}

.role-checking {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    color: #6b7280;
    font-size: 0.875rem;
}

.loading-spinner-tiny {
    display: inline-block;
    width: 12px;
    height: 12px;
    border: 2px solid rgba(0, 0, 0, 0.1);
    border-radius: 50%;
    border-left-color: #93c5fd;
    animation: spin 1s linear infinite;
}

.create-button, .create-button-centered {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    background-color: #4f46e5;
    color: white;
    border: none;
    border-radius: 0.375rem;
    padding: 0.5rem 1rem;
    font-size: 0.875rem;
    font-weight: 500;
    cursor: pointer;
    transition: background-color 0.2s;
    
    svg {
        stroke: white;
    }
    
    &:hover:not(:disabled) {
        background-color: #4338ca;
    }
    
    &:disabled {
        background-color: #c7d2fe;
        color: #6366f1;
        cursor: not-allowed;
    }
}

.create-button-centered {
    margin-top: 1.5rem;
}

.create-form {
    padding: 1.5rem;
    
    h2 {
        font-size: 1.25rem;
        font-weight: 600;
        color: #111827;
        margin-top: 0;
        margin-bottom: 1.5rem;
    }
    
    .form-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 1rem;
    }
    
    .form-group {
        margin-bottom: 1.25rem;
        
        label {
            display: block;
            font-size: 0.875rem;
            font-weight: 500;
            color: #4b5563;
            margin-bottom: 0.5rem;
        }
        
        input, textarea {
            width: 100%;
            padding: 0.625rem;
            border: 1px solid #d1d5db;
            border-radius: 0.375rem;
            font-size: 1rem;
            transition: border-color 0.15s;
            
            &:focus {
                outline: none;
                border-color: #4f46e5;
                box-shadow: 0 0 0 1px rgba(79, 70, 229, 0.2);
            }
        }
        
        textarea {
            resize: vertical;
        }
        
        .field-hint {
            display: block;
            margin-top: 0.25rem;
            font-size: 0.75rem;
            color: #6b7280;
        }
        
        .selected-class-display {
            padding: 0.625rem;
            background-color: #f9fafb;
            border: 1px solid #d1d5db;
            border-radius: 0.375rem;
            color: #374151;
        }

        .class-chip {
            display: inline-block;
            padding: 0.25rem 0.5rem;
            background-color: #e0f2fe;
            color: #0369a1;
            border-radius: 9999px;
            font-size: 0.875rem;
            font-weight: 500;
        }
    }
    
    .notice-info {
        margin-bottom: 15px;
        
        .notice {
            display: flex;
            align-items: flex-start;
            gap: 10px;
            padding: 10px;
            background-color: #e0f2fe;
            border-radius: 5px;
            border-left: 4px solid #3b82f6;
            
            .notice-icon {
                font-size: 18px;
            }
            
            .notice-text {
                font-size: 0.875rem;
                color: #1e40af;
                line-height: 1.5;
            }
        }
    }
    
    .error-message {
        color: #ef4444;
        font-size: 0.875rem;
        margin-bottom: 1rem;
        padding: 0.5rem;
        background-color: #fee2e2;
        border-radius: 0.375rem;
    }
    
    .success-message {
        color: #10b981;
        font-size: 0.875rem;
        margin-bottom: 1rem;
        padding: 0.5rem;
        background-color: #d1fae5;
        border-radius: 0.375rem;
    }
    
    .form-actions {
        display: flex;
        justify-content: flex-end;
        gap: 1rem;
        margin-top: 1rem;
    }
    
    .cancel-button {
        padding: 0.625rem 1rem;
        background-color: #f3f4f6;
        color: #4b5563;
        border: none;
        border-radius: 0.375rem;
        font-size: 0.875rem;
        font-weight: 500;
        cursor: pointer;
        transition: background-color 0.2s;
        
        &:hover {
            background-color: #e5e7eb;
        }
    }
    
    .submit-button {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        padding: 0.625rem 1rem;
        background-color: #4f46e5;
        color: white;
        border: none;
        border-radius: 0.375rem;
        font-size: 0.875rem;
        font-weight: 500;
        cursor: pointer;
        transition: background-color 0.2s;
        
        &:hover:not(:disabled) {
            background-color: #4338ca;
        }
        
        &:disabled {
            opacity: 0.7;
            cursor: not-allowed;
        }
    }
}

.loading-spinner-small {
    display: inline-block;
    width: 1rem;
    height: 1rem;
    border: 2px solid rgba(255, 255, 255, 0.3);
    border-radius: 50%;
    border-top-color: white;
    animation: spin 1s linear infinite;
}

.loading-container {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: 3rem;
    gap: 1rem;
    text-align: center;
}

.loading-spinner {
    width: 2.5rem;
    height: 2.5rem;
    border: 4px solid rgba(0, 0, 0, 0.1);
    border-radius: 50%;
    border-left-color: #93c5fd;
    animation: spin 1s linear infinite;
}

@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}

.empty-state {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: 4rem;
    gap: 1rem;
    text-align: center;

    .empty-icon {
        color: #9ca3af;
        margin-bottom: 1rem;
    }

    h3 {
        font-size: 1.25rem;
        font-weight: 600;
        color: #111827;
        margin: 0;
    }

    p {
        color: #6b7280;
        max-width: 24rem;
    }
}

.assignments-container {
    padding: 2rem;
}

.assignments-list {
    display: flex;
    flex-direction: column;
    gap: 1rem;
}

.assignment-card {
    display: flex;
    background-color: white;
    border-radius: 0.75rem;
    overflow: hidden;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
    transition: transform 0.2s, box-shadow 0.2s;
    cursor: pointer;

    &:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
}

.status-indicator {
    width: 8px;
    flex-shrink: 0;
}

.assignment-content {
    flex-grow: 1;
    padding: 1.25rem;
}

.assignment-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 0.75rem;
}

.assignment-title {
    font-size: 1.125rem;
    font-weight: 600;
    color: #111827;
    margin: 0;
    display: flex;
    align-items: center;
    gap: 8px;
}

.assignment-badge {
    font-size: 12px;
    padding: 2px 6px;
    border-radius: 4px;
    font-weight: 500;
    
    &.pending-badge {
        background-color: #fee2e2;
        color: #b91c1c;
    }
}

.assignment-badges {
    display: flex;
    gap: 0.5rem;
    align-items: center;
}

.status-badge {
    padding: 0.25rem 0.5rem;
    border-radius: 9999px;
    font-size: 0.75rem;
    font-weight: 500;
    color: white;
}

.class-badge {
    padding: 0.25rem 0.5rem;
    border-radius: 9999px;
    font-size: 0.75rem;
    font-weight: 500;
    background-color: #e5e7eb;
    color: #374151;
}

.assignment-description {
    color: #6b7280;
    line-height: 1.5;
    margin-bottom: 1.25rem;
    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
}

.assignment-footer {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.assignment-details {
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
}

.assignment-dates {
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
}

.publish-date, .due-date, .max-attempts, .word-limit {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    color: #6b7280;
    font-size: 0.875rem;

    svg {
        color: #9ca3af;
    }
}

.due-date {
    .days-remaining {
        margin-left: 0.25rem;
        
        &.today {
            color: #f59e0b;
            font-weight: 500;
        }
        
        &.overdue {
            color: #ef4444;
            font-weight: 500;
        }
    }
}

.submission-stats {
    display: flex;
    align-items: flex-start;
    gap: 0.5rem;
    color: #6b7280;
    font-size: 0.875rem;
    margin-top: 0.5rem;
    
    svg {
        color: #9ca3af;
        flex-shrink: 0;
        margin-top: 2px;
    }
    
    .stats-details {
        display: flex;
        flex-direction: column;
        gap: 2px;
        
        .needs-grading {
            color: #b91c1c;
            font-weight: 500;
        }
        
        .all-graded {
            color: #047857;
            font-weight: 500;
        }
    }
}

.delete-assignment-btn {
    width: 28px;
    height: 28px;
    display: flex;
    align-items: center;
    justify-content: center;
    background-color: #fee2e2;
    color: #b91c1c;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    transition: all 0.2s;
    
    &:hover {
        background-color: #ef4444;
        color: white;
    }
    
    svg {
        stroke-width: 2;
    }
}

.delete-confirmation-overlay {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: rgba(0, 0, 0, 0.5);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 1000;
}

.delete-confirmation-dialog {
    background-color: white;
    border-radius: 8px;
    padding: 1.5rem;
    max-width: 500px;
    width: 90%;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    
    h3 {
        color: #111827;
        font-size: 1.25rem;
        font-weight: 600;
        margin-top: 0;
        margin-bottom: 1rem;
    }
    
    p {
        color: #4b5563;
        margin-bottom: 1rem;
        line-height: 1.5;
    }
    
    .delete-warning {
        color: #b91c1c;
        font-weight: 500;
        background-color: #fee2e2;
        padding: 0.5rem 0.75rem;
        border-radius: 6px;
        border-left: 4px solid #ef4444;
    }
    
    .confirmation-actions {
        display: flex;
        justify-content: flex-end;
        gap: 1rem;
        margin-top: 1.5rem;
    }
    
    .cancel-button {
        padding: 0.5rem 1rem;
        border: 1px solid #d1d5db;
        border-radius: 6px;
        background-color: white;
        color: #374151;
        font-weight: 500;
        cursor: pointer;
        
        &:hover:not(:disabled) {
            background-color: #f3f4f6;
        }
        
        &:disabled {
            opacity: 0.7;
            cursor: not-allowed;
        }
    }
    
    .delete-button {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        padding: 0.5rem 1rem;
        border: none;
        border-radius: 6px;
        background-color: #ef4444;
        color: white;
        font-weight: 500;
        cursor: pointer;
        
        &:hover:not(:disabled) {
            background-color: #dc2626;
        }
        
        &:disabled {
            opacity: 0.7;
            cursor: not-allowed;
        }
    }
}

.success-toast {
    position: fixed;
    bottom: 2rem;
    left: 50%;
    transform: translateX(-50%);
    background-color: #10b981;
    color: white;
    padding: 0.75rem 1.5rem;
    border-radius: 6px;
    font-size: 0.875rem;
    font-weight: 500;
    z-index: 1000;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    animation: fadeInOut 3s forwards;
}

@keyframes fadeInOut {
    0% { opacity: 0; transform: translate(-50%, 20px); }
    10% { opacity: 1; transform: translate(-50%, 0); }
    90% { opacity: 1; transform: translate(-50%, 0); }
    100% { opacity: 0; transform: translate(-50%, 20px); }
}

.error-message {
    color: #ef4444;
    font-size: 0.875rem;
    margin-bottom: 1rem;
    padding: 0.5rem;
    background-color: #fee2e2;
    border-radius: 0.375rem;
}

.success-message {
    color: #10b981;
    font-size: 0.875rem;
    margin-bottom: 1rem;
    padding: 0.5rem;
    background-color: #d1fae5;
    border-radius: 0.375rem;
}

@media (max-width: 768px) {
    .container {
        padding: 1rem 1.5rem;
    }

    .assignments-container {
        padding: 1rem;
    }

    .assignment-header {
        flex-direction: column;
        align-items: flex-start;
        gap: 0.5rem;
    }

    .assignment-footer {
        flex-direction: column;
        align-items: flex-start;
        gap: 0.75rem;
    }
    
    .header-container {
        flex-direction: column;
        align-items: flex-start;
        gap: 1rem;
    }
    
    .create-button {
        width: 100%;
        justify-content: center;
    }
    
    .form-grid {
        grid-template-columns: 1fr !important;
    }
    
    .header-actions {
        width: 100%;
        flex-direction: column;
        gap: 8px;
        
        .create-button, .teacher-class-badge {
            width: 100%;
            justify-content: center;
        }
    }
}
</style>