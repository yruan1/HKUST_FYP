<script lang="ts">
    import { page } from '$app/stores';
    import SearchHeader from '$lib/components/SearchHeader.svelte';
    import SubheadingBar from '$lib/components/SubheadingBar.svelte';
    import UnderscoreDiv from '$lib/components/UnderscoreDiv.svelte';
    import { onMount } from 'svelte';
    import { db } from '$lib/firebase';
    import { collection, query, where, getDocs, doc, getDoc, updateDoc } from 'firebase/firestore';
    import { goto } from '$app/navigation';
    import { getCurrentUserIdFromCookie } from '$lib/utils/auth';

    const courseId = $page.params.id || 'default-course';
    
    let userLoading = true;
    let userDetails = null;
    let userId: string | null = null;
    let teacherClass = ""; 
    
    let totalStudents = 0;
    let totalAssignments = 0;
    let totalSubmissions = 0;
    let completionRate = 0; 
    let averageClassGrade = 0;
    
    let loadingStats = true;
    let loadingAssignments = true;
    let loadingStudents = true;
    let statsError = "";
    
    let selectedAssignment = ""; 
    
    let gradeMessage = "";
    let gradeMessageType = "success"; 
    let gradingInProgress = false;
    
    
    $: {
        const urlAssignmentId = $page.url.searchParams.get('assignment');
        if (urlAssignmentId && urlAssignmentId !== selectedAssignment) {
            
            console.log("Setting assignment from URL parameter:", urlAssignmentId);
            selectedAssignment = urlAssignmentId;
            
            
            if (assignments.length > 0 && !loadingAssignments) {
                applyFilters();
            }
        }
    }
    
    
    $: if (selectedAssignment && assignments.length > 0 && !loadingAssignments) {
        console.log("Selected assignment changed to:", selectedAssignment);
        applyFilters();
    }
    
    
    interface Assignment {
        id: string;
        title: string;
        dueDate: string;
        publishDate: string;
        status: string;
        avgGrade?: number;
        submissions?: number;
        class?: string;
    }
    
    interface Student {
        id: string;
        name: string;
        class: string;
        averageGrade: number;
        completedAssignments: number;
        totalAssignments: number;
        lastSubmission?: string;
        performanceTrend?: 'improving' | 'declining' | 'stable';
        submissionId?: string;
        submissionContent?: string;
        grading?: boolean;
        tempGrade?: number | string;
    }
    
    interface GradeDistribution {
        range: string;
        count: number;
        percentage: number;
    }
    
    
    let assignments: Assignment[] = [];
    let students: Student[] = [];
    let gradeDistribution: GradeDistribution[] = [];
    
    
    let showGradeDistributionChart = false;
    
    
    let gradeDistributionChartInstance = null;
    
    
    function parseDate(dateString: string): Date {
        if (!dateString) return new Date();
        
        try {
            
            const date = new Date(dateString);
            
           
            if (isNaN(date.getTime())) {
                console.warn(`Invalid date string: ${dateString}, using current date`);
                return new Date();
            }
            
            return date;
        } catch (e) {
            console.error(`Error parsing date: ${dateString}`, e);
            return new Date();
        }
    }
    
    
    async function checkUserRole() {
        try {
            userLoading = true;
            const uid = getCurrentUserIdFromCookie();
            
            if (!uid) {
                
                goto('/student/assignment');
                return;
            }
            
            userId = uid;
            
            
            const userRef = doc(db, 'users', uid);
            const userSnap = await getDoc(userRef);
            
            if (userSnap.exists()) {
                const userData = userSnap.data();
                userDetails = userData;
                
                
                const userRole = userData.role || 'student';
                const isTeacher = userRole === 'teacher' || userRole === 'admin';
                
                if (!isTeacher) {
                    
                    goto('/student/assignment');
                    return;
                }
                
              
                teacherClass = userData.class || "";
                console.log("Teacher's class:", teacherClass);
                
                
                if (!teacherClass) {
                    loadingStats = false;
                    loadingAssignments = false;
                    loadingStudents = false;
                }
            } else {
                
                goto('/student/assignment');
            }
        } catch (error) {
            console.error("Error checking user role:", error);
            
            goto('/student/assignment');
        } finally {
            userLoading = false;
        }
    }
    
    
    function determineAssignmentStatus(publishDate: string, dueDate: string): string {
        const now = new Date();
        
        
        const publish = publishDate ? parseDate(publishDate) : new Date(0); 
        const due = dueDate ? parseDate(dueDate) : new Date(now.getTime() + 86400000); 
        
        
        due.setHours(23, 59, 59, 999);
        
        
        console.log(`Determining status for assignment with publish date: ${publish} and due date: ${due}`);
        console.log(`Current date: ${now}, Is past due? ${now > due}`);
        
        if (now > due) {
            return 'closed';
        } else if (now >= publish) {
            return 'in-progress';
        } else {
            return 'not-started';
        }
    }
    
    
    async function fetchAssignments() {
        
        if (!teacherClass) {
            loadingAssignments = false;
            return;
        }
        
        loadingAssignments = true;
        assignments = [];
        
        try {
            
            const assignmentsQuery = query(
                collection(db, 'assignments'),
                where('courseId', '==', courseId),
                where('class', '==', teacherClass) 
            );
            
            const assignmentsSnap = await getDocs(assignmentsQuery);
            
            if (!assignmentsSnap.empty) {
                const tempAssignments = [];
                
                
                for (const assignmentDoc of assignmentsSnap.docs) {
                    const data = assignmentDoc.data();
                    
                    
                    let avgGrade = 0;
                    let submissions = 0;
                    
                    
                    const submissionsQuery = query(
                        collection(db, 'assignmentResult'),
                        where('assignmentId', '==', assignmentDoc.id)
                    );
                    
                    const submissionsSnap = await getDocs(submissionsQuery);
                    
                    if (!submissionsSnap.empty) {
                        let gradeSum = 0;
                        let gradedCount = 0;
                        let classSpecificSubmissions = 0;
                        
                        
                        for (const submissionDoc of submissionsSnap.docs) {
                            const submissionData = submissionDoc.data();
                            
                            
                            const studentClass = await getStudentClass(submissionData.userId);
                            
                            
                            if (studentClass === teacherClass) {
                                classSpecificSubmissions++;
                                
                                
                                if (submissionData.teacherGrade) {
                                    const grade = parseFloat(submissionData.teacherGrade);
                                    if (!isNaN(grade)) {
                                        gradeSum += grade;
                                        gradedCount++;
                                    }
                                }
                            }
                        }
                        
                        
                        submissions = classSpecificSubmissions;
                        
                        
                        if (gradedCount > 0) {
                            avgGrade = Math.round((gradeSum / gradedCount) * 10) / 10; 
                        }
                    }
                    
                    const publishDate = data.publishDate || new Date().toISOString().split('T')[0];
                    const dueDate = data.dueDate || new Date(Date.now() + 14*24*60*60*1000).toISOString().split('T')[0];
                    
                    
                    const normalizedStatus = determineAssignmentStatus(publishDate, dueDate);
                    
                    
                    console.log(`Assignment ${data.title} with due date ${dueDate} has status: ${normalizedStatus}`);
                    
                    
                    tempAssignments.push({
                        id: assignmentDoc.id,
                        title: data.title || 'Untitled Assignment',
                        dueDate: dueDate,
                        publishDate: publishDate,
                        status: normalizedStatus,
                        avgGrade: avgGrade,
                        submissions: submissions,
                        class: data.class || "Unknown"
                    });
                }
                
                
                assignments = tempAssignments.sort((a, b) => {
                    return new Date(b.dueDate).getTime() - new Date(a.dueDate).getTime();
                });
                
                totalAssignments = assignments.length;
                
                
                const urlAssignmentId = $page.url.searchParams.get('assignment');
                if (urlAssignmentId) {
                    console.log("Using assignment ID from URL:", urlAssignmentId);
                    selectedAssignment = urlAssignmentId;
                } else if ((!selectedAssignment || selectedAssignment === "all") && assignments.length > 0) {
                    console.log("Setting selected assignment to first assignment:", assignments[0].id);
                    selectedAssignment = assignments[0].id;
                }
                
                
                await applyFilters();
            } else {
                totalAssignments = 0;
            }
        } catch (error) {
            console.error("Error fetching assignments:", error);
            statsError = "Error fetching assignment data";
        } finally {
            loadingAssignments = false;
        }
    }
    
    
    const studentClassCache = new Map();
    
    
    async function getStudentClass(studentId: string): Promise<string> {
        
        if (studentClassCache.has(studentId)) {
            return studentClassCache.get(studentId);
        }
        
        try {
            const userRef = doc(db, 'users', studentId);
            const userSnap = await getDoc(userRef);
            
            if (userSnap.exists()) {
                const userData = userSnap.data();
                const studentClass = userData.class || "";
                
                
                studentClassCache.set(studentId, studentClass);
                
                return studentClass;
            }
        } catch (error) {
            console.error(`Error fetching class for student ${studentId}:`, error);
        }
        
        return "";
    }
    
    
    async function fetchStudentPerformance() {
        
        if (!teacherClass) {
            loadingStudents = false;
            return;
        }
        
        loadingStudents = true;
        students = [];
        
        try {
            
            const usersQuery = query(
                collection(db, 'users'),
                where('role', '==', 'student'),
                where('class', '==', teacherClass) 
            );
            
            const usersSnap = await getDocs(usersQuery);
            
            if (!usersSnap.empty) {
                
                totalStudents = usersSnap.size;
            } else {
                totalStudents = 0;
            }
        } catch (error) {
            console.error("Error fetching students:", error);
            statsError = "Error fetching student data";
        } finally {
            loadingStudents = false;
        }
    }
    
    
    async function updateStudentPerformanceForAssignment(assignmentId) {
        
        if (!teacherClass) {
            loadingStudents = false;
            return;
        }
        
        loadingStudents = true;
        students = [];
        
        try {
            
            const usersQuery = query(
                collection(db, 'users'),
                where('role', '==', 'student'),
                where('class', '==', teacherClass)
            );
            
            const usersSnap = await getDocs(usersQuery);
            
            if (!usersSnap.empty) {
                const tempStudents = [];
                
                
                for (const userDoc of usersSnap.docs) {
                    const userData = userDoc.data();
                    const studentId = userDoc.id;
                    
                    
                    const submissionsQuery = query(
                        collection(db, 'assignmentResult'),
                        where('userId', '==', studentId),
                        where('assignmentId', '==', assignmentId)
                    );
                    
                    const submissionsSnap = await getDocs(submissionsQuery);
                    
                    
                    let hasSubmitted = false;
                    let grade = 0;
                    let latestSubmissionDate = null;
                    let submissionId = null;
                    let submissionContent = "";
                    
                    
                    if (!submissionsSnap.empty) {
                        
                        let latestSubmission = null;
                        
                        submissionsSnap.forEach(submissionDoc => {
                            const submissionData = submissionDoc.data();
                            hasSubmitted = true;
                            
                            
                            if (submissionData.submittedAt) {
                                const submissionDate = new Date(submissionData.submittedAt);
                                if (!latestSubmissionDate || submissionDate > latestSubmissionDate) {
                                    latestSubmissionDate = submissionDate;
                                    latestSubmission = submissionData;
                                    submissionId = submissionDoc.id;
                                    submissionContent = submissionData.content || "";
                                }
                            }
                        });
                        
                        
                        if (latestSubmission) {
                            if (latestSubmission.teacherGrade) {
                                grade = parseFloat(latestSubmission.teacherGrade) || 0;
                            }
                        }
                    }
                    
                   
                    tempStudents.push({
                        id: studentId,
                        name: `${userData.firstName || ''} ${userData.lastName || ''}`.trim() || "Unknown Student",
                        class: userData.class || "Unknown",
                        averageGrade: grade, 
                        completedAssignments: hasSubmitted ? 1 : 0,
                        totalAssignments: 1, 
                        lastSubmission: latestSubmissionDate ? latestSubmissionDate.toISOString() : undefined,
                        performanceTrend: 'stable', 
                        
                        
                        submissionId: submissionId,
                        submissionContent: submissionContent,
                        grading: false, 
                        tempGrade: grade, 
                    });
                }
                
                
                students = tempStudents.sort((a, b) => {
                    
                    if (a.completedAssignments !== b.completedAssignments) {
                        return b.completedAssignments - a.completedAssignments;
                    }
                    
                    return a.name.localeCompare(b.name);
                });
                
               
                totalStudents = students.length;
            } else {
                totalStudents = 0;
            }
        } catch (error) {
            console.error("Error updating student performance for assignment:", error);
            statsError = "Error fetching student data for assignment";
        } finally {
            loadingStudents = false;
        }
    }
    
    
    async function applyFilters() {
        
        if (!selectedAssignment) {
            console.log("No assignment selected, skipping filters");
            return;
        }
        
        
        showGradeDistributionChart = false;
        
        loadingStats = true;
        
        try {
            
            const selectedAssignmentData = assignments.find(a => a.id === selectedAssignment);
            
            if (!selectedAssignmentData) {
                console.error("Selected assignment not found:", selectedAssignment);
                statsError = "Selected assignment not found";
                loadingStats = false;
                return;
            }
            
            console.log("Applying filters for assignment:", selectedAssignmentData.title);
            
            
            const submissionsQuery = query(
                collection(db, 'assignmentResult'),
                where('assignmentId', '==', selectedAssignment)
            );
            
            const submissionsSnap = await getDocs(submissionsQuery);
            
            
            let classSpecificSubmissions = 0;
            let gradeSum = 0;
            let gradedCount = 0;
            const validSubmissions = [];
            const submittedStudentIds = new Set(); 
            
            
            for (const submissionDoc of submissionsSnap.docs) {
                const submissionData = submissionDoc.data();
                
                
                const studentClass = await getStudentClass(submissionData.userId);
                
                
                if (studentClass === teacherClass) {
                    classSpecificSubmissions++;
                    validSubmissions.push(submissionData);
                    
                    
                    if (submissionData.userId) {
                        submittedStudentIds.add(submissionData.userId);
                    }
                    
                    
                    if (submissionData.teacherGrade) {
                        const grade = parseFloat(submissionData.teacherGrade);
                        if (!isNaN(grade)) {
                            gradeSum += grade;
                            gradedCount++;
                        }
                    }
                }
            }
            
            
            totalSubmissions = classSpecificSubmissions;
            
            
            if (totalStudents > 0) {
                const uniqueSubmitters = submittedStudentIds.size;
                completionRate = Math.min(100, Math.round((uniqueSubmitters / totalStudents) * 100));
            } else {
                completionRate = 0;
            }
            
            if (gradedCount > 0) {
                averageClassGrade = Math.round(gradeSum / gradedCount);
            } else {
                averageClassGrade = 0;
            }
            
            console.log("Submissions found:", classSpecificSubmissions);
            console.log("Graded submissions:", gradedCount);
            console.log("Average grade:", averageClassGrade);
            console.log("Completion rate:", completionRate);
            
            calculateGradeDistribution(validSubmissions);
            
            await updateStudentPerformanceForAssignment(selectedAssignment);
            
        } catch (error) {
            console.error("Error applying filters:", error);
            statsError = "Error filtering data";
        } finally {
            loadingStats = false;
        }
    }
    
    // Replace the renderGradeDistributionChart function with this improved version
function renderGradeDistributionChart() {
    if (!showGradeDistributionChart) {
        console.log("Chart display flag is false, not rendering");
        return;
    }
    
    console.log("Attempting to render grade distribution chart");
    
    if (typeof window === 'undefined') {
        console.error("Window object not available");
        return;
    }
    
    // Wait for Chart.js to be available
    if (!window.Chart) {
        console.log("Chart.js not yet available, retrying in 500ms");
        setTimeout(renderGradeDistributionChart, 500);
        return;
    }
    
    // Wait for canvas element to be available in DOM
    const canvas = document.getElementById('gradeDistributionChart');
    if (!canvas) {
        setTimeout(renderGradeDistributionChart, 300);
        return;
    }
    
    // Check if we have data to display
    if (!gradeDistribution || gradeDistribution.length === 0 || gradeDistribution.every(d => d.count === 0)) {
        console.log("No grade distribution data available");
        return;
    }
    
    // Clean up existing chart
    if (gradeDistributionChartInstance) {
        try {
            gradeDistributionChartInstance.destroy();
            gradeDistributionChartInstance = null;
        } catch (error) {
            console.error("Error destroying existing chart:", error);
        }
    }
    
    try {
        console.log("Creating new chart instance");
        const ctx = canvas.getContext('2d');
        
        gradeDistributionChartInstance = new window.Chart(ctx, {
            type: 'bar',
            data: {
                labels: gradeDistribution.map(d => d.range),
                datasets: [{
                    label: 'Number of Students',
                    data: gradeDistribution.map(d => d.count),
                    backgroundColor: [
                        '#ef4444', // red (0-49)
                        '#f97316', // orange (50-59)
                        '#f59e0b', // amber (60-69)
                        '#84cc16', // lime (70-79)
                        '#22c55e', // green (80-89)
                        '#14b8a6'  // teal (90-100)
                    ].reverse(),
                    borderColor: 'rgba(255, 255, 255, 0.5)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            precision: 0
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                const index = context.dataIndex;
                                return `Students: ${gradeDistribution[index].count} (${gradeDistribution[index].percentage}%)`;
                            }
                        }
                    }
                }
            }
        });
        
        console.log("Chart rendered successfully");
    } catch (error) {
        console.error("Error creating chart:", error);
    }
}

    // Replace the calculateGradeDistribution function
function calculateGradeDistribution(submissions) {
    const ranges = [
        { min: 90, max: 100, label: "90-100" },
        { min: 80, max: 89, label: "80-89" },
        { min: 70, max: 79, label: "70-79" },
        { min: 60, max: 69, label: "60-69" },
        { min: 50, max: 59, label: "50-59" },
        { min: 0, max: 49, label: "0-49" }
    ];
    
    const distribution = ranges.map(range => ({
        range: range.label,
        count: 0,
        percentage: 0
    }));
    
    let gradedCount = 0;
    
    if (submissions && submissions.length > 0) {
        console.log("Processing", submissions.length, "submissions for grade distribution");
        
        submissions.forEach(submission => {
            if (submission.teacherGrade) {
                const grade = parseFloat(submission.teacherGrade);
                if (!isNaN(grade)) {
                    gradedCount++;
                    
                    for (let i = 0; i < ranges.length; i++) {
                        if (grade >= ranges[i].min && grade <= ranges[i].max) {
                            distribution[i].count++;
                            break;
                        }
                    }
                }
            }
        });
    }
    
    if (gradedCount > 0) {
        distribution.forEach(item => {
            item.percentage = Math.round((item.count / gradedCount) * 100);
        });
    }
    
    gradeDistribution = distribution;
    
    console.log("Grade distribution data calculated:", gradeDistribution);
    
    // Only if we have actual data, show the chart
    if (gradedCount > 0) {
        setTimeout(() => {
            showGradeDistributionChart = true;
            setTimeout(renderGradeDistributionChart, 300);
        }, 500);
    } else {
        console.log("No graded submissions found, not showing chart");
        showGradeDistributionChart = false;
    }
}
    
    
    
    function formatDate(dateString: string): string {
        if (!dateString) return "No date";
        const date = new Date(dateString);
        return date.toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
    }
    
    function formatDateTime(dateTimeString: string): string {
        if (!dateTimeString) return "No date";
        const date = new Date(dateTimeString);
        return date.toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    }
    
    function getGradeColor(grade: number): string {
        if (grade >= 90) return 'grade-a';
        if (grade >= 80) return 'grade-b';
        if (grade >= 70) return 'grade-c';
        if (grade >= 60) return 'grade-d';
        return 'grade-f';
    }
    
    function getStatusDisplay(status: string): string {
        const normalizedStatus = (status || '').toLowerCase().trim();
        
        switch (normalizedStatus) {
            case 'completed':
                return 'Completed';
            case 'in-progress':
                return 'In Progress';
            case 'not-started':
                return 'Not Started';
            case 'closed':
                return 'Closed';
            default:
                return status || 'Unknown';
        }
    }
    
    function startGrading(student) {
        students = students.map(s => ({...s, grading: false}));
        
        students = students.map(s => {
            if (s.id === student.id) {
                return {...s, grading: true, tempGrade: s.averageGrade || ""};
            }
            return s;
        });
        
        gradeMessage = "";
    }

    function cancelGrading(student) {
        students = students.map(s => {
            if (s.id === student.id) {
                return {...s, grading: false};
            }
            return s;
        });
        
        gradeMessage = "";
    }

    async function saveGrade(student) {
        if (!student.submissionId) {
            gradeMessage = "Error: No submission found to grade";
            gradeMessageType = "error";
            return;
        }
        
        const grade = parseFloat(student.tempGrade);
        if (isNaN(grade) || grade < 0 || grade > 100) {
            gradeMessage = "Grade must be a number between 0 and 100";
            gradeMessageType = "error";
            return;
        }
        
        gradingInProgress = true;
        
        try {
            const submissionRef = doc(db, 'assignmentResult', student.submissionId);
            
            await updateDoc(submissionRef, {
                teacherGrade: grade.toString(),
                gradedAt: new Date().toISOString(),
                gradedBy: userId
            });
            
            students = students.map(s => {
                if (s.id === student.id) {
                    return {
                        ...s, 
                        grading: false, 
                        averageGrade: grade
                    };
                }
                return s;
            });
            
            gradeMessage = `Grade saved successfully for ${student.name}`;
            gradeMessageType = "success";
            
            setTimeout(() => applyFilters(), 1500);
        } catch (error) {
            console.error("Error saving grade:", error);
            gradeMessage = `Error saving grade: ${error.message}`;
            gradeMessageType = "error";
        } finally {
            gradingInProgress = false;
            
            setTimeout(() => {
                gradeMessage = "";
            }, 5000);
        }
    }

    function viewSubmission(student) {
        if (student.submissionId) {
            goto(`/teacher/assignment/${courseId}/${selectedAssignment}?mode=teacher&userId=${student.id}`);
        } else {
            gradeMessage = "No submission found for this student";
            gradeMessageType = "error";
            
            setTimeout(() => {
                gradeMessage = "";
            }, 3000);
        }
    }
    
    function refreshAllData() {
        if (!teacherClass) return;
        
        fetchAssignments().then(() => {
            fetchStudentPerformance().then(() => {
                applyFilters(); 
            });
        });
    }
    
    function viewAssignmentDetails(assignmentId) {
        console.log("Viewing details for assignment:", assignmentId);
        
        if (selectedAssignment === assignmentId) {
            console.log("Already viewing this assignment");
            return;
        }
        
        selectedAssignment = assignmentId;
        
        applyFilters();
    }
    
    function getSelectedAssignmentName() {
        const selected = assignments.find(a => a.id === selectedAssignment);
        return selected ? selected.title : "Selected Assignment";
    }
    
    function cleanup() {
    if (gradeDistributionChartInstance) {
        try {
            gradeDistributionChartInstance.destroy();
            gradeDistributionChartInstance = null;
        } catch (error) {
            console.error("Error destroying chart during cleanup:", error);
        }
    }
}
    
    onMount(async () => {
    async function loadChartJS() {
        return new Promise((resolve) => {
            if (window.Chart) {
                console.log("Chart.js already loaded");
                resolve(true);
                return;
            }
            
            console.log("Waiting for Chart.js to load...");
            
            // Check for Chart.js every 100ms
            const checkInterval = setInterval(() => {
                if (window.Chart) {
                    console.log("Chart.js loaded successfully");
                    clearInterval(checkInterval);
                    resolve(true);
                }
            }, 100);
            
            // Set a timeout to avoid infinite waiting
            setTimeout(() => {
                if (!window.Chart) {
                    console.error("Failed to load Chart.js within timeout");
                    clearInterval(checkInterval);
                    resolve(false);
                }
            }, 5000);
        });
    }
    
    await checkUserRole();
    
    if (teacherClass) {
        await fetchAssignments();
        await fetchStudentPerformance();
        
        if (selectedAssignment && !$page.url.searchParams.has('assignment')) {
            await applyFilters();
        }
        
        // Ensure Chart.js is loaded
        const chartJsLoaded = await loadChartJS();
        
        if (chartJsLoaded && showGradeDistributionChart) {
            renderGradeDistributionChart();
        }
    }
    
    return cleanup;
});
</script>

<svelte:head>
   
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</svelte:head>

<main class="teacher-assignment-dashboard">

    <div class="container">
        <UnderscoreDiv>
            <div class="header-container">
                <SubheadingBar title="Assignment Statistics" />
                
                <div class="header-actions">
                    {#if userLoading}
                        <div class="role-checking">
                            <span class="loading-spinner-tiny"></span> Loading...
                        </div>
                    {:else}
                        <button 
                            class="back-button" 
                            on:click={() => goto('/teacher/assignment/')}
                        >
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <line x1="19" y1="12" x2="5" y2="12"></line>
                                <polyline points="12 19 5 12 12 5"></polyline>
                            </svg>
                            Back to Assignments
                        </button>
                        
                        <div class="teacher-class-badge">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M3 3v18h18"></path>
                                <path d="M3 15L9 9l4 4 8-8"></path>
                            </svg>
                            {teacherClass ? `Class ${teacherClass}` : 'No Class Assigned'}
                        </div>
                        
                        <button 
                            class="refresh-button" 
                            on:click={refreshAllData} 
                            disabled={!teacherClass}
                        >
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M21.5 2v6h-6M2.5 22v-6h6M2 11.5a10 10 0 0 1 18.8-4.3M22 12.5a10 10 0 0 1-18.8 4.2"/>
                            </svg>
                            Refresh Data
                        </button>
                    {/if}
                </div>
            </div>
        </UnderscoreDiv>

        {#if !teacherClass && !userLoading}
            <UnderscoreDiv>
                <div class="no-class-warning">
                    <div class="warning-icon">⚠️</div>
                    <div class="warning-message">
                        <h3>No Class Assigned</h3>
                        <p>You don't have a class assigned to your account. Please contact an administrator to assign you to a class before viewing statistics.</p>
                    </div>
                </div>
            </UnderscoreDiv>
        {/if}

        {#if teacherClass}
        

            <div class="stats-row">
                <UnderscoreDiv>
                    <div class="stat-card">
                        <div class="stat-icon students">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                                <circle cx="9" cy="7" r="4"></circle>
                                <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
                                <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                            </svg>
                        </div>
                        <div class="stat-content">
                            <div class="stat-title">Students in Class {teacherClass}</div>
                            <div class="stat-value">{loadingStats ? '-' : totalStudents}</div>
                            <div class="stat-desc">Total students</div>
                        </div>
                    </div>
                </UnderscoreDiv>

                <UnderscoreDiv>
                    <div class="stat-card">
                        <div class="stat-icon completion">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                                <polyline points="22 4 12 14.01 9 11.01"></polyline>
                            </svg>
                        </div>
                        <div class="stat-content">
                            <div class="stat-title">Submission Rate</div>
                            <div class="stat-value">{loadingStats ? '-' : completionRate}%</div>
                            <div class="stat-desc">Of students submitted</div>
                        </div>
                    </div>
                </UnderscoreDiv>

                <UnderscoreDiv>
                    <div class="stat-card">
                        <div class="stat-icon grade">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M12 20h9"></path>
                                <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"></path>
                            </svg>
                        </div>
                        <div class="stat-content">
                            <div class="stat-title">{getSelectedAssignmentName()} Average</div>
                            <div class="stat-value {getGradeColor(averageClassGrade)}">{loadingStats ? '-' : averageClassGrade}</div>
                            <div class="stat-desc">Average score</div>
                        </div>
                    </div>
                </UnderscoreDiv>

                <UnderscoreDiv>
                    <div class="stat-card">
                        <div class="stat-icon submissions">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                                <polyline points="14 2 14 8 20 8"></polyline>
                                <line x1="16" y1="13" x2="8" y2="13"></line>
                                <line x1="16" y1="17" x2="8" y2="17"></line>
                                <polyline points="10 9 9 9 8 9"></polyline>
                            </svg>
                        </div>
                        <div class="stat-content">
                            <div class="stat-title">Total Submissions</div>
                            <div class="stat-value">{loadingStats ? '-' : totalSubmissions}</div>
                            <div class="stat-desc">For this assignment</div>
                        </div>
                    </div>
                </UnderscoreDiv>
            </div>

            <div class="charts-row">
                <UnderscoreDiv>
                    <div class="chart-container">
                        <h3>{getSelectedAssignmentName()} - Grade Distribution</h3>
                        {#if loadingStats}
                            <div class="loading-chart">
                                <div class="loading-spinner"></div>
                                <p>Loading chart data...</p>
                            </div>
                        {:else if !gradeDistribution || gradeDistribution.length === 0 || gradeDistribution.every(d => d.count === 0)}
                            <div class="empty-chart">
                                <p>No graded submissions available for this assignment</p>
                            </div>
                        {:else}
                            <div class="chart-wrapper" id="gradeDistributionContainer">
                                <canvas id="gradeDistributionChart" width="400" height="300"></canvas>
                            </div>
                        {/if}
                    </div>
                </UnderscoreDiv>

                <UnderscoreDiv>
                    <div class="chart-container">
                        <h3>Submission Status</h3>
                        {#if loadingStats}
                            <div class="loading-chart">
                                <div class="loading-spinner"></div>
                                <p>Loading submission data...</p>
                            </div>
                        {:else}
                            <div class="submission-summary">
                                <div class="submission-stat">
                                    <div class="stat-circle submitted">
                                        <span class="stat-number">{completionRate}%</span>
                                    </div>
                                    <div class="stat-label">Submitted</div>
                                </div>
                                
                                <div class="submission-stat">
                                    <div class="stat-circle not-submitted">
                                        <span class="stat-number">{100 - completionRate}%</span>
                                    </div>
                                    <div class="stat-label">Not Submitted</div>
                                </div>
                            </div>
                        {/if}
                    </div>
                </UnderscoreDiv>
            </div>

<UnderscoreDiv>
    <div class="submissions-section">
        <h3>Student Submissions for {getSelectedAssignmentName()}</h3>
        
        {#if loadingStudents}
            <div class="loading-table">
                <div class="loading-spinner"></div>
                <p>Loading submissions...</p>
            </div>
        {:else if students.length === 0}
            <div class="empty-table">
                <p>No student submissions available for this assignment</p>
            </div>
        {:else}
            <div class="table-wrapper">
                <table class="submissions-table">
                    <thead>
                        <tr>
                            <th>Student</th>
                            <th>Submitted At</th>
                            <th>Status</th>
                            <th>Grade</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {#each students as student}
                            <tr>
                                <td>{student.name}</td>
                                <td>{student.lastSubmission ? formatDateTime(student.lastSubmission) : 'Not submitted'}</td>
                                <td>
                                    <span class="status-badge {student.completedAssignments > 0 ? 'submitted' : 'not-submitted'}">
                                        {student.completedAssignments > 0 ? 'Submitted' : 'Not submitted'}
                                    </span>
                                </td>
                                <td class="grade-cell">
                                    {#if student.grading}
                                        <input 
                                            type="number" 
                                            class="grade-input" 
                                            bind:value={student.tempGrade} 
                                            min="0" 
                                            max="100"
                                            placeholder="0-100"
                                        />
                                    {:else}
                                        <span class="grade-badge {getGradeColor(student.averageGrade)}">
                                            {student.averageGrade || '-'}
                                        </span>
                                    {/if}
                                </td>
                                <td>
                                    {#if student.completedAssignments > 0}
                                        {#if student.grading}
                                            <div class="grading-actions">
                                                <button 
                                                    class="save-grade-btn" 
                                                    on:click={() => saveGrade(student)}
                                                    disabled={!student.tempGrade}
                                                >
                                                    Save
                                                </button>
                                                <button 
                                                    class="cancel-grade-btn" 
                                                    on:click={() => cancelGrading(student)}
                                                >
                                                    Cancel
                                                </button>
                                            </div>
                                        {:else}
                                            <div class="submission-actions">
                                                <button 
                                                    class="view-btn" 
                                                    on:click={() => viewSubmission(student)}
                                                >
                                                    View
                                                </button>
                                                <span class="grade-status {student.averageGrade ? 'graded' : 'not-graded'}">
                                                    {student.averageGrade ? 'Graded' : 'Not Graded'}
                                                </span>
                                            </div>
                                        {/if}
                                    {:else}
                                        <span class="no-submission">No submission</span>
                                    {/if}
                                </td>
                            </tr>
                        {/each}
                    </tbody>
                </table>
            </div>
            
            {#if gradeMessage}
                <div class="grade-message {gradeMessageType}">
                    {gradeMessage}
                </div>
            {/if}
        {/if}
    </div>
</UnderscoreDiv>

            

<UnderscoreDiv>
    <div class="assignment-statistics">
        <h3>Class {teacherClass} Assignment Statistics</h3>
        
        {#if loadingAssignments}
            <div class="loading-table">
                <div class="loading-spinner"></div>
                <p>Loading assignment data...</p>
            </div>
        {:else if assignments.length === 0}
            <div class="empty-table">
                <p>No assignments available for this class</p>
            </div>
        {:else}
            <div class="table-wrapper">
                <table class="assignments-table">
                    <thead>
                        <tr>
                            <th>Assignment</th>
                            <th>Due Date</th>
                            <th>Status</th>
                            <th>Average Grade</th>
                            <th>Submissions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {#each assignments as assignment}
                            <tr class={assignment.id === selectedAssignment ? 'selected-row' : ''}>
                                <td>{assignment.title}</td>
                                <td>{formatDate(assignment.dueDate)}</td>
                                <td class="status-cell">
                                    <span class="status-badge {assignment.status}">
                                        {getStatusDisplay(assignment.status)}
                                    </span>
                                </td>
                                <td class="grade-cell">
                                    {#if assignment.avgGrade}
                                        <span class="grade-badge {getGradeColor(assignment.avgGrade)}">
                                            {assignment.avgGrade}
                                        </span>
                                    {:else}
                                        -
                                    {/if}
                                </td>
                                <td>{assignment.submissions || 0}</td>
                            </tr>
                        {/each}
                    </tbody>
                </table>
            </div>
        {/if}
    </div>
</UnderscoreDiv>
        {/if}
    </div>
</main>

<style lang="scss">
    main {
        position: relative;
        height: 100%;
        width: 100%;
        background-color: var(--clr-content-background);
    }

    /* Hide the "Add new exam" button */
    .teacher-assignment-dashboard :global(div.s-EHBj4WKrFE0n),
    .teacher-assignment-dashboard :global(div[title="Add new exam"]) {
    display: none !important;
}

    .container {
        padding: 1.25rem 2.5rem;
        max-width: 1440px;
        margin: 0 auto;
    }
    
    .header-container {
        display: flex;
        justify-content: space-between;
        align-items: center;
        width: 100%;
    }
    
    .header-actions {
        display: flex;
        align-items: center;
        gap: 10px;
    }
    
    .back-button {
        display: flex;
        align-items: center;
        gap: 6px;
        padding: 8px 12px;
        background-color: #f3f4f6;
        color: #4b5563;
        border: none;
        border-radius: 6px;
        font-size: 14px;
        font-weight: 500;
        cursor: pointer;
        transition: all 0.2s;
        
        &:hover {
            background-color: #e5e7eb;
        }
    }
    
    .no-class-warning {
        display: flex;
        align-items: flex-start;
        gap: 15px;
        padding: 15px;
        background-color: #fff3cd;
        border-radius: 8px;
        border-left: 4px solid #f59e0b;
        
        .warning-icon {
            font-size: 24px;
        }
        
        .warning-message {
            h3 {
                margin: 0 0 8px 0;
                color: #92400e;
                font-size: 16px;
            }
            
            p {
                margin: 0;
                color: #7c3aed;
                font-size: 14px;
            }
        }
    }
    
    .role-checking {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        color: #6b7280;
        font-size: 0.875rem;
    }
    
    .loading-spinner-tiny {
        display: inline-block;
        width: 12px;
        height: 12px;
        border: 2px solid rgba(0, 0, 0, 0.1);
        border-radius: 50%;
        border-left-color: #93c5fd;
        animation: spin 1s linear infinite;
    }
    
    .teacher-class-badge {
        display: flex;
        align-items: center;
        gap: 6px;
        padding: 6px 12px;
        background-color: #e0f2fe;
        color: #0c4a6e;
        border-radius: 6px;
        font-weight: 500;
        font-size: 14px;
    }
    
    .refresh-button {
        display: flex;
        align-items: center;
        gap: 6px;
        padding: 8px 12px;
        background-color: #f3f4f6;
        color: #4b5563;
        border: none;
        border-radius: 6px;
        font-size: 14px;
        font-weight: 500;
        cursor: pointer;
        transition: all 0.2s;
        
        svg {
            transition: transform 0.3s;
        }
        
        &:hover:not(:disabled) {
            background-color: #e5e7eb;
            
            svg {
                transform: rotate(180deg);
            }
        }
        
        &:disabled {
            background-color: #f3f4f6;
            color: #9ca3af;
            cursor: not-allowed;
            opacity: 0.7;
        }
    }
    
    .stats-row {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 20px;
        margin-bottom: 20px;
    }
    
    .stat-card {
        display: flex;
        align-items: center;
        gap: 15px;
        padding: 20px;
        border-radius: 8px;
        
        .stat-icon {
            width: 48px;
            height: 48px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            
            svg {
                color: white;
            }
            
            &.students {
                background-color: #3b82f6;
            }
            
            &.completion {
                background-color: #10b981;
            }
            
            &.grade {
                background-color: #f59e0b;
            }
            
            &.submissions {
                background-color: #8b5cf6;
            }
        }
        
        .stat-content {
            .stat-title {
                font-size: 14px;
                color: #6b7280;
                margin-bottom: 5px;
            }
            
            .stat-value {
                font-size: 24px;
                font-weight: 700;
                color: #111827;
                
                &.grade-a { color: #16a34a; }
                &.grade-b { color: #65a30d; }
                &.grade-c { color: #ca8a04; }
                &.grade-d { color: #ea580c; }
                &.grade-f { color: #dc2626; }
            }
            
            .stat-desc {
                font-size: 12px;
                color: #9ca3af;
            }
        }
    }
    
    .charts-row {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 20px;
        margin-bottom: 20px;
    }
    
    .chart-container {
        padding: 20px;
        border-radius: 8px;
        
        h3 {
            font-size: 16px;
            font-weight: 600;
            color: #111827;
            margin-top: 0;
            margin-bottom: 15px;
        }
        
        &.full-width {
            grid-column: 1 / -1;
        }
    }
    
    .chart-wrapper {
        position: relative;
        height: 300px;
        width: 100%;
        
        canvas {
            width: 100% !important;
            height: 100% !important;
        }
    }
    
    .loading-chart, .empty-chart {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        height: 300px;
        width: 100%;
        
        p {
            margin-top: 15px;
            color: #6b7280;
            font-size: 14px;
        }
    }

    .submission-summary {
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 40px;
        height: 300px;
    }

    .submission-stat {
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 15px;
    }

    .stat-circle {
        width: 120px;
        height: 120px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        
        &.submitted {
            background-color: #dcfce7;
            border: 4px solid #22c55e;
        }
        
        &.not-submitted {
            background-color: #fee2e2;
            border: 4px solid #ef4444;
        }
    }

    .stat-number {
        font-size: 28px;
        font-weight: 700;
        color: #111827;
    }

    .stat-label {
        font-size: 16px;
        font-weight: 500;
        color: #4b5563;
    }
    
    .loading-spinner {
        width: 30px;
        height: 30px;
        border: 3px solid rgba(0, 0, 0, 0.1);
        border-radius: 50%;
        border-left-color: #3b82f6;
        animation: spin 1s linear infinite;
    }
    
    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }
    
    .student-performance, .assignment-statistics {
        padding: 20px;
        border-radius: 8px;
    }
    
    .table-wrapper {
        overflow-x: auto;
    }
    
    .performance-table, .assignments-table {
        width: 100%;
        border-collapse: collapse;
        font-size: 14px;
        
        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #e5e7eb;
        }
        
        th {
            font-weight: 600;
            color: #4b5563;
            background-color: #f9fafb;
            position: sticky;
            top: 0;
        }
        
        tr:hover {
            background-color: #f9fafb;
        }
        
        .grade-cell {
            text-align: center;
        }
        
        .status-cell {
            text-align: center;
        }
    }
    
    .selected-row {
        background-color: #f0f9ff !important;
        border-left: 3px solid #3b82f6;
        
        &:hover {
            background-color: #e0f2fe !important;
        }
    }
    
    .view-details-btn {
        padding: 4px 8px;
        background-color: #f3f4f6;
        color: #4b5563;
        border: 1px solid #d1d5db;
        border-radius: 4px;
        font-size: 12px;
        cursor: pointer;
        transition: all 0.2s;
        
        &:hover:not(:disabled) {
            background-color: #e5e7eb;
        }
        
        &:disabled {
            background-color: #e0f2fe;
            color: #0284c7;
            border-color: #0ea5e9;
            cursor: default;
        }
    }
    
    .loading-table, .empty-table {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        padding: 40px 0;
        
        p {
            margin-top: 15px;
            color: #6b7280;
            font-size: 14px;
        }
    }
    
    .grade-badge {
        display: inline-block;
        padding: 4px 8px;
        border-radius: 9999px;
        font-weight: 600;
        font-size: 12px;
        
        &.grade-a { background-color: #dcfce7; color: #16a34a; }
        &.grade-b { background-color: #ecfccb; color: #65a30d; }
        &.grade-c { background-color: #fef3c7; color: #ca8a04; }
        &.grade-d { background-color: #ffedd5; color: #ea580c; }
        &.grade-f { background-color: #fee2e2; color: #dc2626; }
    }
    
    .status-badge {
        display: inline-block;
        padding: 4px 8px;
        border-radius: 9999px;
        font-weight: 500;
        font-size: 12px;
        text-transform: capitalize;
        
        &.completed { background-color: #dcfce7; color: #16a34a; }
        &.in-progress { background-color: #e0f2fe; color: #0284c7; }
        &.not-started { background-color: #f3f4f6; color: #6b7280; }
        &.closed { background-color: #fee2e2; color: #dc2626; }
        &.unknown { background-color: #f3f4f6; color: #6b7280; }
        
        &.submitted { background-color: #dcfce7; color: #16a34a; }
        &.not-submitted { background-color: #fee2e2; color: #dc2626; }
    }
    
    .submissions-section {
        padding: 20px;
        border-radius: 8px;
        
        h3 {
            font-size: 16px;
            font-weight: 600;
            color: #111827;
            margin-top: 0;
            margin-bottom: 15px;
        }
    }

    .submissions-table {
        width: 100%;
        border-collapse: collapse;
        font-size: 14px;
        
        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #e5e7eb;
        }
        
        th {
            font-weight: 600;
            color: #4b5563;
            background-color: #f9fafb;
            position: sticky;
            top: 0;
        }
        
        tr:hover {
            background-color: #f9fafb;
        }
        
        .grade-input {
            width: 80px;
            padding: 6px 8px;
            border: 1px solid #d1d5db;
            border-radius: 4px;
            font-size: 14px;
            text-align: center;
            
            &:focus {
                outline: none;
                border-color: #3b82f6;
                box-shadow: 0 0 0 1px rgba(59, 130, 246, 0.3);
            }
        }
        
        .status-badge {
            &.submitted {
                background-color: #dcfce7;
                color: #16a34a;
            }
            
            &.not-submitted {
                background-color: #fee2e2;
                color: #dc2626;
            }
        }
        
        .submission-actions, .grading-actions {
            display: flex;
            gap: 8px;
        }
        
        .view-btn, .grade-btn, .edit-grade-btn, .save-grade-btn, .cancel-grade-btn {
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 500;
            cursor: pointer;
            border: 1px solid;
            transition: all 0.2s;
        }
        
        .view-btn {
            background-color: #f3f4f6;
            color: #4b5563;
            border-color: #d1d5db;
            
            &:hover {
                background-color: #e5e7eb;
            }
        }
        
        .grade-btn {
            background-color: #4f46e5;
            color: white;
            border-color: #4338ca;
            
            &:hover {
                background-color: #4338ca;
            }
        }
        
        .edit-grade-btn {
            background-color: #f59e0b;
            color: white;
            border-color: #d97706;
            
            &:hover {
                background-color: #d97706;
            }
        }
        
        .save-grade-btn {
            background-color: #10b981;
            color: white;
            border-color: #059669;
            
            &:hover:not(:disabled) {
                background-color: #059669;
            }
            
            &:disabled {
                opacity: 0.6;
                cursor: not-allowed;
            }
        }
        
        .cancel-grade-btn {
            background-color: #f3f4f6;
            color: #4b5563;
            border-color: #d1d5db;
            
            &:hover {
                background-color: #e5e7eb;
            }
        }
        
        .no-submission {
            color: #9ca3af;
            font-style: italic;
            font-size: 12px;
        }
    }

    .grade-message {
        margin-top: 15px;
        padding: 10px 15px;
        border-radius: 6px;
        font-size: 14px;
        
        &.success {
            background-color: #dcfce7;
            color: #16a34a;
            border-left: 4px solid #16a34a;
        }
        
        &.error {
            background-color: #fee2e2;
            color: #dc2626;
            border-left: 4px solid #dc2626;
        }
    }
    
    .grade-status {
        padding: 4px 8px;
        border-radius: 4px;
        font-size: 12px;
        
        &.graded {
            background-color: #dcfce7;
            color: #16a34a;
        }
        
        &.not-graded {
            background-color: #fee2e2;
            color: #dc2626;
        }
    }
    
    @media (max-width: 1280px) {
        .stats-row {
            grid-template-columns: repeat(2, 1fr);
        }
    }
    
    @media (max-width: 768px) {
        .container {
            padding: 1rem 1rem;
        }
        
        .header-container {
            flex-direction: column;
            align-items: flex-start;
            gap: 10px;
        }
        
        .header-actions {
            width: 100%;
            flex-wrap: wrap;
        }
        
        .stats-row {
            grid-template-columns: 1fr;
        }
        
        .charts-row {
            grid-template-columns: 1fr;
        }
    }
</style>