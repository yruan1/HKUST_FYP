<script lang="ts">
	import ChatBotWidget from '$lib/components/ChatBotWidget.svelte';
	import SearchHeader from '$lib/components/SearchHeader.svelte';
	import AnnouncementCard from '$lib/components/AnnouncementCardT.svelte';
	import { onMount } from 'svelte';
	import { db } from '$lib/firebase'; // Import Firestore
	import { collection, doc, updateDoc, setDoc, addDoc, serverTimestamp, deleteDoc } from 'firebase/firestore';
	import firebase from 'firebase/compat/app';
	export let data;

	console.log('announcements : ', data.announcements);
	$: sortedAnnouncements = data.announcements
		? [...data.announcements].sort((a, b) => b.createdAt.seconds - a.createdAt.seconds)
		: [];
	let dialog: HTMLDialogElement;

	onMount(async () => {});

	function showPostDialog() {
		dialog.showModal();
	}

	function closePostDialog() {
		dialog.close();
	}

	let title = '';
	let content = '';
	let createAt = '';
	let classId = data.userInfo.class;

	async function submitForm(event: Event) {
		event.preventDefault();
		try {
			const docRef = await addDoc(collection(db, 'classes/' + classId + '/announcements'), {
				title,
				content,
				createdAt: serverTimestamp(),
				author: data.userInfo.firstName + ' ' + data.userInfo.lastName
			});

			// Create a new announcement object with the document ID
			const newAnnouncement = {
				id: docRef.id,
				title,
				content,
				author: data.userInfo.firstName + ' ' + data.userInfo.lastName,
				createdAt: { seconds: Date.now() / 1000 }
			};

			// Update local state with the new announcement
			sortedAnnouncements = [newAnnouncement, ...sortedAnnouncements];
			
			// Reset form and close dialog
			title = '';
			content = '';
			closePostDialog();
		} catch (error) {
			console.error('Error adding announcement: ', error);
		}
	}

	let editDialog: HTMLDialogElement;
	let editingAnnouncement: any = null;
	let editTitle = '';
	let editContent = '';

	function showEditDialog(announcement: any) {
		editingAnnouncement = announcement;
		editTitle = announcement.title;
		editContent = announcement.content;
		editDialog.showModal();
	}

	function closeEditDialog() {
		editDialog.close();
		editingAnnouncement = null;
		editTitle = '';
		editContent = '';
	}

	async function submitEditForm(event: Event) {
		event.preventDefault();
		if (!editingAnnouncement?.id) {
			console.error('No announcement ID found');
			return;
		}

		try {
			// Update in Firestore directly
			const docRef = doc(db, 'classes', classId, 'announcements', editingAnnouncement.id);
			await updateDoc(docRef, {
				title: editTitle,
				content: editContent,
				updatedAt: serverTimestamp()
			});

			// Update the announcement in the local state
			const updatedAnnouncement = {
				...editingAnnouncement,
				title: editTitle,
				content: editContent,
				updatedAt: { seconds: Date.now() / 1000 }
			};

			sortedAnnouncements = sortedAnnouncements.map(a => 
				a.id === editingAnnouncement.id ? updatedAnnouncement : a
			);

			closeEditDialog();
		} catch (error) {
			console.error('Error updating announcement:', error);
		}
	}

	async function deleteAnnouncement(announcement: any) {
		if (!announcement?.id) {
			console.error('No announcement ID found');
			return;
		}

		if (confirm('Are you sure you want to delete this announcement?')) {
			try {
				// Delete from Firestore directly
				const docRef = doc(db, 'classes', classId, 'announcements', announcement.id);
				await deleteDoc(docRef);

				// Remove the announcement from the local state
				sortedAnnouncements = sortedAnnouncements.filter(a => a.id !== announcement.id);
			} catch (error) {
				console.error('Error deleting announcement:', error);
			}
		}
	}
</script>

<main>
	<ChatBotWidget></ChatBotWidget>

	<div class="content-container">
		<div><h1>Announcement</h1></div>
		<button id="postbtn" on:click={showPostDialog}>New Post</button>
		<div class="announcements-container">
			{#each sortedAnnouncements as announcement}
				<AnnouncementCard
					title={announcement.title}
					content={announcement.content}
					author={announcement.author}
					createdAt={announcement.createdAt}
					onEdit={() => showEditDialog(announcement)}
					onDelete={() => deleteAnnouncement(announcement)}
				/>
			{/each}
		</div>
	</div>
	<dialog bind:this={dialog} id="post-dialog">
		<h2>New Post</h2>

		<form action="" on:submit={submitForm}>
			<div>
				<div>
					<div><label for="title">Title</label></div>
					<input
						type="text"
						name="title"
						id="title"
						bind:value={title}
						required
						placeholder="Enter title"
					/>
				</div>
				<div>
					<div><label for="content">Content</label></div>
					<textarea
						name="content"
						id="content"
						rows="5"
						cols="50"
						bind:value={content}
						required
						placeholder="Enter contet"
					></textarea>
				</div>
			</div>
			<div class="button-div">
				<button type="submit">Submit</button>
				<button type="button" on:click={closePostDialog}>Cancel</button>
			</div>
		</form>
	</dialog>

	<dialog bind:this={editDialog} id="edit-dialog">
		<h2>Edit Post</h2>
		<form action="" on:submit={submitEditForm}>
			<div>
				<div><label for="editTitle">Title</label></div>
				<input
					type="text"
					name="editTitle"
					id="editTitle"
					bind:value={editTitle}
					required
					placeholder="Enter title"
				/>
			</div>
			<div>
				<div><label for="editContent">Content</label></div>
				<textarea
					name="editContent"
					id="editContent"
					rows="5"
					cols="50"
					bind:value={editContent}
					required
					placeholder="Enter content"
				></textarea>
			</div>
			<div class="button-div">
				<button type="submit">Update</button>
				<button type="button" on:click={closeEditDialog}>Cancel</button>
			</div>
		</form>
	</dialog>
</main>

<style lang="scss">
	main {
		height: 100%;
		width: 100%;
		background-color: var(--clr-content-background);
	}

	button {
		width: 100%;
		background-color: var(--clr-nav);
		border-radius: 10px;

		cursor: pointer;
		&:hover {
			background-color: var(--clr-hover-backgroud);
			color: var(--clr-hover-font);
		}
	}

	#postbtn {
		height: 44px;
		width: 140px;
		margin-bottom: 1.5rem;
		background: linear-gradient(135deg, #6b46c1 0%, #4834d4 100%);
		color: white;
		font-weight: 500;
		font-size: 1rem;
		border: none;
		box-shadow: 0 4px 12px rgba(107, 70, 193, 0.2);
		transition: all 0.3s ease;

		&:hover {
			transform: translateY(-2px);
			background: linear-gradient(135deg, #805ad5 0%, #553c9a 100%);
			box-shadow: 0 6px 16px rgba(107, 70, 193, 0.3);
		}
	}

	dialog {
		width: 600px;
		height: 600px;
		border: none;
		border-radius: 20px;
		background-color: var(--clr-nav);
		color: var(--clr-font);
		padding: 2.5rem;
		box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
		max-height: 85vh;
		overflow-y: auto;

		h2 {
			margin-bottom: 2rem;
			font-size: 1.75rem;
			font-weight: 600;
			position: relative;
			padding-bottom: 0.75rem;
			position: sticky;
			top: -2.5rem;
			background-color: var(--clr-nav);
			z-index: 1;
			padding-top: 0;
			margin-top: 0;

			&:after {
				content: '';
				position: absolute;
				bottom: 0;
				left: 0;
				width: 60px;
				height: 3px;
				background: linear-gradient(135deg, #6b46c1 0%, #4834d4 100%);
				border-radius: 3px;
			}
		}

		form {
			display: flex;
			flex-direction: column;
			gap: 1.75rem;

			label {
				display: block;
				margin-bottom: 0.75rem;
				font-weight: 500;
				font-size: 1.1rem;
				color: var(--clr-font);
			}

			input, textarea {
				width: 100%;
				padding: 1rem;
				border: 2px solid rgba(255, 255, 255, 0.1);
				border-radius: 12px;
				background-color: rgba(255, 255, 255, 0.05);
				color: var(--clr-font);
				font-size: 1rem;
				transition: all 0.3s ease;

				&:focus {
					outline: none;
					border-color: #6b46c1;
					box-shadow: 0 0 0 4px rgba(107, 70, 193, 0.1);
					background-color: rgba(255, 255, 255, 0.08);
				}

				&::placeholder {
					color: rgba(255, 255, 255, 0.4);
				}
			}

			textarea {
				resize: vertical;
				min-height: 150px;
				max-height: 400px;
				line-height: 1.6;
			}

			.button-div {
				display: flex;
				gap: 1rem;
				justify-content: flex-end;
				margin-top: 1.5rem;
				position: sticky;
				bottom: -2.5rem;
				background-color: var(--clr-nav);
				padding: 1rem 0;
				z-index: 1;

				button {
					min-width: 120px;
					padding: 0.875rem 1.5rem;
					font-size: 1rem;
					font-weight: 500;
					border: none;
					border-radius: 12px;
					transition: all 0.3s ease;
					cursor: pointer;

					&:first-child {
						background: linear-gradient(135deg, #6b46c1 0%, #4834d4 100%);
						color: white;
						box-shadow: 0 4px 12px rgba(107, 70, 193, 0.2);

						&:hover {
							background: linear-gradient(135deg, #805ad5 0%, #553c9a 100%);
							transform: translateY(-2px);
							box-shadow: 0 6px 16px rgba(107, 70, 193, 0.3);
						}
					}

					&:last-child {
						background: transparent;
						border: 2px solid rgba(255, 255, 255, 0.2);
						color: var(--clr-font);

						&:hover {
							background: rgba(255, 255, 255, 0.05);
							border-color: rgba(255, 255, 255, 0.3);
						}
					}
				}
			}
		}

		&::backdrop {
			background-color: rgba(0, 0, 0, 0.7);
			backdrop-filter: blur(6px);
		}
	}

	#post-dialog, #edit-dialog {
		position: fixed;
		top: 50%;
		left: 50%;
		transform: translate(-50%, -50%);
		margin: 0;
	}

	.content-container {
		padding: 2rem;
		max-width: 800px;
		margin: 0 auto;
	}

	.announcements-container {
		margin-top: 2rem;
	}
</style>
