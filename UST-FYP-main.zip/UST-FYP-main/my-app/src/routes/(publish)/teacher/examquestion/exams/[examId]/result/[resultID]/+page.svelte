<script lang="ts">
	import ResultCard from '$lib/components/Result/ResultCard.svelte';
	import ResultTag from '$lib/components/Result/ResultTagBar.svelte';
	import ScrollRowBar from '$lib/components/Result/ScrollRowBar.svelte';
	import { onMount } from 'svelte';
	import { db } from '$lib/firebase';
	import { doc, getDoc } from 'firebase/firestore';
	import { page } from '$app/stores';
	import { marked } from 'marked';
	import LoadingPage from '$lib/components/loadingPage.svelte';
	import ExamNavigation from '$lib/components/Exam/ExamNavigation.svelte';
	import BubbleBar from '$lib/components/BubbleBar.svelte';
	import TeacherCorrectCard from '$lib/components/Result/TeacherCorrectCard.svelte';

	//export let data;
	//console.log('data', data.comments);

	interface ExamData {
		createdAt: string;
		questions: {
			[key: string]: {
				content: string;
				part: number;
				year: number;
			};
		};
	}
	interface ExamResult {
		answers: {
			[key: string]: string;
		};
		comment: {
			content: {
				[key: string]: string[];
			};
			language: {
				[key: string]: string[];
			};
			organization: {
				[key: string]: string[];
			};
			grammarAnalysis?: {
				[key: string]: {
					// Changed this part
					originalText: string;
					analysis: string;
					analyzedAt: string;
				};
			};
		};
		teacherComments?: {
			[key: string]: string;
		};
		exams: string;
		grade: string;
		submittedAt: string;
		userId: string;
		markedComments?: {
			[key: string]: Mark[];
		};
	}

	let currentRowbarIndex: number = 0;
	let currentNavTagIndex: number = 0;
	let questionNumber: HTMLHeadingElement;
	let taskTitile: HTMLHeadingElement;
	let taskContent: HTMLHeadingElement;
	let examData: ExamData | null = null;
	let examResult: ExamResult | null = null;
	let loading = true;
	let error: string | null = null;
	let activeCommentType: 'ai' | 'teacher' = 'ai';
	let currentComment: string = '';

	let text_height: number;
	let text_width: number;

	function triggerGrammarAnalysis() {
		if (!examResult) return;

		const resultId = $page.url.pathname.split('/').pop() || '';
		fetch('/api/grammar-analysis', {
			method: 'POST',
			headers: {
				'Content-Type': 'application/json'
			},
			body: JSON.stringify({
				resultId: resultId
			})
		})
			.then((response) => response.json())
			.then((data) => {
				if (data.success && examResult) {
					if (!examResult.comment.grammarAnalysis) {
						examResult.comment.grammarAnalysis = {};
					}
					examResult.comment.grammarAnalysis = data.grammarAnalysis;
					if (currentRowbarIndex === 3) {
						currentComment =
							data.grammarAnalysis[(currentNavTagIndex + 1).toString()]?.analysis ||
							'# Grammar Analysis\n\nAnalyzing grammar...';
					}
				}
			})
			.catch((error) => {
				console.error('Error fetching grammar analysis:', error);
			});
	}

	function handleCardClick(type: 'ai' | 'teacher') {
		activeCommentType = type;
		if (examResult) {
			// Clear all highlights in the answer text
			const textContainer = document.querySelector('.user-answer .answer-text');
			if (textContainer) {
				textContainer.innerHTML = examResult.answers[(currentNavTagIndex + 1).toString()] || '';
				org_HTML = textContainer.innerHTML;
			}

			currentComment =
				type === 'teacher'
					? '# Teacher Comments\n\nTeacher feedback pending review.'
					: getContent(currentNavTagIndex, getContentType(currentRowbarIndex));
			updateUI();
		}
	}

	function scrollToHighlight() {
		// Give the DOM time to update with the highlight
		setTimeout(() => {
			const highlightedElement = document.querySelector('.user-answer .highlight');
			if (highlightedElement) {
				highlightedElement.scrollIntoView({
					behavior: 'smooth',
					block: 'center'
				});
			}
		}, 100);
	}

	// Simplify the teacher comment getter
	function getTeacherComment(questionIndex: number): string {
		if (!examResult?.teacherComments) return '';

		const questionKey = (questionIndex + 1).toString();
		return examResult.teacherComments[questionKey] || '';
	}

	function getContentType(rowbarIndex: number): string {
		switch (rowbarIndex) {
			case 0:
				return 'content';
			case 1:
				return 'language';
			case 2:
				return 'organization';
			default:
				return 'grammar';
		}
	}

	function cleanText(text: string): string {
		return text.replace(/^\s*\*\*\s*\n?/, '').replace(/\n?\s*\*\*\s*$/, '');
	}

	function getContent(questionIndex: number, contentType: string): string {
		if (!examResult) {
			console.log('No exam result available');
			return '';
		}

		if (activeCommentType === 'teacher') {
			const teacherComment = getTeacherComment(questionIndex);
			return teacherComment
				? `# Teacher Comments\n\n${teacherComment}`
				: '# Teacher Comments\n\nNo feedback provided yet.';
		}

		const questionKey = (questionIndex + 1).toString();
		let feedbackContent = '';

		switch (contentType) {
			case 'content':
				if (!examResult.comment?.content?.[questionKey]) {
					return '# Content feedback not available';
				}
				feedbackContent = examResult.comment.content[questionKey]
					.map((item, index) => {
						if (index === 0) {
							return `# Content Feedback\n\n${cleanText(item)}`;
						}
						return `- ${item}`;
					})
					.join('\n\n');
				break;

			case 'language':
				if (!examResult.comment?.language?.[questionKey]) {
					return '# Language feedback not available';
				}
				feedbackContent = examResult.comment.language[questionKey]
					.map((item, index) => {
						if (index === 0) {
							return `# Language Feedback\n\n${cleanText(item)}`;
						}
						return `- ${item}`;
					})
					.join('\n\n');
				break;

			case 'organization':
				if (!examResult.comment?.organization?.[questionKey]) {
					return '# Organization feedback not available';
				}
				feedbackContent = examResult.comment.organization[questionKey]
					.map((item, index) => {
						if (index === 0) {
							return `# Organization Feedback\n\n${cleanText(item)}`;
						}
						return `- ${item}`;
					})
					.join('\n\n');
				break;

			case 'grammar':
				const answer = examResult?.answers[questionKey] || '';

				if (!answer) {
					return '# Grammar Analysis\n\nNo answer available to analyze.';
				}

				return (
					examResult.comment?.grammarAnalysis?.[questionKey]?.analysis ||
					'# Grammar Analysis\n\nAnalyzing grammar...'
				);

			default:
				return '';
		}

		return feedbackContent;
	}

	async function fetchData() {
		try {
			const resultId = $page.url.pathname.split('/').pop() || '';
			console.log('Fetching result ID:', resultId);

			// Fetch exam result
			const resultRef = doc(db, 'examResult', resultId);
			const resultDoc = await getDoc(resultRef);

			if (!resultDoc.exists()) {
				throw new Error('No exam result found');
			}

			const resultData = resultDoc.data();
			examResult = resultData as ExamResult;
			console.log('Fetched exam result:', examResult);

			// Fetch exam data using examId from examResult
			const examId = examResult.exams;
			console.log('Fetching exam data for ID:', examId);

			const examRef = doc(db, 'exams', examId);
			const examDoc = await getDoc(examRef);

			if (!examDoc.exists()) {
				throw new Error('No exam found');
			}

			examData = examDoc.data() as ExamData;
			console.log('Fetched exam data:', examData);

			// Update question content if we have questions
			if (Object.keys(examData.questions || {}).length > 0) {
				updateQuestionContent(currentNavTagIndex);
				// Initialize currentComment after data is loaded
				currentComment = getContent(currentNavTagIndex, getContentType(currentRowbarIndex));

				// Trigger grammar analysis after loading data
				triggerGrammarAnalysis();
			} else {
				error = 'No questions available';
			}
		} catch (err) {
			console.error('Error fetching data:', err);
			error = 'Failed to load data';
		} finally {
			loading = false;
		}
	}

	function updateQuestionContent(index: number) {
		if (examData?.questions && questionNumber && taskContent) {
			const question = examData.questions[index];
			if (question) {
				questionNumber.innerHTML = `Q${index + 1}`;
				taskContent.innerHTML = question.content;
				if (taskTitile) {
					taskTitile.innerHTML = `Task ${index + 1}`;
				}
			}
		}
	}

	$: if (currentNavTagIndex !== undefined && examData) {
        updateQuestionContent(currentNavTagIndex);
        if (examResult) {
            currentComment = getContent(currentNavTagIndex, getContentType(currentRowbarIndex));
            // Update markQuery based on current question
            if (examResult.markedComments) {
                markQuery = examResult.markedComments[currentNavTagIndex + 1] || [];
            } else {
                markQuery = [];
            }

            // Important: Reset both HTML values to ensure clean state after navigation
            org_HTML = examResult.answers[(currentNavTagIndex + 1).toString()] || '';
            cur_HTML = org_HTML;

            // Then apply any needed UI updates
            updateUI();
        }
    }

	onMount(() => {
		fetchData();
		org_HTML = cur_HTML;
	});

	$: hasQuestions = examData && Object.keys(examData.questions || {}).length > 0;

	function countWords(text: string): number {
		if (!text) return 0;
		return text
			.trim()
			.split(/\s+/)
			.filter((word) => word.length > 0).length;
	}
	// BubbleBar
	let temp: number = 0;
	let startX: number = 0;
	let startY: number = 0;
	let endX: number = 0;
	let endY: number = 0;
	let org_HTML: string;
	let cur_HTML: string;
	let showBubbleBar = 'none';
	let BubbleBarY: number;
	let containerXY: { x: number; y: number } = { x: 0, y: 0 };
	let org_containerScrollTop: number = 0;
	interface Mark {
		type: 'CORRECT' | 'WRONG' | 'WARNING';
		start: number;
		end: number;
		content: string;
	}
	let cur_mark_start: number = 0;
	let cur_mark_end: number = 0;
	//let markedComments = data.comments;
	//console.log('markedComments', markedComments);
	let markQuery: Mark[] = [];
	function createMark(start: number, end: number, type: 'CORRECT' | 'WRONG' | 'WARNING'): Mark {
		let temp_mark: Mark = {
			type,
			start,
			end,
			content: ''
		};
		return temp_mark;
	}
	function checkQuery(query: Mark[]) {
		let count = query.length;

		if (count == 0) {
			return true;
		}
		let smallest: number = query[count - 1].end;
		for (let i = 0; i < count; i++) {
			// TODO: smallest < query[count - 1 - i].end need checking
			if (smallest <= query[count - 1 - i].start || smallest < query[count - 1 - i].end) {
				return false;
			} else {
				smallest = query[count - 1 - i].start;
			}
		}
		return true;
	}
	function insertMarkQuery(mark: Mark) {
		let temp_query: Mark[] = [...markQuery];
		temp_query.push(mark);
		const compareFn = (cur: Mark, next: Mark) => cur.end - next.start;
		temp_query.sort(compareFn);

		if (checkQuery(temp_query)) {
			markQuery = [...temp_query];
			// Initialize markedComments if it doesn't exist
			if (!examResult!.markedComments) {
				examResult!.markedComments = {};
			}
			// Update the specific question's comments
			examResult!.markedComments[currentNavTagIndex + 1] = markQuery;
			updateUI();
		} else {
			alert('Please select a different range');
		}
	}
	function updateUI() {
		// if (markQuery.length == 0) {
		// 	return;
		// }

		let count = markQuery.length;
		if (activeCommentType === 'ai') {
			count = 0;
			showBubbleBar = 'none';
		}
		let temp_HTML = org_HTML;

		for (let i = 0; i < count; i++) {
			let temp_string: string;
			switch (markQuery[count - 1 - i].type) {
				case 'CORRECT':
					temp_string = '<span class="comment" style="color:green;  display:content;">';
					break;
				case 'WARNING':
					temp_string = '<span class="comment " style="color:#ffc80a;  display:content;">';
					break;
				case 'WRONG':
					temp_string = '<span class="comment" style="color:red;  display:content;">';
					break;
				default:
					return;
			}

			temp_HTML =
				temp_HTML.substring(0, markQuery[count - 1 - i].start) +
				temp_string +
				temp_HTML.substring(markQuery[count - 1 - i].start, markQuery[count - 1 - i].end) +
				'</span>' +
				temp_HTML.substring(markQuery[count - 1 - i].end);
		}
		// setTimeout(() => {
		// 	correctionAreaUpdated = false;
		// 	setTimeout(() => {
		// 		correctionAreaUpdated = true;
		// 	}, 1);
		// }, 1);
		console.log('markQuery', markQuery);
		cur_HTML = temp_HTML;
	}

	//
	let scrollingCallback: () => void = () => {
		BubbleBarY = startY + (org_containerScrollTop - containerXY.y);
	};
	let bubbleBarCallBack: (type: string) => void = (type: string) => {
		let temp_mark = createMark(
			cur_mark_start,
			cur_mark_end,
			type as 'CORRECT' | 'WRONG' | 'WARNING'
		);
		insertMarkQuery(temp_mark);
		showBubbleBar = 'none';
	};
	interface TeacherComment {
		type: 'CORRECT' | 'WRONG' | 'WARNING';
		start: number;
		end: number;
		content: string;
	}

	// let editableTeacherComments: TeacherComment[] = [];
	let correctionAreaUpdated: boolean = true;
	let cancelCorrection: (index: number) => void = (index) => {
		markQuery = markQuery.filter((mark, i) => i !== index);
		if (examResult?.markedComments) {
			examResult.markedComments[currentNavTagIndex + 1] = markQuery;
		}
		updateUI();
		saveComments();
	};

	async function saveComments() {
		try {
			const resultId = $page.url.pathname.split('/').pop() || '';
			if (!resultId || !examResult) return;

			if (!examResult.markedComments) {
				examResult.markedComments = {};
			}

			examResult.markedComments[currentNavTagIndex + 1] = markQuery;

			const response = await fetch('/api/exam/post_comment', {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json'
				},
				body: JSON.stringify({
					resultId,
					comments: examResult.markedComments
				})
			});

			const result = await response.json();
			if (!result.success) {
				throw new Error('Failed to save comments');
			}
			alert('Comments saved successfully!');
		} catch (error) {
			console.error('Error saving comments:', error);
			alert('Failed to save comments. Please try again.');
		}
	}
</script>

<BubbleBar
	x={startX - 40}
	y={BubbleBarY}
	display={showBubbleBar}
	start={cur_mark_start}
	end={cur_mark_end}
	callback={bubbleBarCallBack}
></BubbleBar>

<ExamNavigation bind:curXY={containerXY} bind:callback={scrollingCallback}>
	<div class="container">
		{#if loading}
			<LoadingPage />
		{:else if error}
			<div class="error">{error}</div>
		{:else if hasQuestions}
			<div class="nav">
				<ResultTag
					bind:currentTagIndex={currentNavTagIndex}
					questions={examData?.questions || {}}
				/>
			</div>
			<div class="header">
				<div class="question">
					<div>
						<div class="question-number"><h1 bind:this={questionNumber}>Q1</h1></div>
						<h2 bind:this={taskTitile}>Task 1</h2>
					</div>
					<h2 bind:this={taskContent}>
						{#if examData?.questions[currentNavTagIndex]}
							{examData.questions[currentNavTagIndex].content}
						{:else}
							Loading question content...
						{/if}
					</h2>
				</div>
				<div class="summery">
					<div class="grade-section">
						<div
							class="card-wrapper"
							class:active={activeCommentType === 'ai'}
							on:click={() => handleCardClick('ai')}
							on:keydown={(e) => e.key === 'Enter' && handleCardClick('ai')}
							role="button"
							tabindex="0"
						>
							<ResultCard
								value={examResult?.grade || 'Graded'}
								description="AI Comments"
								isTeacher={false}
								{activeCommentType}
							/>
						</div>

						<div
							class="card-wrapper"
							class:active={activeCommentType === 'teacher'}
							on:click={() => handleCardClick('teacher')}
							on:keydown={(e) => e.key === 'Enter' && handleCardClick('teacher')}
							role="button"
							tabindex="0"
						>
							<ResultCard
								value={examResult?.teacherComments?.[currentNavTagIndex + 1] ? 'Graded' : 'Pending'}
								description="Teacher Comments"
								examId={$page.url.pathname.split('/').pop() || ''}
								questionKey={(currentNavTagIndex + 1).toString()}
								isTeacher={true}
								{activeCommentType}
								on:commentUpdated={(event) => {
									if (!examResult) return; // Ensure examResult is defined

									if (!examResult.teacherComments) {
										examResult.teacherComments = {}; // Assign safely
									}

									examResult.teacherComments[currentNavTagIndex + 1] = event.detail.comment;
									currentComment = `# Teacher Comments\n\n${event.detail.comment}`;
								}}
							/>
						</div>
					</div>
					{#if activeCommentType === 'ai'}
						<div class="scroll-section">
							<ScrollRowBar
								bind:RowBarIndex={currentRowbarIndex}
								tagList={['Content (C)', 'Language (L)', 'Organization (O)', 'Grammar Analysis']}
							/>
						</div>
					{/if}
				</div>
			</div>

			<div class="answer">
				<div class="user-answer">
					{#if examResult}
						<div class="answer-container">
							<!-- svelte-ignore a11y-click-events-have-key-events -->
							<!-- svelte-ignore a11y-no-static-element-interactions -->
							<div class="box">
								<div
									class="answer-text"
									contenteditable="true"
									style="--text-height:{text_height}; --text-weight:{text_width};"
									bind:innerHTML={org_HTML}
									bind:clientHeight={text_height}
									bind:clientWidth={text_width}
									on:click|capture={(event) => {
										endX = event.clientX;
										endY = event.clientY;
										let anchorOffset = window.getSelection()?.anchorOffset;
										let focusOffset = window.getSelection()?.focusOffset;
										if (anchorOffset && focusOffset && anchorOffset != focusOffset) {
											cur_mark_start = Math.min(anchorOffset, focusOffset);
											cur_mark_end = Math.max(anchorOffset, focusOffset);
											// let temp_mark = createMark(start, end, 'test');
											org_containerScrollTop = containerXY.y;
											if (activeCommentType == 'teacher') {
												showBubbleBar = 'flex';
											}
										}

										// console.log(anchorOffset);
										// console.log(focusOffset);
									}}
									on:pointerdown={(event) => {
										showBubbleBar = 'none';
										startX = event.clientX;
										startY = event.clientY;
										BubbleBarY = startY;
									}}
									on:selectionchange={(event) => {
										showBubbleBar = 'none';
									}}
								>
									{examResult.answers[(currentNavTagIndex + 1).toString()] || ''}
								</div>
								<div class="cover" contenteditable="true" bind:innerHTML={cur_HTML}>
									{examResult.answers[(currentNavTagIndex + 1).toString()] || ''}
								</div>
							</div>
							<div class="answer-actions">
								<div class="word-count">
									{countWords(examResult.answers[(currentNavTagIndex + 1).toString()] || '')} words
								</div>
							</div>
						</div>
					{/if}
				</div>
				<div class="system-answer">
					<div class="answer-container">
						<div class="answer-text" class:fade-in={currentComment}>
							{#if activeCommentType === 'teacher'}
								<h1>Teacher Comments</h1>
								<p>
									{examResult?.teacherComments?.[currentNavTagIndex + 1] ||
										'Teacher feedback pending review.'}
								</p>
								{#if correctionAreaUpdated}
									<div class="correction-area">
										{#each markQuery as comment, i}
											<TeacherCorrectCard
												description={org_HTML.substring(comment.start, comment.end)}
												type={comment.type}
												bind:value={comment.content}
												callback1={saveComments}
												callback2={() => cancelCorrection(i)}
												readonly={false}
											></TeacherCorrectCard>
										{/each}
									</div>
								{/if}
							{:else if examResult?.comment && currentRowbarIndex === 3}
								<h1>Grammar Analysis</h1>
								{#if !examResult.comment.grammarAnalysis?.[currentNavTagIndex + 1]?.analysis}
									<p class="analyzing">Analyzing grammar...</p>
								{:else}
									{#each examResult.comment.grammarAnalysis[currentNavTagIndex + 1].analysis
										.split(/\d+\./)
										.filter(Boolean) as section, index}
										{#if section.includes('Original:') && section.includes('Corrected:')}
											<div class="grammar-section">
												<button
													class="section-title"
													on:click={() => {
														// Get just the section text without the section number prefix
														const sectionContent = section.trim();
														
														// Try different strategies to find the problematic text
														let pattern = null;
														
														// Strategy 1: Look for text between quotes with an error marker
														const quoteMatch = sectionContent.match(/(?:❌|Original:|Error:)\s*["']([^"']+)["']/);
														if (quoteMatch) {
														  pattern = quoteMatch[1];
														} 
														// Strategy 2: Look for specific sentences in the section
														else if (sectionContent.includes('Original:') && sectionContent.includes('Corrected:')) {
														  const lines = sectionContent.split('\n');
														  const originalLine = lines.find(line => line.trim().startsWith('Original:'));
														  if (originalLine) {
															pattern = originalLine.replace('Original:', '').trim();
														  }
														}
														// Strategy 3: Extract the first sentence after the heading that's not a label
														else {
														  const lines = sectionContent.split('\n').filter(line => line.trim().length > 0);
														  // Skip the first line (the heading) and find a substantial line
														  for (let i = 1; i < lines.length; i++) {
															const line = lines[i].trim();
															if (line.length > 10 && !line.includes(':')) {
															  pattern = line;
															  break;
															}
														  }
														}
														
														if (pattern) {
														  const text = examResult?.answers?.[(currentNavTagIndex + 1).toString()] || '';
														  const textContainer = document.querySelector('.user-answer .answer-text');
														  
														  if (textContainer) {
															// Clear previous highlights first
															const currentHTML = textContainer.innerHTML;
															textContainer.innerHTML = currentHTML.replace(/<span class="highlight"[^>]*>|<\/span>/g, '');
															
															// Try exact match first (for shorter patterns)
															let foundIndex = text.indexOf(pattern);
															
															// If exact match fails, try case-insensitive
															if (foundIndex === -1) {
															  const lowerPattern = pattern.toLowerCase();
															  const lowerText = text.toLowerCase();
															  foundIndex = lowerText.indexOf(lowerPattern);
															  
															  // If still no match and pattern is long, try to find a shorter substring
															  if (foundIndex === -1 && pattern.length > 15) {
																// Get the first 15-20 characters to try matching
																const partialPattern = lowerPattern.substring(0, Math.min(20, pattern.length));
																foundIndex = lowerText.indexOf(partialPattern);
																
																if (foundIndex !== -1) {
																  // If we found a match with the beginning, use that to highlight
																  const matchLength = Math.min(pattern.length, 
																							  text.length - foundIndex);
																  pattern = text.substring(foundIndex, foundIndex + matchLength);
																}
															  }
															}
															
															// If we found a match position
															if (foundIndex !== -1) {
															  // Get the original cased version to highlight
															  const matchLength = Math.min(pattern.length, text.length - foundIndex);
															  const originalMatch = text.substring(foundIndex, foundIndex + matchLength);
															  const beforeText = text.substring(0, foundIndex);
															  const afterText = text.substring(foundIndex + matchLength);
															  
															  // Create a temporary div to handle HTML encoding
															  const tempDiv = document.createElement('div');
															  tempDiv.textContent = beforeText;
															  const safeBeforeText = tempDiv.innerHTML;
															  tempDiv.textContent = originalMatch;
															  const safeMatch = tempDiv.innerHTML;
															  tempDiv.textContent = afterText;
															  const safeAfterText = tempDiv.innerHTML;
															  
															  // Use a background color that extends across lines
															  textContainer.innerHTML = `${safeBeforeText}<span class="highlight" style="background-color: #fef08a; display: inline;">${safeMatch}</span>${safeAfterText}`;
															  
															  // Scroll to the highlighted text
															  const highlightEl = textContainer.querySelector('.highlight');
															  if (highlightEl) {
																highlightEl.scrollIntoView({
																  behavior: 'smooth',
																  block: 'center'
																});
															  }
															} else {
															  // No match found
															  console.log("Could not find matching text for highlight:", pattern);
															}
														  }
														}
													  }}
												>
													{index}. {section.split('\n')[0].trim()}
												</button>
												<div class="section-content">
													{@html marked(section.split('\n').slice(1).join('\n'))}
												</div>
											</div>
										{/if}
									{/each}
								{/if}
							{:else}
								{@html marked(currentComment)}
							{/if}
						</div>
					</div>
				</div>
			</div>
		{/if}
	</div>
</ExamNavigation>

<style lang="scss">
	.grammar-section {
		margin-bottom: 24px;

		.section-title {
			width: 100%;
			text-align: left;
			padding: 8px 12px;
			margin-bottom: 8px;
			border-radius: 6px;
			background: transparent;
			border: none;
			color: var(--primary-color);
			font-weight: 600;
			font-size: 1.1rem;
			cursor: pointer;
			transition: all 0.2s ease;
			border-left: 3px solid transparent;

			&:hover {
				background-color: var(--primary-light);
				border-left-color: var(--primary-color);
			}
		}

		.section-content {
			padding-left: 12px;
		}
	}

	:root {
		--primary-color: #4f46e5;
		--primary-light: #eef2ff;
		--hover-color: #f1f5f9;
		--active-color: #e2e8f0;
		--text-primary: #1e293b;
		--text-secondary: #64748b;
		--background-light: #f8fafc;
		--border-color: #e2e8f0;
		--shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
		--shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1);
	}

	.container {
		display: flex;
		flex-direction: column;
		height: 100%;
		width: 100%;
		max-width: 1440px;
		margin: 0 auto;
		padding: 24px;
		background-color: var(--background-light);
		gap: 16px;
	}

	.nav {
		display: flex;
		align-items: center;
		height: 56px;
		background-color: white;
		padding: 0 20px;
		border-radius: 12px;
		box-shadow: var(--shadow-sm);
	}

	.header {
		display: flex;
		gap: 16px;
		min-height: 200px;
		> div {
			flex: 1;
			background-color: white;
			border-radius: 12px;
			box-shadow: var(--shadow-sm);
		}
	}

	.card-wrapper {
		cursor: pointer;
		transition: all 0.2s ease;
		position: relative;
		overflow: hidden;

		&:hover {
			transform: translateY(-2px);
		}

		&.active {
			:global(.result-card) {
				border: 2px solid var(--primary-color);
				background-color: var(--primary-light);
				transition: all 0.3s ease;
			}

			&::after {
				content: '';
				position: absolute;
				bottom: 0;
				left: 0;
				width: 100%;
				height: 2px;
				background-color: var(--primary-color);
				animation: slideIn 0.3s ease-out;
			}
		}
	}

	@keyframes slideIn {
		from {
			transform: scaleX(0);
		}
		to {
			transform: scaleX(1);
		}
	}

	.question {
		padding: 24px;
		> div {
			display: flex;
			align-items: center;
			margin-bottom: 20px;
			> .question-number {
				position: relative;
				padding-right: 24px;
				margin-right: 24px;
				> h1 {
					font-size: 32px;
					color: var(--primary-color);
					font-weight: 700;
					&::after {
						position: absolute;
						content: '';
						width: 2px;
						height: 100%;
						top: 0;
						right: 0;
						background-color: var(--primary-color);
						opacity: 0.3;
					}
				}
			}
			> h2 {
				color: var(--text-secondary);
				font-size: 20px;
				font-weight: 600;
			}
		}
		> h2 {
			min-width: 400px;
			max-height: 150px;
			overflow-y: scroll;
			background-color: var(--primary-light);
			border-radius: 12px;
			padding: 20px;
			font-size: 16px;
			line-height: 1.8;
			color: var(--text-primary);
		}
	}

	.summery {
		overflow: hidden;
		padding: 24px;
		display: flex;
		flex-direction: column;
		gap: 20px;
	}

	.grade-section {
		display: grid;
		grid-template-columns: 1fr 1fr;
		gap: 16px;
	}

	.scroll-section {
		height: 44px;
		display: flex;
		align-items: center;
	}

	.answer {
		display: flex;
		gap: 16px;
		flex: 1;
		min-height: 400px;

		> div {
			flex: 1;
			background-color: white;
			border-radius: 12px;
			box-shadow: var(--shadow-sm);
			transition: all 0.2s ease;

			&:hover {
				box-shadow: var(--shadow-md);
			}
		}
	}
	.box {
		position: relative;
	}
	.answer-actions {
		display: flex;
		justify-content: space-between;
		align-items: center;
		gap: 16px;
	}

	.answer-container {
		height: 100%;
		padding: 24px;
		display: flex;
		flex-direction: column;
		gap: 16px;
	}

	.answer-text {
		position: relative;
		flex: 1;
		background-color: var(--background-light);
		border-radius: 12px;
		padding: 24px;
		line-height: 1.8;
		color: var(--text-primary);
		font-size: 16px;
		border: 1px solid var(--border-color);
		overflow-y: auto;
		white-space: pre-wrap;
		transition: all 0.3s ease;

		:global(.highlight) {
			background-color: #fef08a !important;
			box-decoration-break: clone;
			-webkit-box-decoration-break: clone;
			padding: 2px 0;
			border-radius: 2px;
			display: inline;
			white-space: pre-wrap;
		}

		&.fade-in {
			animation: fadeIn 0.3s ease-out;
		}

		&::-webkit-scrollbar {
			width: 8px;
		}

		&::-webkit-scrollbar-track {
			background: var(--background-light);
			border-radius: 4px;
		}

		&::-webkit-scrollbar-thumb {
			background: var(--primary-color);
			border-radius: 4px;
			opacity: 0.7;
		}

		&::-webkit-scrollbar-thumb:hover {
			opacity: 1;
		}

		:global(h1) {
			font-size: 1.5rem;
			font-weight: 600;

			color: var(--primary-color);
		}

		:global(ul) {
			list-style-type: disc;
			padding-left: 1.5rem;
		}

		:global(li) {
			margin-bottom: 0.5rem;
		}
	}
	.cover {
		position: absolute;
		height: var(--text-height);
		width: var(--text-weight);
		top: 0;
		left: 0;
		background-color: rgb(0 0 0 / 0);
		// color: rgb(0 0 0 / 0);
		border: 1px solid var(--border-color);
		// color: red;
		border-radius: 12px;
		padding: 24px;
		line-height: 1.8;
		font-size: 16px;
		pointer-events: none;
		overflow-y: auto;
		white-space: pre-wrap;
	}
	@keyframes fadeIn {
		from {
			opacity: 0;
			transform: translateY(10px);
		}
		to {
			opacity: 1;
			transform: translateY(0);
		}
	}

	.word-count {
		align-self: flex-end;
		color: var(--text-secondary);
		padding: 8px 16px;
		border-radius: 24px;
		font-size: 14px;
		font-weight: 500;
		background-color: var(--primary-light);
		border: 1px solid var(--border-color);
		display: inline-flex;
		align-items: center;
		gap: 8px;
		transition: all 0.2s ease;

		&::before {
			content: '📝';
			font-size: 14px;
		}

		&:hover {
			transform: translateY(-2px);
			background-color: var(--primary-color);
			color: white;
		}
	}

	@media (max-width: 1024px) {
		.container {
			padding: 16px;
		}

		.header {
			flex-direction: column;
			> div {
				width: 100%;
			}
		}
	}

	@media (max-width: 768px) {
		.answer {
			flex-direction: column;
			> div {
				min-height: 300px;
			}
		}

		.question {
			padding: 20px;
			> div {
				> .question-number > h1 {
					font-size: 28px;
				}
				> h2 {
					font-size: 18px;
				}
			}
		}
	}
	.comment {
		&:hover {
			background-color: var(--hover-color) !important;
		}
	}
	.correction-area {
		display: flex;
		flex-direction: column;
		gap: 16px;
		overflow: scroll;
		height: 850px;
	}
</style>
