<script lang="ts">
    import ExamNavigation from '$lib/components/Exam/ExamNavigation.svelte';
    import UnderscoreDiv from '$lib/components/UnderscoreDiv.svelte';
    import SubheadingBar from '$lib/components/SubheadingBar.svelte';
    import { collection, query, getDocs, where, doc, getDoc } from 'firebase/firestore';
    import { db } from '$lib/firebase';
    import { onMount } from 'svelte';
    import { goto } from '$app/navigation';
    import { page } from '$app/stores';

    $: examId = $page.url.pathname.split('/')[4];
    $: isValidExamId = examId && examId !== 'undefined';

    interface User {
        firstName: string;
        lastName: string;
        class: string;
    }

    interface ExamResult {
        id: string;
        userID: string;
        gradedAt: string;
        submittedAt: string;
        score: string;
        feedback: string;
        exams: string;
        teacherComments: {
            [key: string]: string;
        } | null;
        userData?: User;
    }

    let examResults: ExamResult[] = [];
    let loading = true;
    let searchQuery = '';

    const navigateToResult = (resultId: string) => {
        goto(`/teacher/examquestion/exams/${examId}/result/${resultId}`);
    };

    function determineGradeStatus(result: ExamResult): string {
        return result.teacherComments !== null && Object.keys(result.teacherComments).length > 0 ? 'Graded' : 'Pending';
    }

    async function fetchUserData(userID: string): Promise<User | null> {
        try {
            const userDoc = await getDoc(doc(db, 'users', userID));
            if (userDoc.exists()) {
                const userData = userDoc.data() as User;
                return userData;
            }
            return null;
        } catch (error) {
            console.error('Error fetching user data:', error);
            return null;
        }
    }

    onMount(async () => {
        if (!isValidExamId) {
            console.error('Invalid exam ID');
            loading = false;
            return;
        }

        try {
            console.log('Current exam ID:', examId);
            
            const examResultsRef = collection(db, 'examResult');
            const q = query(examResultsRef, where('exams', '==', examId));
            const querySnapshot = await getDocs(q);
            
            const resultsWithUserData = await Promise.all(
                querySnapshot.docs.map(async (doc) => {
                    const data = doc.data();
                    const userData = await fetchUserData(data.userID);
                    return {
                        id: doc.id,
                        userID: data.userID || '',
                        gradedAt: data.gradedAt || '',
                        submittedAt: data.submittedAt || '',
                        score: data.score || '',
                        feedback: data.feedback || '',
                        exams: data.exams || '',
                        teacherComments: data.teacherComments || null,
                        userData: userData
                    };
                })
            );
            
            examResults = resultsWithUserData;
            console.log('Fetched results:', examResults);
            loading = false;
        } catch (error) {
            console.error('Error fetching exam results:', error);
            loading = false;
        }
    });

    $: filteredResults = examResults.filter(result => {
        const searchLower = searchQuery.toLowerCase();
        const userName = result.userData ? 
            `${result.userData.firstName} ${result.userData.lastName}`.toLowerCase() : '';
        const userClass = result.userData?.class?.toLowerCase() || '';
        
        return userName.includes(searchLower) ||
            userClass.includes(searchLower) ||
            result.score.toLowerCase().includes(searchLower);
    });
</script>

<ExamNavigation>
    <UnderscoreDiv>
        <SubheadingBar title={'Exam Results'} checkShow={false} />
        
        <div class="list-container">
            {#if !isValidExamId}
                <div class="error-message">
                    Invalid exam ID. Please check the URL.
                </div>
            {:else}
                <div class="search-sort-container">
                    <div class="search-container">
                        <input 
                            type="text" 
                            placeholder="Search by name, class, or score" 
                            bind:value={searchQuery}
                            class="search-input"
                        />
                    </div>
                </div>

                {#if loading}
                    <div class="loading">
                        <div class="loading-spinner"></div>
                        Loading...
                    </div>
                {:else if filteredResults.length === 0}
                    <div class="no-results">
                        {searchQuery ? 'No matching results found' : 'No exam results found'}
                    </div>
                {:else}
                    <div class="results-list">
                        {#each filteredResults as result (result.id)}
                            <div 
                                class="result-row"
                                on:click={() => navigateToResult(result.id)}
                                on:keydown={(e) => e.key === 'Enter' && navigateToResult(result.id)}
                                tabindex="0"
                                role="button"
                            >
                                <div class="result-info">
                                    <div class="details">
                                        {#if result.userData}
                                            <div class="user-info">
                                                <span class="user-name">
                                                    {result.userData.firstName} {result.userData.lastName}
                                                </span>
                                                <span class="class-badge">
                                                    {result.userData.class}
                                                </span>
                                            </div>
                                        {:else}
                                            <div class="user-id">User ID: {result.userID}</div>
                                        {/if}
                                        <div class="score">Score: {result.score}</div>
                                        <div class="timestamps">
                                            <span>Submitted: {new Date(result.submittedAt).toLocaleString()}</span>
                                            {#if determineGradeStatus(result) === 'Graded'}
                                                <span>Graded: {new Date(result.gradedAt).toLocaleString()}</span>
                                            {/if}
                                        </div>
                                    </div>
                                </div>
                                <div class="metadata">
                                    <div class="grade-badge" class:pending={determineGradeStatus(result) === 'Pending'}>
                                        {determineGradeStatus(result)}
                                    </div>
                                    <div class="view-details">
                                        View Details →
                                    </div>
                                </div>
                            </div>
                        {/each}
                    </div>
                {/if}
            {/if}
        </div>
    </UnderscoreDiv>
</ExamNavigation>

<style lang="scss">
    .list-container {
        padding: 1rem;
    }

    .search-sort-container {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 1rem;
    }

    .search-input {
        padding: 0.5rem 1rem;
        border: 1px solid #e2e8f0;
        border-radius: 0.375rem;
        width: 300px;
        font-size: 0.875rem;
        
        &:focus {
            outline: none;
            border-color: #4f46e5;
            box-shadow: 0 0 0 1px #4f46e5;
        }
    }

    .results-list {
        display: flex;
        flex-direction: column;
        gap: 0.5rem;
    }

    .result-row {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 1rem;
        background: white;
        border: 1px solid #e2e8f0;
        border-radius: 0.5rem;
        cursor: pointer;
        transition: all 0.2s ease;
        
        &:hover {
            background: #f8fafc;
            transform: translateY(-1px);
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);

            .view-details {
                opacity: 1;
            }
        }

        &:focus {
            outline: 2px solid #4f46e5;
            outline-offset: 2px;
        }
    }

    .details {
        display: flex;
        flex-direction: column;
        gap: 0.5rem;
    }

    .user-info {
        display: flex;
        align-items: center;
        gap: 0.75rem;
    }

    .user-name {
        font-weight: 600;
        color: #111827;
        font-size: 1rem;
    }

    .user-id {
        font-weight: 500;
        color: #111827;
    }

    .class-badge {
        background: #E0E7FF;
        color: #4338CA;
        padding: 0.25rem 0.75rem;
        border-radius: 1rem;
        font-size: 0.75rem;
        font-weight: 500;
    }

    .score {
        font-size: 0.875rem;
        color: #4f46e5;
        font-weight: 500;
    }

    .timestamps {
        font-size: 0.75rem;
        color: #6b7280;
        display: flex;
        gap: 1rem;
    }

    .metadata {
        display: flex;
        flex-direction: column;
        align-items: flex-end;
        gap: 0.5rem;
    }

    .grade-badge {
        padding: 0.25rem 0.75rem;
        background: #EEF2FF;
        color: #4F46E5;
        border-radius: 1rem;
        font-size: 0.75rem;
        font-weight: 500;

        &.pending {
            background: #FEF3C7;
            color: #92400E;
        }
    }

    .view-details {
        font-size: 0.75rem;
        color: #4f46e5;
        opacity: 0;
        transition: opacity 0.2s ease;
    }

    .loading {
        text-align: center;
        padding: 2rem;
        color: #6b7280;
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 0.5rem;
    }

    .loading-spinner {
        width: 1.5rem;
        height: 1.5rem;
        border: 2px solid #e2e8f0;
        border-top-color: #4f46e5;
        border-radius: 50%;
        animation: spin 1s linear infinite;
    }

    .no-results {
        text-align: center;
        padding: 2rem;
        color: #6b7280;
        background: #f9fafb;
        border-radius: 0.5rem;
    }

    .error-message {
        text-align: center;
        padding: 2rem;
        color: #991B1B;
        background: #FEE2E2;
        border-radius: 0.5rem;
        margin: 1rem;
    }

    @keyframes spin {
        to {
            transform: rotate(360deg);
        }
    }
</style>