<script lang="ts">
	import SearchHeader from '$lib/components/SearchHeader.svelte';
	import SubheadingBar from '$lib/components/SubheadingBar.svelte';
	import UnderscoreDiv from '$lib/components/UnderscoreDiv.svelte';
	import ExamNavigation from '$lib/components/Exam/ExamNavigation.svelte';
	import { onMount, onDestroy } from 'svelte';
	import { db } from '$lib/firebase';
	import { collection, onSnapshot } from 'firebase/firestore';
	import { goto } from '$app/navigation';

	interface Question {
		content: string;
		part: number;
		
	}

	interface Exam {
		id: string;
		createdAt: string;
		questions: Question[];
		year: number;
		title: string;  // Add this line
	}

	let exams: Exam[] = [];
	let loading = true;
	let userId: string | null = null;
	let unsubscribe: () => void;

	function getUserIdFromCookie(): string | null {
		if (typeof document !== 'undefined') {
			const cookies = document.cookie.split('=');
			if (cookies.length >= 2) {
				return cookies[1];
			}
		}
		return null;
	}

	function setupRealtimeExams() {
    const examCollection = collection(db, 'exams');

    unsubscribe = onSnapshot(
        examCollection,
        (snapshot) => {
            exams = snapshot.docs.map((doc) => {
                const data = doc.data();
                return {
                    id: doc.id,
                    createdAt: data.createdAt,
                    questions: data.questions || [],
                    year: data.year,
                    title: data.title || 'Untitled Question'  // Add this line
                };
            });

            exams.sort((a, b) => b.year - a.year);
            loading = false;
        },
        (error) => {
            console.error('Error fetching exams:', error);
            loading = false;
        }
    );
}

	async function handleExamClick(examId: string) {
		if (!userId) {
			console.error('No user ID found in cookie');
			return;
		}
		goto(`/teacher/examquestion/exams/${examId}/people`);
	}

	onMount(() => {
		userId = getUserIdFromCookie();
		if (!userId) {
			console.error('No user ID found in cookie');
			return;
		}
		setupRealtimeExams();
	});

	onDestroy(() => {
		if (unsubscribe) {
			unsubscribe();
		}
	});
</script>

<main>
	
	<div class="container">
		<UnderscoreDiv>
			<SubheadingBar title={'Exam'} />
		</UnderscoreDiv>

		<UnderscoreDiv>
			<div class="exam-grid">
				{#if loading}
					<div class="loading-skeleton">
						<div class="skeleton-card"></div>
						<div class="skeleton-card"></div>
						<div class="skeleton-card"></div>
					</div>
				{:else}
					{#each exams as exam}
						<div class="exam-card" on:click={() => handleExamClick(exam.id)}>
							<div class="card-content">
								<div class="book-icon">
									<span class="book book-1"></span>
									<span class="book book-2"></span>
								</div>
								<p class="semester-year">{exam.year}</p>
								<h3 class="card-title">HKDSE English Language Paper 2 </h3>
								<p class="question-title">{exam.title || 'Untitled Question'}</p>
							</div>
						</div>
					{/each}
				{/if}
			</div>
		</UnderscoreDiv>
	</div>
</main>


<style lang="scss">
	.question-title {
		color: white;
		font-size: 1rem;
		font-weight: 500;
		opacity: 0.9;
		margin-bottom: 0.5rem;
		overflow: hidden;
		text-overflow: ellipsis;
		display: -webkit-box;
		-webkit-line-clamp: 2;
		-webkit-box-orient: vertical;
		max-width: 100%;
	}

	main {
		position: relative;
		height: 100%;
		width: 100%;
		background-color: var(--clr-content-background);
	}

	.container {
		padding: 10px 40px;
	}

	.exam-grid {
		display: grid;
		grid-template-columns: repeat(3, 1fr);
		gap: 2rem;
		padding: 2rem;

		@media (max-width: 768px) {
			grid-template-columns: repeat(2, 1fr);
		}

		@media (max-width: 480px) {
			grid-template-columns: 1fr;
		}
	}

	.exam-card {
		background: linear-gradient(135deg, #e9b8d4 0%, #93c5fd 100%);

		border-radius: 1rem;
		padding: 1.5rem;
		transition: transform 0.2s ease;
		cursor: pointer;

		&:hover {
			transform: translateY(-5px);
		}
	}

	.card-content {
		display: flex;
		flex-direction: column;
		align-items: center;
		text-align: center;
	}

	.book-icon {
		position: relative;
		width: 60px;
		height: 60px;
		margin-bottom: 1rem;
	}

	.book {
		position: absolute;
		background: white;
		border-radius: 4px;
		box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);

		&.book-1 {
			width: 40px;
			height: 50px;
			transform: rotate(-15deg);
			left: 0;
			bottom: 0;
		}

		&.book-2 {
			width: 40px;
			height: 50px;
			transform: rotate(15deg);
			right: 0;
			bottom: 0;
		}
	}

	.card-title {
		font-size: 1.25rem;
		font-weight: 600;
		color: white;
		margin-bottom: 0.5rem;
	}

	.semester-year {
		color: white;
		font-size: 1rem;
		opacity: 0.9;
	}

	.loading-skeleton {
		display: contents;

		.skeleton-card {
			background: linear-gradient(110deg, #ececec 8%, #f5f5f5 18%, #ececec 33%);
			border-radius: 1rem;
			height: 200px;
			background-size: 200% 100%;
			animation: shimmer 1.5s linear infinite;
		}
	}

	@keyframes shimmer {
		0% {
			background-position: 200% 0;
		}
		100% {
			background-position: -200% 0;
		}
	}
</style>