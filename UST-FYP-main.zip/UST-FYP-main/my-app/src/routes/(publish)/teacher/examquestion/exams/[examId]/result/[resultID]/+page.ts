// import type { PageLoad } from './$types';

// export const ssr = false;

// export const load: PageLoad = async ({ params, fetch }) => {
//     const response = await fetch(`/api/exam/get_comment?resultId=${params.resultID}`);
//     const commentsData = await response.json();
    
//     return {
//         examId: params.examId,
//         resultId: params.resultID,
//         comments: commentsData.success ? commentsData.comments : {}
//     };
// };