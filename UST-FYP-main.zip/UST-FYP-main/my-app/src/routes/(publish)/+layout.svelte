<script lang="ts">
	import NavigationBar from '$lib/components/Navigation/NavigationBar.svelte';
	import ChatBotButton from '$lib/components/ChatBotButton.svelte';
	import MenuButton from '$lib/components/MenuButton.svelte';
	
	export let data;

	let fullname = data.userInfo.firstName + ' ' + data.userInfo.lastName;
</script>

<body>	
	<!-- <p>{x[1]}</p> -->
	<NavigationBar name = {fullname}></NavigationBar>

	<!-- <ChatBotButton></ChatBotButton> -->
	 
	<div class="content">
		<slot />
	</div>
</body>

<style lang="scss">
	body {
		--clr-hover-backgroud: #a0a5ac;
		--clr-hover-font: #f1f2f3;
		display: flex;
		flex-direction: row;
		position: relative;
		width: 100%;
		height: 100%;
	}
	.content {
		overflow-y: auto;
		width: 100%;
	}
</style>
