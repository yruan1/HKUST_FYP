import { error } from '@sveltejs/kit';

export async function load({ cookies, fetch }) {
    let uid = cookies.get('uid');
    let url = '/api/auth/getUserInfo?uid=' + uid;
	const response =  await fetch(url);

    if (!response.ok) {
        throw error(response.status, 'Failed to fetch user data');
    }

    const data = await response.json();
    //console.log("ts ",data);
    return  {userInfo : data}; 
}