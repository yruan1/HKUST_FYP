<script>
	import { onMount } from 'svelte';
	import { collection, getDocs, doc, updateDoc, deleteDoc, setDoc } from 'firebase/firestore';
	import { auth, db } from '$lib/firebase';
	import { goto } from '$app/navigation';
	import { onAuthStateChanged } from 'firebase/auth';
	import { createUserWithEmailAndPassword } from 'firebase/auth';

	// Form fields
	let firstName = '';
	let lastName = '';
	let email = '';
	let password = '';
	let role = 'student';
	let className = '';

	// App state
	let users = [];
	let loading = true;
	let error = null;
	let message = null;
	let editingUser = null;
	let currentUser = null;

	// Possible roles
	const roles = ['student', 'teacher', 'admin'];

	onMount(() => {
		// Check if user is authenticated and is an admin
		const unsubscribe = onAuthStateChanged(auth, async (user) => {
			if (user) {
				currentUser = user;
				// You might want to check if current user is an admin here
				// by fetching their document from Firestore
				
				await loadUsers();
			} else {
				// Redirect to login if not authenticated
				goto('/login');
			}
			loading = false;
		});

		return unsubscribe; // Clean up on component unmount
	});

	async function loadUsers() {
		try {
			loading = true;
			const querySnapshot = await getDocs(collection(db, "users"));
			
			users = querySnapshot.docs.map(doc => {
				const data = doc.data();
				return {
					userId: doc.id,
					...data,
					createdAt: data.createdAt?.toDate?.() || new Date()
				};
			});
		} catch (err) {
			error = `Error loading users: ${err.message}`;
		} finally {
			loading = false;
		}
	}

	async function handleSubmit() {
		try {
			loading = true;
			message = null;
			error = null;

			if (editingUser) {
				// Update existing user
				const userRef = doc(db, "users", editingUser.userId);
				await updateDoc(userRef, {
					firstName,
					lastName,
					email,
					role,
					class: className,
				});
				
				message = `User ${firstName} ${lastName} updated successfully!`;
				resetForm();
			} else {
				// Create new user
				// First create auth user
				let userCredential;
				try {
					userCredential = await createUserWithEmailAndPassword(auth, email, password);
				} catch (authError) {
					throw new Error(`Auth error: ${authError.message}`);
				}

				// Then store user data in Firestore
				const userData = {
					firstName,
					lastName,
					email,
					role,
					class: className,
					createdAt: new Date(),
					userId: userCredential.user.uid
				};

				// Use setDoc with the UID from Authentication as the document ID
				await setDoc(doc(db, "users", userCredential.user.uid), userData);
				
				// Also add to role-specific collection if needed
				if (role === 'student' || role === 'teacher' || role === 'admin') {
					await setDoc(doc(db, role + "s", userCredential.user.uid), {
						userId: userCredential.user.uid,
						firstName,
						lastName,
						email,
						class: className
					});
				}
				
				message = `User ${firstName} ${lastName} created successfully!`;
				resetForm();
			}
			
			await loadUsers();
		} catch (err) {
			error = editingUser 
				? `Error updating user: ${err.message}` 
				: `Error creating user: ${err.message}`;
		} finally {
			loading = false;
		}
	}

	async function deleteUser(userId) {
		if (!confirm('Are you sure you want to delete this user?')) return;
		
		try {
			loading = true;
			error = null;
			
			// Find the user to get their role
			const userToDelete = users.find(u => u.userId === userId);
			
			if (userToDelete) {
				// Delete from users collection
				await deleteDoc(doc(db, "users", userId));
				
				// Also delete from role-specific collection if it exists
				if (userToDelete.role === 'student' || userToDelete.role === 'teacher' || userToDelete.role === 'admin') {
					await deleteDoc(doc(db, userToDelete.role + "s", userId));
				}
				
				message = "User deleted successfully!";
				await loadUsers();
			} else {
				error = "User not found";
			}
		} catch (err) {
			error = `Error deleting user: ${err.message}`;
		} finally {
			loading = false;
		}
	}

	function editUser(user) {
		editingUser = user;
		firstName = user.firstName || '';
		lastName = user.lastName || '';
		email = user.email || '';
		role = user.role || 'student';
		className = user.class || '';
		password = ''; // Clear password field for security
	}

	function resetForm() {
		editingUser = null;
		firstName = '';
		lastName = '';
		email = '';
		password = '';
		role = 'student';
		className = '';
	}
</script>

<main>
	<h1>User Management</h1>
	
	{#if error}
		<div class="alert error">
			{error}
			<button on:click={() => error = null} class="close-btn">×</button>
		</div>
	{/if}
	
	{#if message}
		<div class="alert success">
			{message}
			<button on:click={() => message = null} class="close-btn">×</button>
		</div>
	{/if}
	
	<section class="user-form-section">
		<h2>{editingUser ? 'Edit User' : 'Create New User'}</h2>
		<form on:submit|preventDefault={handleSubmit}>
			<div class="form-group">
				<label for="firstName">First Name</label>
				<input 
					type="text" 
					id="firstName" 
					bind:value={firstName} 
					required
					placeholder="Enter first name"
				/>
			</div>
			
			<div class="form-group">
				<label for="lastName">Last Name</label>
				<input 
					type="text" 
					id="lastName" 
					bind:value={lastName} 
					required
					placeholder="Enter last name"
				/>
			</div>
			
			<div class="form-group">
				<label for="email">Email</label>
				<input 
					type="email" 
					id="email" 
					bind:value={email} 
					required
					placeholder="Enter email address"
					disabled={editingUser}
				/>
			</div>
			
			{#if !editingUser}
				<div class="form-group">
					<label for="password">Password</label>
					<input 
						type="password" 
						id="password" 
						bind:value={password} 
						required={!editingUser}
						placeholder="Enter password"
					/>
				</div>
			{/if}
			
			<div class="form-group">
				<label for="role">Role</label>
				<select id="role" bind:value={role} required>
					{#each roles as roleOption}
						<option value={roleOption}>{roleOption.charAt(0).toUpperCase() + roleOption.slice(1)}</option>
					{/each}
				</select>
			</div>
			
			<div class="form-group">
				<label for="class">Class</label>
				<input 
					type="text" 
					id="class" 
					bind:value={className}
					placeholder="Enter class (e.g. 5B)"
				/>
			</div>
			
			<div class="form-actions">
				<button type="submit" class="btn-primary" disabled={loading}>
					{loading ? 'Processing...' : (editingUser ? 'Update User' : 'Create User')}
				</button>
				{#if editingUser}
					<button type="button" class="btn-secondary" on:click={resetForm}>
						Cancel
					</button>
				{/if}
			</div>
		</form>
	</section>
	
	<section class="user-list-section">
		<h2>Existing Users</h2>
		{#if loading && users.length === 0}
			<p class="loading">Loading users...</p>
		{:else if users.length === 0}
			<p class="no-users">No users found. Create a new user to get started.</p>
		{:else}
			<div class="table-container">
				<table>
					<thead>
						<tr>
							<th>Name</th>
							<th>Email</th>
							<th>Role</th>
							<th>Class</th>
							<th>Created</th>
							<th>Actions</th>
						</tr>
					</thead>
					<tbody>
						{#each users as user (user.userId)}
							<tr>
								<td>{user.firstName} {user.lastName}</td>
								<td>{user.email}</td>
								<td>
									<span class="badge {user.role}">
										{user.role.charAt(0).toUpperCase() + user.role.slice(1)}
									</span>
								</td>
								<td>{user.class || '-'}</td>
								<td>
									{user.createdAt instanceof Date
										? user.createdAt.toLocaleDateString()
										: 'N/A'}
								</td>
								<td class="actions">
									<button class="edit-btn" on:click={() => editUser(user)}>
										Edit
									</button>
									<button class="delete-btn" on:click={() => deleteUser(user.userId)}>
										Delete
									</button>
								</td>
							</tr>
						{/each}
					</tbody>
				</table>
			</div>
		{/if}
	</section>
</main>

<style>
	main {
		max-width: 1200px;
		margin: 0 auto;
		padding: 20px;
		font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,
			Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
	}
	
	h1 {
		color: #3e3e3e;
		border-bottom: 2px solid #eee;
		padding-bottom: 10px;
	}
	
	h2 {
		color: #555;
		font-size: 1.3rem;
		margin-bottom: 1rem;
	}
	
	section {
		margin-bottom: 2rem;
		padding: 1.5rem;
		background-color: #f9f9f9;
		border-radius: 6px;
		box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
	}
	
	.alert {
		padding: 12px;
		border-radius: 4px;
		margin-bottom: 20px;
		display: flex;
		justify-content: space-between;
		align-items: center;
	}
	
	.error {
		background-color: #ffe6e6;
		color: #d32f2f;
	}
	
	.success {
		background-color: #e6ffe6;
		color: #388e3c;
	}
	
	.close-btn {
		background: none;
		border: none;
		font-size: 20px;
		cursor: pointer;
		color: inherit;
	}
	
	form {
		display: flex;
		flex-direction: column;
		gap: 15px;
	}
	
	.form-group {
		display: flex;
		flex-direction: column;
		gap: 5px;
	}
	
	label {
		font-weight: 500;
		color: #555;
	}
	
	input, select {
		padding: 10px;
		border: 1px solid #ddd;
		border-radius: 4px;
		font-size: 16px;
		transition: border-color 0.2s;
	}
	
	input:focus, select:focus {
		outline: none;
		border-color: #4a90e2;
		box-shadow: 0 0 0 2px rgba(74, 144, 226, 0.2);
	}
	
	.form-actions {
		display: flex;
		gap: 10px;
		margin-top: 10px;
	}
	
	button {
		padding: 10px 15px;
		border: none;
		border-radius: 4px;
		font-size: 16px;
		cursor: pointer;
		transition: background-color 0.2s;
	}
	
	button:disabled {
		opacity: 0.7;
		cursor: not-allowed;
	}
	
	.btn-primary {
		background-color: #4a90e2;
		color: white;
	}
	
	.btn-primary:hover:not(:disabled) {
		background-color: #3a7bc8;
	}
	
	.btn-secondary {
		background-color: #e0e0e0;
		color: #333;
	}
	
	.btn-secondary:hover:not(:disabled) {
		background-color: #d0d0d0;
	}
	
	.table-container {
		overflow-x: auto;
	}
	
	table {
		width: 100%;
		border-collapse: collapse;
		border-spacing: 0;
	}
	
	th, td {
		text-align: left;
		padding: 12px;
		border-bottom: 1px solid #eee;
	}
	
	th {
		background-color: #f5f5f5;
		font-weight: 600;
	}
	
	tr:hover {
		background-color: #f9f9f9;
	}
	
	.actions {
		display: flex;
		gap: 8px;
	}
	
	.edit-btn {
		background-color: #4a90e2;
		color: white;
		padding: 6px 10px;
		font-size: 14px;
	}
	
	.delete-btn {
		background-color: #e53935;
		color: white;
		padding: 6px 10px;
		font-size: 14px;
	}
	
	.badge {
		display: inline-block;
		padding: 4px 8px;
		border-radius: 4px;
		font-size: 12px;
		font-weight: 600;
		text-transform: uppercase;
	}
	
	.badge.student {
		background-color: #4caf50;
		color: white;
	}
	
	.badge.teacher {
		background-color: #2196f3;
		color: white;
	}
	
	.badge.admin {
		background-color: #9c27b0;
		color: white;
	}
	
	.loading, .no-users {
		text-align: center;
		color: #888;
		font-style: italic;
		padding: 20px;
	}
</style>