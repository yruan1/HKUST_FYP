<script lang="ts">
	import { goto } from '$app/navigation';
	import ChatBotWidget from '$lib/components/ChatBotWidget.svelte';
	import SearchHeader from '$lib/components/SearchHeader.svelte';

	let question = '';
	let essay = '';
	let loading = false;

	async function handleGrade() {
		loading = true;
		try {
			const response = await fetch('/api/grade', {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json'
				},
				body: JSON.stringify({
					question,
					answer: essay
				})
			});

			if (!response.ok) {
				throw new Error('Grading failed');
			}

			const data = await response.json();

			if (data.error) {
				throw new Error(data.error);
			}

			// Store the results in localStorage
			localStorage.setItem('examData', JSON.stringify(data.examData));
			localStorage.setItem('examResult', JSON.stringify(data.examResult));

			// Navigate to result page
			await goto('/check/result');
		} catch (error) {
			console.error('Error:', error);
			// Handle error (show error message to user)	
		} finally {
			loading = false;
		}
	}

	function handleReset() {
		question = '';
		essay = '';
	}
</script>

<main>
	<ChatBotWidget />
	
</main>

<div class="container">
	<h1>IELTS Writing Task 2 Question</h1>
	<textarea bind:value={question} placeholder="Enter the IELTS Writing Task 2 question here." />

	<h2>Your Essay</h2>
	<textarea bind:value={essay} placeholder="Enter your essay here." />

	<div class="button-group">
		<button class="grade" on:click={handleGrade} disabled={loading}>
			<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
				<line x1="22" y1="2" x2="11" y2="13" />
				<polygon points="22 2 15 22 11 13 2 9 22 2" />
			</svg>
			{loading ? 'Grading...' : 'Grade my essay'}
		</button>

		<button class="reset" on:click={handleReset} disabled={loading}>
			<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
				<path d="M21 12a9 9 0 1 1-9-9c2.52 0 4.93 1 6.74 2.74L21 8" />
				<path d="M21 3v5h-5" />
			</svg>
			Start a new one
		</button>
	</div>
</div>

<style lang="scss">
	:global(body) {
		margin: 0;
		padding: 0;
		background: white;
		font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
	}

	.container {
		max-width: 1000px;
		margin: 40px auto;
		padding: 32px;
	}

	h1,
	h2 {
		font-size: 18px;
		color: #333;
		font-weight: 500;
		margin: 0 0 16px 0;
	}

	textarea {
		width: 100%;
		padding: 16px;
		border: 1px solid #e0e0e0;
		border-radius: 8px;
		background: #f8f9fa;
		margin-bottom: 32px;
		resize: none;
		font-size: 15px;
		line-height: 1.6;
		font-family: inherit;

		&:first-of-type {
			height: 160px;
		}

		&:last-of-type {
			height: 320px;
		}

		&::placeholder {
			color: #666;
		}
	}

	.button-group {
		display: flex;
		gap: 12px;
		margin-bottom: 40px;
	}

	button {
		display: flex;
		align-items: center;
		gap: 8px;
		padding: 12px 24px;
		border: none;
		border-radius: 6px;
		font-size: 14px;
		cursor: pointer;
		color: white;
		transition: all 0.2s ease;

		&:disabled {
			opacity: 0.7;
			cursor: not-allowed;
			transform: none;
		}

		&:not(:disabled):hover {
			transform: translateY(-1px);
		}

		svg {
			width: 16px;
			height: 16px;
		}
	}

	.grade {
		background-color: #0066ff;
		&:not(:disabled):hover {
			background-color: #0052cc;
		}
	}

	.reset {
		background-color: #666;
		&:not(:disabled):hover {
			background-color: #555;
		}
	}

	@media (max-width: 768px) {
		.container {
			padding: 16px;
		}

		.button-group {
			flex-direction: column;
		}
	}
</style>
