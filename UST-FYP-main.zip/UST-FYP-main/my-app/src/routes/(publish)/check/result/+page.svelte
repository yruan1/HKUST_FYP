<script lang="ts">
	import ResultCard from '$lib/components/Result/ResultCard.svelte';
	import ResultTag from '$lib/components/Result/ResultTagBar.svelte';
	import ScrollRowBar from '$lib/components/Result/ScrollRowBar.svelte';
	import { onMount } from 'svelte';
	import { page } from '$app/stores';
	import { marked } from 'marked';
	import LoadingPage from '$lib/components/loadingPage.svelte';

	let currentRowbarIndex: number = 0;
	let currentNavTagIndex: number = 0;
	let questionNumber: HTMLHeadingElement;
	let taskTitile: HTMLHeadingElement;
	let taskContent: HTMLHeadingElement;
	let examData: any;
	let examResult: any;
	let loading = false;
	let error: string | null = null;
	let activeCommentType: 'ai' | 'teacher' = 'ai';
	let currentComment: string = '';
	let isLoadingGrammar = false;

	function getContentType(rowbarIndex: number): string {
		switch (rowbarIndex) {
			case 0:
				return 'content';
			case 1:
				return 'language';
			case 2:
				return 'organization';
			default:
				return 'grammar';
		}
	}

	async function fetchGrammarAnalysis() {
		if (!examResult?.answers || !examData?.questions) return;

		const questionKey = (currentNavTagIndex + 1).toString();
		const answer = examResult.answers[questionKey];
		const question = examData.questions[currentNavTagIndex]?.content;

		if (examResult.comment?.grammarAnalysis?.[questionKey]?.analysis) {
			currentComment = examResult.comment.grammarAnalysis[questionKey].analysis;
			return;
		}

		isLoadingGrammar = true;
		currentComment = '# Grammar Analysis\n\nAnalyzing grammar...';

		try {
			const response = await fetch('/api/grammar', {
				// Changed from absolute to relative path
				method: 'POST',
				headers: {
					'Content-Type': 'application/json'
				},
				body: JSON.stringify({
					question,
					answer
				})
			});

			const data = await response.json();

			if (!response.ok) {
				throw new Error(`Failed to analyze grammar: ${data.error || response.statusText}`);
			}

			if (!data.success || !data.analysis) {
				throw new Error('Invalid response format');
			}

			if (!examResult.comment) examResult.comment = {};
			if (!examResult.comment.grammarAnalysis) examResult.comment.grammarAnalysis = {};

			examResult.comment.grammarAnalysis[questionKey] = data.analysis;
			localStorage.setItem('examResult', JSON.stringify(examResult));

			currentComment = data.analysis.analysis || data.analysis;
		} catch (error) {
			console.error('Grammar analysis error:', error);
			currentComment = `# Grammar Analysis\n\nFailed to analyze grammar: ${error.message}`;
		} finally {
			isLoadingGrammar = false;
		}
	}

	$: if (currentNavTagIndex !== undefined && examData) {
		updateQuestionContent(currentNavTagIndex);
		if (examResult) {
			const contentType = getContentType(currentRowbarIndex);
			if (contentType === 'grammar') {
				fetchGrammarAnalysis();
			} else {
				currentComment = getContent(currentNavTagIndex, contentType);
			}
		}
	}

	function getContent(questionIndex: number, contentType: string): string {
		if (!examResult?.comment) return '';

		const questionKey = (questionIndex + 1).toString();

		if (activeCommentType === 'teacher') {
			return examResult?.teacherComments?.[questionKey]
				? `# Teacher Comments\n\n${examResult.teacherComments[questionKey]}`
				: '# Teacher Comments\n\nNo feedback provided yet.';
		}

		if (contentType === 'grammar') {
			if (isLoadingGrammar) {
				return '# Grammar Analysis\n\nAnalyzing grammar...';
			}
			const grammarAnalysis = examResult.comment.grammarAnalysis?.[questionKey];
			return grammarAnalysis?.analysis || '# Grammar Analysis\n\nAnalyzing grammar...';
		}

		const comments = examResult.comment[contentType]?.[questionKey];
		if (!comments) return `# ${contentType} feedback not available`;

		return comments
			.map((item: string, index: number) =>
				index === 0 ? `# ${contentType} Feedback\n\n${item}` : `- ${item}`
			)
			.join('\n\n');
	}

	function updateQuestionContent(index: number) {
		if (!examData?.questions || !questionNumber || !taskContent) return;

		const question = examData.questions[index];
		if (question) {
			questionNumber.innerHTML = `Q${index + 1}`;
			taskContent.innerHTML = question.content;
			if (taskTitile) {
				taskTitile.innerHTML = `Task ${index + 1}`;
			}
		}
	}

	onMount(async () => {
		try {
			const storedExamData = localStorage.getItem('examData');
			const storedExamResult = localStorage.getItem('examResult');

			if (storedExamData && storedExamResult) {
				examData = JSON.parse(storedExamData);
				examResult = JSON.parse(storedExamResult);
				updateQuestionContent(currentNavTagIndex);
				currentComment = getContent(currentNavTagIndex, getContentType(currentRowbarIndex));

				if (examData?.questions) {
					for (let i = 0; i < Object.keys(examData.questions).length; i++) {
						currentNavTagIndex = i;
						await fetchGrammarAnalysis();
					}
					currentNavTagIndex = 0;
					currentComment = getContent(currentNavTagIndex, getContentType(currentRowbarIndex));
				}
			}
		} catch (error) {
			console.error('Error:', error);
			loading = false;
			error = 'Failed to load results';
		}
	});

	function scrollToHighlight() {
		setTimeout(() => {
			const highlightedElement = document.querySelector('.user-answer .highlight');
			if (highlightedElement) {
				highlightedElement.scrollIntoView({
					behavior: 'smooth',
					block: 'center'
				});
			}
		}, 100);
	}

	function countWords(text: string): number {
		if (!text) return 0;
		return text
			.trim()
			.split(/\s+/)
			.filter((word) => word.length > 0).length;
	}

	$: hasQuestions = examData && Object.keys(examData.questions || {}).length > 0;
</script>

<div class="container">
	{#if loading}
		<LoadingPage />
	{:else if error}
		<div class="error">{error}</div>
	{:else if hasQuestions}
		<div class="nav">
			<ResultTag bind:currentTagIndex={currentNavTagIndex} questions={examData?.questions || {}} />
		</div>

		<div class="header">
			<div class="question">
				<div>
					<div class="question-number">
						<h1 bind:this={questionNumber}>Q1</h1>
					</div>
					<h2 bind:this={taskTitile}>Task 1</h2>
				</div>
				<h2 bind:this={taskContent}>
					{examData?.questions[currentNavTagIndex]?.content || 'Loading...'}
				</h2>
			</div>

			<div class="summery">
				<div class="grade-section">
					<ResultCard
						value={examResult?.grade || 'Graded'}
						description="AI Comments"
						isTeacher={false}
						{activeCommentType}
					/>
				</div>

				{#if activeCommentType === 'ai'}
					<div class="scroll-section">
						<ScrollRowBar
							bind:RowBarIndex={currentRowbarIndex}
							tagList={['Content (C)', 'Language (L)', 'Organization (O)', 'Grammar Analysis']}
						/>
					</div>
				{/if}
			</div>
		</div>

		<div class="answer">
			<div class="user-answer">
				<div class="answer-container">
					<div class="answer-text">
						{examResult?.answers[(currentNavTagIndex + 1).toString()] || ''}
					</div>
					<div class="word-count">
						{countWords(examResult?.answers[(currentNavTagIndex + 1).toString()] || '')} words
					</div>
				</div>
			</div>

			<div class="system-answer">
				<div class="answer-container">
					<div class="answer-text">
						{#if activeCommentType === 'ai' && currentRowbarIndex === 3 && examResult?.comment?.grammarAnalysis}
							<h1>Grammar Analysis</h1>
							{#if !examResult.comment.grammarAnalysis[(currentNavTagIndex + 1).toString()]?.analysis}
								<p class="analyzing">Analyzing grammar...</p>
							{:else}
								{#each examResult.comment.grammarAnalysis[(currentNavTagIndex + 1).toString()].analysis
									.split(/\d+\./)
									.filter(Boolean) as section, index}
									{#if section.includes('Original:') && section.includes('Corrected:')}
										<div class="grammar-section">
											<button
												class="section-title"
												on:click={() => {
													const pattern = section.match(/❌\s*"([^"]+)"/)?.[1];
													if (pattern) {
														const text =
															examResult?.answers?.[(currentNavTagIndex + 1).toString()] || '';
														const answerText = document.querySelector('.user-answer .answer-text');

														if (answerText) {
															// Remove previous highlights
															document.querySelectorAll('.user-answer .highlight').forEach((el) => {
																const parent = el.parentNode;
																if (parent) {
																	parent.replaceChild(
																		document.createTextNode(el.textContent || ''),
																		el
																	);
																}
															});

															// Case-insensitive matching
															const lowerPattern = pattern.toLowerCase();
															const lowerText = text.toLowerCase();
															const startIndex = lowerText.indexOf(lowerPattern);

															if (startIndex !== -1) {
																const beforeMatch = text.substring(0, startIndex);
																const match = text.substring(
																	startIndex,
																	startIndex + pattern.length
																);
																const afterMatch = text.substring(startIndex + pattern.length);

																answerText.innerHTML = `${beforeMatch}<span class="highlight">${match}</span>${afterMatch}`;
																scrollToHighlight();
															} else {
																answerText.innerHTML = text;
															}
														}
													}
												}}
											>
												{index}. {section.split('\n')[0].trim()}
											</button>
											<div class="section-content">
												{@html marked(section.split('\n').slice(1).join('\n'))}
											</div>
										</div>
									{/if}
								{/each}
							{/if}
						{:else}
							{@html marked(currentComment)}
						{/if}
					</div>
				</div>
			</div>
		</div>
	{/if}
</div>

<style lang="scss">
	.grammar-section {
		margin-bottom: 24px;

		.section-title {
			width: 100%;
			text-align: left;
			padding: 8px 12px;
			margin-bottom: 8px;
			border-radius: 6px;
			background: transparent;
			border: none;
			color: var(--primary-color);
			font-weight: 600;
			font-size: 1.1rem;
			cursor: pointer;
			transition: all 0.2s ease;
			border-left: 3px solid transparent;

			&:hover {
				background-color: var(--primary-light);
				border-left-color: var(--primary-color);
			}
		}

		.section-content {
			padding-left: 12px;
		}
	}
	:root {
		--primary-color: #4f46e5;
		--primary-light: #eef2ff;
		--hover-color: #f1f5f9;
		--active-color: #e2e8f0;
		--text-primary: #1e293b;
		--text-secondary: #64748b;
		--background-light: #f8fafc;
		--border-color: #e2e8f0;
		--shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
		--shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1);
	}

	.container {
		display: flex;
		flex-direction: column;
		height: 100%;
		width: 100%;
		max-width: 1440px;
		margin: 0 auto;
		padding: 24px;
		background-color: var(--background-light);
		gap: 16px;
	}

	.nav {
		display: flex;
		align-items: center;
		height: 56px;
		background-color: white;
		padding: 0 20px;
		border-radius: 12px;
		box-shadow: var(--shadow-sm);
	}

	.header {
		display: flex;
		gap: 16px;
		min-height: 200px;
		> div {
			flex: 1;
			background-color: white;
			border-radius: 12px;
			box-shadow: var(--shadow-sm);
		}
	}

	.card-wrapper {
		cursor: pointer;
		transition: all 0.2s ease;
		position: relative;
		overflow: hidden;

		&:hover {
			transform: translateY(-2px);
		}

		&.active {
			:global(.result-card) {
				border: 2px solid var(--primary-color);
				background-color: var(--primary-light);
				transition: all 0.3s ease;
			}

			&::after {
				content: '';
				position: absolute;
				bottom: 0;
				left: 0;
				width: 100%;
				height: 2px;
				background-color: var(--primary-color);
				animation: slideIn 0.3s ease-out;
			}
		}
	}

	@keyframes slideIn {
		from {
			transform: scaleX(0);
		}
		to {
			transform: scaleX(1);
		}
	}

	.question {
		padding: 24px;
		> div {
			display: flex;
			align-items: center;
			margin-bottom: 20px;
			> .question-number {
				position: relative;
				padding-right: 24px;
				margin-right: 24px;
				> h1 {
					font-size: 32px;
					color: var(--primary-color);
					font-weight: 700;
					&::after {
						position: absolute;
						content: '';
						width: 2px;
						height: 100%;
						top: 0;
						right: 0;
						background-color: var(--primary-color);
						opacity: 0.3;
					}
				}
			}
			> h2 {
				color: var(--text-secondary);
				font-size: 20px;
				font-weight: 600;
			}
		}
		> h2 {
			background-color: var(--primary-light);
			border-radius: 12px;
			padding: 20px;
			font-size: 16px;
			line-height: 1.8;
			color: var(--text-primary);
		}
	}

	.summery {
		padding: 24px;
		display: flex;
		flex-direction: column;
		gap: 20px;
	}

	.grade-section {
		display: grid;
		grid-template-columns: 1fr 1fr;
		gap: 16px;
	}

	.scroll-section {
		height: 44px;
		display: flex;
		align-items: center;
	}

	.answer {
		display: flex;
		gap: 16px;
		flex: 1;
		min-height: 400px;

		> div {
			flex: 1;
			background-color: white;
			border-radius: 12px;
			box-shadow: var(--shadow-sm);
			transition: all 0.2s ease;

			&:hover {
				box-shadow: var(--shadow-md);
			}
		}
	}

	.answer-container {
		height: 100%;
		padding: 24px;
		display: flex;
		flex-direction: column;
		gap: 16px;
	}

	.answer-text {
		flex: 1;
		background-color: var(--background-light);
		border-radius: 12px;
		padding: 24px;
		line-height: 1.8;
		color: var(--text-primary);
		font-size: 16px;
		border: 1px solid var(--border-color);
		overflow-y: auto;
		white-space: pre-wrap;
		transition: all 0.3s ease;

		:global(.highlight) {
			background-color: #fef08a;
			padding: 0 2px;
			border-radius: 2px;
		}

		&.fade-in {
			animation: fadeIn 0.3s ease-out;
		}

		&::-webkit-scrollbar {
			width: 8px;
		}

		&::-webkit-scrollbar-track {
			background: var(--background-light);
			border-radius: 4px;
		}

		&::-webkit-scrollbar-thumb {
			background: var(--primary-color);
			border-radius: 4px;
			opacity: 0.7;
		}

		&::-webkit-scrollbar-thumb:hover {
			opacity: 1;
		}

		:global(h1) {
			font-size: 1.5rem;
			font-weight: 600;
			margin-bottom: 1rem;
			color: var(--primary-color);
		}

		:global(p) {
			margin-bottom: 1rem;
		}

		:global(ul) {
			list-style-type: disc;
			padding-left: 1.5rem;
			margin-bottom: 1rem;
		}

		:global(li) {
			margin-bottom: 0.5rem;
		}
	}

	@keyframes fadeIn {
		from {
			opacity: 0;
			transform: translateY(10px);
		}
		to {
			opacity: 1;
			transform: translateY(0);
		}
	}

	.word-count {
		align-self: flex-end;
		color: var(--text-secondary);
		padding: 8px 16px;
		border-radius: 24px;
		font-size: 14px;
		font-weight: 500;
		background-color: var(--primary-light);
		border: 1px solid var(--border-color);
		display: inline-flex;
		align-items: center;
		gap: 8px;
		transition: all 0.2s ease;

		&::before {
			content: '📝';
			font-size: 14px;
		}

		&:hover {
			transform: translateY(-2px);
			background-color: var(--primary-color);
			color: white;
		}
	}

	@media (max-width: 1024px) {
		.container {
			padding: 16px;
		}

		.header {
			flex-direction: column;
			> div {
				width: 100%;
			}
		}
	}

	@media (max-width: 768px) {
		.answer {
			flex-direction: column;
			> div {
				min-height: 300px;
			}
		}

		.question {
			padding: 20px;
			> div {
				> .question-number > h1 {
					font-size: 28px;
				}
				> h2 {
					font-size: 18px;
				}
			}
		}
	}
</style>
