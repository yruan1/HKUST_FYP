<script lang="ts">
    // Current step in the progress indicator
    let currentStep = 1;
  
    // States for the left sidebar
    let states = ['Part1', 'Part2', 'Part3'];
    let activeState = states[currentStep - 1]; // Sync activeState with currentStep
  
    // Evaluation metrics for the right section
    let metrics = [
      { label: 'Grammar/Spelling', score: '100%', status: 'success' },
      { label: 'Style Score', score: '50%', status: 'warning' },
      { label: 'Style Guide', score: '100%', status: 'success' }
    ];
  
    // Paper question and student answer
    let paperQuestion = "Write an essay discussing the impacts of technology on society.";
    let articleText = "";
  
    // Navigate between steps
    const goToNextStep = () => {
      if (currentStep < 3) {
        currentStep++;
        activeState = states[currentStep - 1];
      }
    };
  
    const goToPreviousStep = () => {
      if (currentStep > 1) {
        currentStep--;
        activeState = states[currentStep - 1];
      }
    };
  </script>
  
  <div class="container">
    <!-- Progress Bar -->
    <div class="progress-bar">
      {#each [1, 2, 3] as step}
        <!-- Step Circle -->
        <div class="step {currentStep === step ? 'active' : ''}">
          {step}
        </div>
        {#if step < 3}
          <!-- Connecting Line -->
          <div class="line {currentStep > step ? 'completed' : ''}"></div>
        {/if}
      {/each}
    </div>
  
    <!-- Main Layout -->
    <div class="main-content">
      <!-- Sidebar -->
      <div class="sidebar">
        <div class="state-list">
          {#each states as state}
            <div class="state {activeState === state ? 'active' : ''}">
              {state}
            </div>
          {/each}
        </div>
      </div>
  
      <!-- Content Area -->
      <div class="content">
        <div class="content-area">
          <!-- Top Section: Paper Question -->
          <div class="question-section">
            <h3>Paper Question</h3>
            <p>{paperQuestion}</p>
          </div>
  
          <!-- Separator -->
          <hr />
  
          <!-- Bottom Section: Student Answer -->
          <div class="answer-section">
            <h3>Your Answer</h3>
            <textarea
              bind:value={articleText}
              class="article-text"
              placeholder="Start typing your answer here..."
            ></textarea>
          </div>
  
          <!-- Navigation Buttons -->
          <div class="navigation-buttons">
            <button on:click={goToPreviousStep} disabled={currentStep === 1}>Previous</button>
            <button on:click={goToNextStep} disabled={currentStep === 3}>Next</button>
          </div>
        </div>
      </div>
  
      <!-- Evaluation Metrics -->
      <div class="evaluation">
        <div class="evaluation-header">
          <span>Goal: <span style="color: #007bff;">50%</span></span>
          <span>Improvement: <span style="color: #28a745;">70%</span></span>
        </div>
  
        {#each metrics as metric}
          <div class="metric {metric.status}">
            <span>{metric.label}</span>
            <span class="icon {metric.status}">
              {metric.status === 'success' ? '✔' : '⚠'}
            </span>
            <span>{metric.score}</span>
          </div>
        {/each}
      </div>
    </div>
  </div>
  
  <style lang="scss">
    /* General Reset */
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
  
    :global(body) {
      font-family: Arial, sans-serif;
      background-color: #f8f9fa;
    }
  
    /* Full-Screen Layout */
    .container {
      display: flex;
      flex-direction: column;
      height: 100vh;
      width: 100vw;
      padding: 0;
    }
  
    /* Progress Bar */
    .progress-bar {
      display: flex;
      align-items: center;
      justify-content: center;
      margin-bottom: 10px;
      padding: 15px;
      background-color: #f8f9fa;
    }
  
    .step {
      width: 40px;
      height: 40px;
      border-radius: 50%;
      background-color: #e0e0e0;
      color: #fff;
      font-weight: bold;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: background-color 0.3s, color 0.3s;
    }
  
    .step.active {
      background-color: #007bff;
      color: #fff;
    }
  
    .line {
      flex: 1;
      height: 4px;
      background-color: #e0e0e0;
      margin: 0 5px;
      transition: background-color 0.3s;
    }
  
    .line.completed {
      background-color: #007bff;
    }
  
    /* Main Content Layout */
    .main-content {
      display: grid;
      grid-template-columns: 1fr 2fr 1fr;
      gap: 10px;
      flex: 1;
      height: 100%;
    }
  
    /* Sidebar */
    .sidebar {
      background-color: #fff;
      border: 1px solid #ddd;
      border-radius: 8px;
      padding: 20px;
      overflow: auto;
    }
  
    .state-list {
      display: flex;
      flex-direction: column;
      gap: 10px;
    }
  
    .state {
      padding: 10px 15px;
      border: 1px solid #ddd;
      border-radius: 5px;
      text-align: center;
      background-color: #f8f9fa;
      font-weight: bold;
      color: #6c757d;
    }
  
    .state.active {
      border-color: #007bff;
      background-color: #e7f3ff;
      color: #007bff;
    }
  
    /* Content Area */
    .content {
      background-color: #fff;
      border: 1px solid #ddd;
      border-radius: 8px;
      padding: 20px;
      overflow: auto;
      height: 100%;
    }
  
    .content-area {
      border: 2px solid #007bff;
      border-radius: 8px;
      display: flex;
      flex-direction: column;
      height: 100%;
    }
  
    .question-section {
      flex: 0 0 auto;
      padding: 10px 0;
      font-size: 16px;
      color: #333;
    }
  
    .question-section h3 {
      font-size: 18px;
      color: #007bff;
      margin-bottom: 10px;
    }
  
    .answer-section {
      flex: 1 1 auto;
      display: flex;
      flex-direction: column;
    }
  
    .answer-section h3 {
      font-size: 18px;
      color: #007bff;
      margin-bottom: 10px;
    }
  
    .article-text {
      flex: 1 1 auto;
      width: 100%;
      border: 1px solid #ddd;
      border-radius: 5px;
      padding: 10px;
      font-size: 16px;
      font-family: Arial, sans-serif;
      resize: none;
      box-sizing: border-box;
    }
  
    .article-text:focus {
      outline: none;
      border-color: #007bff;
      box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
    }
  
    .navigation-buttons {
      flex: 0 0 auto;
      margin-top: 10px;
      display: flex;
      justify-content: space-between;
      padding: 10px 0;
    }
  
    .navigation-buttons button {
      padding: 10px 20px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      background-color: #007bff;
      color: #fff;
      font-weight: bold;
      transition: background-color 0.3s;
    }
  
    .navigation-buttons button:disabled {
      background-color: #ddd;
      cursor: not-allowed;
    }
  
    /* Evaluation Metrics */
    .evaluation {
      background-color: #fff;
      border: 1px solid #ddd;
      border-radius: 8px;
      padding: 20px;
      overflow: auto;
    }
  
    .evaluation-header {
      display: flex;
      justify-content: space-between;
      margin-bottom: 20px;
      font-weight: bold;
    }
  
    .metric {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 10px 15px;
      border: 1px solid #ddd;
      border-radius: 5px;
      margin-bottom: 10px;
      background-color: #fff;
    }
  
    .metric.success {
      border-left: 5px solid #28a745;
    }
  
    .metric.warning {
      border-left: 5px solid #ffc107;
    }
  
    .metric .icon {
      font-size: 20px;
    }
  
    .metric .icon.success {
      color: #28a745;
    }
  
    .metric .icon.warning {
      color: #ffc107;
    }
  </style>