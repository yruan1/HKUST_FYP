<script lang="ts">
	import './style.scss';
</script>

<slot />
