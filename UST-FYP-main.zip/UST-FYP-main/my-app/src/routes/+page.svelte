<script lang="ts">
	import { auth } from '../firebase';
	import { signInWithEmailAndPassword } from 'firebase/auth';
	import { goto } from '$app/navigation';
	import { error } from '@sveltejs/kit';
	//export let data;

	//let email = 'ckloaj@connect.ust.hk';
	//let password = '1234567890';
	let email = '';
	let password = '';
	let errorMessage = '';
	let rememberMe = false;
	let role = '';

	const login = async () => {
		try {
			document.cookie = 'uid=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;';
			errorMessage = '';
			const userCredential = await signInWithEmailAndPassword(auth, email, password);
			console.log('User logged in:', userCredential.user);
			document.cookie = 'uid=' + userCredential.user.uid; //set cookie uid

			//fetch the role
			let uid = userCredential.user.uid;
			let url = '/api/auth/getUserRole?uid=' + uid;
			const response = await fetch(url);
			if (!response.ok) {
				throw error(response.status, 'Failed to fetch user data');
			}
			const data = await response.json();
			role = data.role;

			if(role === "admin"){
				goto('/settings/users');
			}else{
				goto('/' + role);
			}
		} catch (error) {
			console.error('Login failed:', error);
		}
	};
</script>

<div class="page-container">
	<div class="container">
		<div class="left">
			<h2>Welcome back</h2>
			<p>Please enter your details to continue</p>

			<form on:submit|preventDefault={login}>
				<div class="input-group">
					<span class="input-icon">📧</span>
					<input type="email" placeholder="Email address" bind:value={email} required />
				</div>

				<div class="input-group">
					<span class="input-icon">🔒</span>
					<input type="password" placeholder="Password" bind:value={password} required />
				</div>

				<div class="checkbox-container">
					<div class="remember-me">
						<input type="checkbox" id="remember" bind:checked={rememberMe} />
						<label for="remember">Remember</label>
					</div>
					<!-- <a href="/forgot-password" class="forgot-password">Forgot password?</a> -->
				</div>

				<button type="submit">Sign in</button>
			</form>
		</div>

		<div class="right">
			<div class="decoration decoration-1"></div>
			<div class="decoration decoration-2"></div>
			<div class="right-content">
				<h3>UST Writing</h3>
			</div>
		</div>
	</div>
</div>

<style>
	:global(*) {
		margin: 0;
		padding: 0;
		box-sizing: border-box;
	}

	.page-container {
		min-height: 100vh;
		width: 100%;
		background: linear-gradient(135deg, #f5f7fa 0%, #e4e8ed 100%);
		padding: 2rem 1rem;
	}

	.container {
		max-width: 1200px;
		margin: 0 auto;
		background-color: white;
		border-radius: 20px;
		box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
		overflow: hidden;
		display: flex;
		min-height: 600px;
	}

	.left {
		flex: 1;
		padding: 3.5rem;
		display: flex;
		flex-direction: column;
		justify-content: center;
		position: relative;
	}

	h2 {
		margin-bottom: 1rem;
		font-size: 2.5rem;
		font-weight: 700;
		color: #1a1a1a;
		line-height: 1.2;
	}

	p {
		margin-bottom: 2.5rem;
		color: #666;
		font-size: 1.1rem;
	}

	.input-group {
		position: relative;
		margin-bottom: 1.5rem;
	}

	.input-icon {
		position: absolute;
		left: 1rem;
		top: 50%;
		transform: translateY(-50%);
		color: #6b47dc;
	}

	input {
		width: 100%;
		padding: 1rem 1rem 1rem 3rem;
		border: 2px solid #eef0f3;
		border-radius: 12px;
		font-size: 1rem;
		transition: all 0.3s ease;
		background-color: #f8fafc;
	}

	input:focus {
		border-color: #6b47dc;
		outline: none;
		box-shadow: 0 0 0 4px rgba(107, 71, 220, 0.1);
		background-color: white;
	}

	.checkbox-container {
		display: flex;
		align-items: center;
		justify-content: space-between;
		margin-bottom: 2rem;
	}

	.remember-me {
		display: flex;
		align-items: center;
		gap: 0.5rem;
	}

	.checkbox-container label {
		color: #4a5568;
		font-size: 0.95rem;
	}

	.forgot-password {
		color: #6b47dc;
		text-decoration: none;
		font-weight: 600;
		font-size: 0.95rem;
		transition: color 0.2s ease;
	}

	.forgot-password:hover {
		color: #5535be;
	}

	button {
		width: 100%;
		padding: 1rem;
		background: linear-gradient(135deg, #6b47dc, #9e68ed);
		color: white;
		border: none;
		border-radius: 12px;
		font-size: 1rem;
		font-weight: 600;
		cursor: pointer;
		transition:
			transform 0.2s ease,
			box-shadow 0.2s ease;
		margin-bottom: 2rem;
	}

	button:hover {
		transform: translateY(-2px);
		box-shadow: 0 4px 12px rgba(107, 71, 220, 0.2);
	}

	button:active {
		transform: translateY(0);
	}

	.signup {
		text-align: center;
		font-size: 0.95rem;
		color: #4a5568;
	}

	.signup a {
		color: #6b47dc;
		text-decoration: none;
		font-weight: 600;
		margin-left: 0.5rem;
		transition: color 0.2s ease;
	}

	.signup a:hover {
		color: #5535be;
	}

	.right {
		flex: 1;
		background: linear-gradient(135deg, #6b47dc, #9e68ed);
		padding: 3rem;
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
		color: white;
		position: relative;
		overflow: hidden;
	}

	.right-content {
		position: relative;
		z-index: 1;
		text-align: center;
	}

	.right h3 {
		font-size: 2.5rem;
		font-weight: 700;
		margin-bottom: 1.5rem;
	}

	.right p {
		color: rgba(255, 255, 255, 0.9);
		font-size: 1.1rem;
		line-height: 1.6;
	}

	.decoration {
		position: absolute;
		background: rgba(255, 255, 255, 0.1);
		border-radius: 50%;
	}

	.decoration-1 {
		width: 300px;
		height: 300px;
		top: -100px;
		right: -100px;
	}

	.decoration-2 {
		width: 200px;
		height: 200px;
		bottom: -50px;
		left: -50px;
	}

	@media (max-width: 768px) {
		.container {
			flex-direction: column;
		}

		.right {
			display: none;
		}

		.left {
			padding: 2rem;
		}
	}
</style>
