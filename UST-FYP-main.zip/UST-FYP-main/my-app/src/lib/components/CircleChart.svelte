<script lang="ts">
	export let cx = 50;
	export let cy = 50;
	export let r = '30px';
	export let value: number = 0;
	export let color = 'red';
	let circle_length = (188.1910858154297 * (100 - value)) / 100;
</script>

<div>
	<svg style:--svg-width="{cx * 2}px" style:--svg-height="{cy * 2}px" style:--circle-color={color}>
		<circle {cx} {cy} {r} style="stroke-dashoffset:{circle_length}" />
		<!-- <circle class="background" {cx} {cy} {r} /> -->
	</svg>
	<p>
		{value}%
	</p>
</div>

<style lang="scss">
	svg {
		width: var(--svg-width);
		height: var(--svg-height);

		> circle:first-child {
			fill: none;
			stroke: var(--circle-color);
			stroke-width: 10px;
			stroke-dasharray: 188.1910858154297;
			//stroke-dashoffset: calc(188.1910858154297 / 2);
			transition: stroke-dashoffset 1s ease;
			transform-origin: 50% 50%;
			stroke-linecap: round;
			transform: rotate(-90deg);
			//animation: draw-chart 1s ease infinite;
		}
	}
	// .background {
	// 	fill: none;
	// 	stroke-width: 10px;
	// 	stroke: linear-gradient(90deg, green, white);
	// 	stroke-dasharray: 188.1910858154297;
	// }
	@keyframes draw-chart {
		to {
			stroke-dashoffset: 188.1910858154297;
		}
	}
	div {
		width: fit-content;
		display: flex;
		justify-content: center;
		align-items: center;
	}
	p {
		position: absolute;
	}
</style>
