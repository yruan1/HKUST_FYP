<script lang="ts">
	import { goto } from '$app/navigation';

	const navigateToAICorrection = () => {
		goto('/check');
	};

</script>

<div class="home-container">
	<h1>Home</h1>

	<div class="menu-grid">
		<div class="menu-item ai-correction" on:click={navigateToAICorrection}>
			<div class="icon-container">
				<div class="book book1"></div>
				<div class="book book2"></div>
				<div class="book book3"></div>
			</div>
			<span class="menu-text">AI correction</span>
		</div>
	</div>
</div>

<style lang="scss">
	.home-container {
		padding: 20px;
		margin-left: 60px;
	}

	h1 {
		font-size: 24px;
		font-weight: bold;
		margin-bottom: 20px;
		color: #333;
	}

	.menu-grid {
		display: flex;
		gap: 20px;
	}

	.menu-item {
		width: 350px; /* Increased from 260px */
		height: 200px; /* Increased from 160px */
		border-radius: 20px; /* Slightly increased for better proportion */
		padding: 25px; /* Increased padding */
		display: flex;
		flex-direction: column;
		justify-content: flex-end;
		cursor: pointer;
		position: relative;
	}

	/* Also scale up the text size */
	.menu-text {
		color: white;
		font-size: 22px; /* Increased from 18px */
		font-weight: bold;
	}

	/* Scale up the icon sizes proportionally */
	.book {
		width: 50px; /* Increased from 40px */
		height: 60px; /* Increased from 50px */
		position: absolute;
		border-radius: 3px;
	}

	/* Adjust icon positioning */
	.icon-container {
		position: absolute;
		top: 45px; /* Adjusted for larger card */
		left: 40px; /* Adjusted for larger card */
	}

	/* Also adjust globe size */
	.globe {
		width: 75px; /* Increased from 60px */
		height: 75px; /* Increased from 60px */
		background-color: #35c2c1;
		border-radius: 50%;
		border: 4px solid #f9c270; /* Slightly thicker border */
	}

	.stand {
		width: 50px; /* Increased from 40px */
		height: 15px; /* Increased from 12px */
		background-color: #8a6eff;
		border-radius: 12px;
		margin: 5px auto 0;
	}

	.globe-container {
		position: absolute;
		top: 45px; /* Adjusted for larger card */
		left: 40px; /* Adjusted for larger card */
	}

	.ai-correction {
		background: linear-gradient(135deg, #add8e6, #f8a5c2);
	}

	.vocab {
		background: linear-gradient(135deg, #da9dff, #8364e8);
	}

	.menu-text {
		color: white;
		font-size: 18px;
		font-weight: bold;
	}

	/* Book icon styling */
	.icon-container {
		position: absolute;
		top: 35px;
		left: 30px;
	}

	.book {
		width: 40px;
		height: 50px;
		position: absolute;
		border-radius: 3px;
	}

	.book1 {
		background-color: #8a6eff;
		transform: rotate(-25deg) translateY(-5px);
		z-index: 3;
	}

	.book2 {
		background-color: #35c2c1;
		transform: rotate(-10deg) translateX(15px) translateY(5px);
		z-index: 2;
	}

	.book3 {
		background-color: #a4beff;
		transform: rotate(5deg) translateX(30px) translateY(10px);
		z-index: 1;
	}

	/* Globe icon styling */
	.globe-container {
		position: absolute;
		top: 35px;
		left: 30px;
	}

	.globe {
		width: 60px;
		height: 60px;
		background-color: #35c2c1;
		border-radius: 50%;
		border: 3px solid #f9c270;
	}

	.stand {
		width: 40px;
		height: 12px;
		background-color: #8a6eff;
		border-radius: 10px;
		margin: 5px auto 0;
	}
</style>
