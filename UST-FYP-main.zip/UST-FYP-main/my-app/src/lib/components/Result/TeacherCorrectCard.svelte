<script lang="ts">
	export let description: string = '';
	export let type: 'CORRECT' | 'WRONG' | 'WARNING' = 'CORRECT';
	export let value: string;
	export let callback1: () => void = () => {};
	export let callback2 = () => {};
	export let readonly: boolean = false;
</script>

<div class="card">
	<!-- ❌✅⚠️ -->
	<p>
		{#if type === 'CORRECT'}
			<span>✅</span>
		{/if}{#if type === 'WRONG'}
			<span>❌</span>
		{/if}
		{#if type === 'WARNING'}
			<span>⚠️</span>
		{/if}"{description}"
	</p>

	<textarea bind:value placeholder="Enter your comment here" readonly={readonly}/>
    {#if !readonly}
        <div class="button-row">
            <button class="save" on:click={callback1}> </button>
            <button class="cancel" on:click={callback2}> Cancel </button>
        </div>
    {/if}
</div>

<style lang="scss">
	.card {
		display: flex;
		flex-direction: column;
		gap: 0.5rem;
		padding: 1rem;
		border-radius: 0.5rem;
		background-color: var(--primary-light);
		box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
		> textarea {
			padding: 0.5rem;
			border-radius: 0.5rem;
			border: 1px solid white;
			background-color: white;
			color: var(--primary);
			font-size: 1rem;
			min-height: 100px;
		}
	}
	.button-row {
		display: flex;
		flex-direction: row-reverse;
		> button {
			align-self: flex-end;
			color: var(--text-secondary);
			padding: 8px 16px;
			border-radius: 24px;
			font-size: 14px;
			font-weight: 500;
			background-color: var(--primary-light);
			border: 1px solid var(--border-color);
			display: inline-flex;
			align-items: center;
			gap: 8px;
			transition: all 0.2s ease;
			&:hover {
				transform: translateY(-2px);
				background-color: var(--primary-color);
				color: white;
			}
		}
	}
	.save {
		&::before {
			content: '💾';
			font-size: 14px;
		}
	}
</style>
