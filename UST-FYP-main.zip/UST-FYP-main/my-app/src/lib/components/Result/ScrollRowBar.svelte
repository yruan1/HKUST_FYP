<script lang="ts">
    export let tagList: string[] = [
        'Content (C)',
        'Language (L)',
        'Organization (O)',
        'Grammar (G)'
    ];
    export let RowBarIndex = 0;

    let listBox: HTMLDivElement;
    let pairIndex = 0;
    $: visibleTags = tagList.slice(pairIndex * 2, (pairIndex * 2) + 2);
    
    function moveRight() {
        if (pairIndex < Math.floor((tagList.length - 1) / 2)) {
            pairIndex++;
            RowBarIndex = pairIndex * 2;
            scrollToActive();
        }
    }

    function moveLeft() {
        if (pairIndex > 0) {
            pairIndex--;
            RowBarIndex = pairIndex * 2;
            scrollToActive();
        }
    }

    function scrollToActive() {
        if (listBox) {
            const activeButton = listBox.children[RowBarIndex % 2] as HTMLElement;
            if (activeButton) {
                const containerWidth = listBox.offsetWidth;
                const buttonLeft = activeButton.offsetLeft;
                const buttonWidth = activeButton.offsetWidth;

                const idealScroll = buttonLeft - (containerWidth / 2) + (buttonWidth / 2);

                listBox.scrollTo({
                    left: idealScroll,
                    behavior: 'smooth'
                });
            }
        }
    }
</script>

<div class="container">
    <button
        class="arrow left-arrow"
        on:click={moveLeft}
        aria-label="Scroll left"
        disabled={pairIndex === 0}
    >
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M15 18l-6-6 6-6"/>
        </svg>
    </button>

    <div 
        class="list-box"
        bind:this={listBox}
    >
        {#each visibleTags as tag, i}
            <button
                class="tag"
                class:active={RowBarIndex === (pairIndex * 2) + i}
                on:click={() => {
                    RowBarIndex = (pairIndex * 2) + i;
                    scrollToActive();
                }}
            >
                {tag}
            </button>
        {/each}
    </div>

    <button
        class="arrow right-arrow"
        on:click={moveRight}
        aria-label="Scroll right"
        disabled={pairIndex >= Math.floor((tagList.length - 1) / 2)}
    >
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M9 18l6-6-6-6"/>
        </svg>
    </button>
</div>

<style lang="scss">
    .container {
        position: relative;
        width: 100%;
        padding: 0 32px;
        margin: 0 auto;
    }

    .list-box {
        position: relative;
        display: flex;
        gap: 12px;
        overflow-x: auto;
        scrollbar-width: none;
        scroll-behavior: smooth;
        -ms-overflow-style: none;
        padding: 4px 0;
        width: 100%;

        &::-webkit-scrollbar {
            display: none;
        }
    }

    .tag {
        white-space: nowrap;
        font-size: 14px;
        font-weight: 500;
        color: #1e293b;
        border-radius: 9999px;
        padding: 8px 20px;
        background-color: white;
        border: 1px solid #e2e8f0;
        transition: all 0.2s ease;
        flex: 1;

        &:hover {
            background-color: var(--hover-color);
        }

        &.active {
            background-color: #eef2ff;
            color: #4f46e5;
            border-color: #4f46e5;
        }
    }

    .arrow {
        position: absolute;
        top: 50%;
        transform: translateY(-50%);
        width: 24px;
        height: 24px;
        border-radius: 50%;
        background-color: white;
        border: 1px solid #e2e8f0;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: all 0.2s ease;
        z-index: 10;
        padding: 0;
        color: #64748b;

        &:disabled {
            opacity: 0.5;
            cursor: not-allowed;
            &:hover {
                background-color: white;
                box-shadow: none;
            }
        }

        svg {
            width: 16px;
            height: 16px;
            opacity: 0.6;
            transition: opacity 0.2s ease;
        }

        &:not(:disabled):hover {
            background-color: var(--hover-color);
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);

            svg {
                opacity: 0.8;
            }
        }
    }

    .left-arrow {
        left: 0;
    }

    .right-arrow {
        right: 0;
    }

    @media (max-width: 768px) {
        .container {
            padding: 0 28px;
        }

        .tag {
            font-size: 13px;
            padding: 8px 16px;
        }

        .arrow {
            width: 24px;
            height: 24px;

            svg {
                width: 14px;
                height: 14px;
            }
        }
    }
</style> 