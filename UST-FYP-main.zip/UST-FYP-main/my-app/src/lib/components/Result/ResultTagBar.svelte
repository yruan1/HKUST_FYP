<script content="module" lang="ts">
	interface Tag {
		value: number;
		fillMark: number;
	}

	export let currentTagIndex = 0;
	export let questions: { [key: string]: any } = {};

	$: tags = Object.keys(questions || {}).map((_, index) => ({
		value: 0,
		fillMark: 9
	}));
</script>

<div class="tag-container">
	{#each tags as tag, i}
		<button
			class="tag"
			class:active={i === currentTagIndex}
			on:click={() => {
				currentTagIndex = i;
			}}
		>
			<p>{i + 1}</p>
		</button>
	{/each}
</div>

<style lang="scss">
	.tag-container {
		display: flex;
		align-items: center;
		gap: 5px;
		height: 100%;
	}
	.tag {
		padding: 4px 12px;
		display: flex;
		border-radius: 8px;
		font-size: 16px;
		font-weight: 400;
		line-height: 24px;
		background-color: #f7f9fb;
		
		p {
			min-width: 16px;
			text-align: center;
		}
	}
	.number {
		font-weight: 500;
		color: rgb(215, 0, 13);
	}
	.active {
		color: rgb(255, 255, 255);
		background-color: red;
	}
</style>