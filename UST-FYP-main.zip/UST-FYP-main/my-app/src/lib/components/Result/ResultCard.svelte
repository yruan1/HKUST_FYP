<!-- ResultCard.svelte -->
<script lang="ts">
	import { createEventDispatcher } from 'svelte';
	import { doc, updateDoc } from 'firebase/firestore';
	import { db } from '$lib/firebase';
    import { onMount } from 'svelte';
	const dispatch = createEventDispatcher();

	export let value: string = '';
	export let description: string = ''; // This will remain unchanged
	export let examId: string = '';
	export let questionKey: string = '';
	export let isTeacher: boolean = false;
	export let activeCommentType: 'ai' | 'teacher' = 'ai';
	let userRole: string = '';

	let editedComment = ''; // Initialize separate from description
	let isEditing = false;
	let isSaving = false;
	let error: string | null = null;

	$: {
		if (isTeacher && activeCommentType === 'ai') {
			isEditing = false;
		}
	}

	function handleEdit() {

		if (userRole !== 'teacher') {
			alert('Only teachers can create exams');
			return;
		}

		if (isTeacher && activeCommentType === 'teacher') {
			isEditing = true;
			editedComment = examResult?.teacherComments?.[questionKey] || '';
		}
	}

	function handleCancel() {
		isEditing = false;
		editedComment = '';
		error = null;
	}

	async function getUserRole() {
		try {
			const uid = document.cookie
				.split('; ')
				.find((row) => row.startsWith('uid='))
				?.split('=')[1];

			if (uid) {
				const url = '/api/auth/getUserRole?uid=' + uid;
				const response = await fetch(url);
				if (!response.ok) {
					throw new Error('Failed to fetch user role');
				}
				const data = await response.json();
				userRole = data.role.toLowerCase();
			}
		} catch (error) {
			console.error('Error fetching user role:', error);
		}
	}

	async function handleSave() {
		if (!editedComment.trim()) return;

		isSaving = true;
		error = null;

		try {
			const examRef = doc(db, 'examResult', examId);

			await updateDoc(examRef, {
				[`teacherComments.${questionKey}`]: editedComment
			});

			dispatch('commentUpdated', { comment: editedComment });
			isEditing = false;
		} catch (err) {
			console.error('Save error:', err);
			error = 'Failed to save comment. Please try again.';
			return;
		} finally {
			isSaving = false;
		}
	}

	onMount(async () => {
		await getUserRole();
	});
</script>

<div class="result-card">
	<div class="content">
		<div class="header">
			<h1>{value}</h1>
		</div>
		<div class="description">
			{#if isTeacher}
				{#if isEditing && activeCommentType === 'teacher'}
					<div class="edit-mode">
						{#if error}
							<div class="error-message">{error}</div>
						{/if}
						<textarea
							bind:value={editedComment}
							class="comment-input"
							rows="4"
							placeholder="Enter your feedback here..."
							disabled={isSaving}
						/>
						<div class="button-group">
							<button
								class="action-button cancel"
								on:click|stopPropagation={handleCancel}
								disabled={isSaving}
							>
								Cancel
							</button>
							<button
								class="action-button save"
								on:click|stopPropagation={handleSave}
								disabled={isSaving || !editedComment.trim()}
							>
								{isSaving ? 'Saving...' : 'Save'}
							</button>
						</div>
					</div>
				{:else}
					<div class="view-mode">
						<p class="description-text">
							{description}
							<!-- Always show the original description -->
						</p>
						{#if userRole === 'teacher' && activeCommentType === 'teacher'}
							<button class="edit-button" on:click|stopPropagation={handleEdit}> Edit </button>
						{/if}
					</div>
				{/if}
			{:else}
				<p class="description-text">{description}</p>
			{/if}
		</div>
	</div>
</div>

<style lang="scss">
	.result-card {
		background-color: white;
		border-radius: 12px;
		padding: 16px;
		border: 2px solid #e2e8f0;
		transition: all 0.2s ease;
	}

	.content {
		.header {
			display: flex;
			justify-content: space-between;
			align-items: center;
			margin-bottom: 8px;

			h1 {
				font-size: 24px;
				font-weight: 600;
				color: #1e293b;
			}
		}
	}

	.description {
		.description-text {
			color: #64748b;
			font-size: 14px;
			line-height: 1.5;
		}
	}

	.view-mode {
		display: flex;
		justify-content: space-between;
		align-items: flex-start;
		gap: 12px;
	}

	.edit-button {
		padding: 4px 12px;
		border-radius: 4px;
		font-size: 12px;
		color: #4f46e5;
		background: transparent;
		border: 1px solid #4f46e5;
		cursor: pointer;
		transition: all 0.2s ease;

		&:hover {
			background-color: #4f46e5;
			color: white;
		}
	}

	.edit-mode {
		display: flex;
		flex-direction: column;
		gap: 12px;

		.comment-input {
			width: 100%;
			padding: 12px;
			border: 1px solid #e2e8f0;
			border-radius: 8px;
			font-size: 14px;
			resize: vertical;
			min-height: 100px;
			background-color: white;

			&:focus {
				outline: none;
				border-color: #4f46e5;
				box-shadow: 0 0 0 2px rgba(79, 70, 229, 0.1);
			}
		}

		.button-group {
			display: flex;
			gap: 8px;
			justify-content: flex-end;
		}
	}

	.action-button {
		padding: 8px 16px;
		border-radius: 6px;
		font-size: 14px;
		font-weight: 500;
		cursor: pointer;
		transition: all 0.2s ease;
		border: none;

		&.save {
			background-color: #4f46e5;
			color: white;

			&:hover:not(:disabled) {
				background-color: #4338ca;
			}
		}

		&.cancel {
			background-color: #e2e8f0;
			color: #64748b;

			&:hover:not(:disabled) {
				background-color: #cbd5e1;
			}
		}

		&:disabled {
			opacity: 0.5;
			cursor: not-allowed;
		}
	}

	.error-message {
		color: #ef4444;
		font-size: 14px;
		font-weight: 400;
		margin-bottom: -4px;
	}
</style>
