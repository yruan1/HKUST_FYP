<script lang="ts">
	import addFileSVG from '$lib/img/add-file.svg?raw';
	import { db } from '$lib/firebase';
	import { collection, addDoc, Timestamp } from 'firebase/firestore';
	import { onMount } from 'svelte';

	export let title = '??';
	export let checkShow: boolean = true;

	let examTitle: string = '';
	let year: number = new Date().getFullYear();
	let maxAttempts: number = 5;
	let startDate: string = '';
	let startTime: string = '';
	let startPeriod: 'AM' | 'PM' = 'PM';
	let dueDate: string = '';
	let dueTime: string = '';
	let duePeriod: 'AM' | 'PM' = 'PM';
	let questionParts: { part: number; content: string }[] = [{ part: 1, content: '' }];
	let showModal = false;
	let userRole: string = '';

	// Set default start date and time to today at noon
	const today = new Date();
	today.setHours(12, 0, 0, 0);
	startDate = today.toISOString().split('T')[0];
	startTime = '12:00';

	// Set default due date and time to tomorrow at noon
	const tomorrow = new Date();
	tomorrow.setDate(tomorrow.getDate() + 1);
	tomorrow.setHours(12, 0, 0, 0);
	dueDate = tomorrow.toISOString().split('T')[0];
	dueTime = '12:00';

	async function getUserRole() {
		try {
			const uid = document.cookie
				.split('; ')
				.find(row => row.startsWith('uid='))
				?.split('=')[1];

			if (uid) {
				const url = '/api/auth/getUserRole?uid=' + uid;
				const response = await fetch(url);
				if (!response.ok) {
					throw new Error('Failed to fetch user role');
				}
				const data = await response.json();
				userRole = data.role.toLowerCase();
			}
		} catch (error) {
			console.error('Error fetching user role:', error);
		}
	}

	function addQuestionPart() {
		const nextPart = questionParts.length + 1;
		questionParts = [...questionParts, { part: nextPart, content: '' }];
	}

	function removeQuestionPart(index: number) {
		questionParts = questionParts.filter((_, i) => i !== index);
		// Reorder part numbers
		questionParts = questionParts.map((q, i) => ({ ...q, part: i + 1 }));
	}

	function convertTo24Hour(time: string, period: 'AM' | 'PM'): string {
		const [hours, minutes] = time.split(':').map(Number);
		let hour24 = hours;
		
		if (period === 'PM' && hours !== 12) {
			hour24 = hours + 12;
		} else if (period === 'AM' && hours === 12) {
			hour24 = 0;
		}
		
		return `${hour24.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
	}

	function createTimestamp(date: string, time: string, period: 'AM' | 'PM'): Date {
		const [year, month, day] = date.split('-').map(Number);
		const time24 = convertTo24Hour(time, period);
		const [hours, minutes] = time24.split(':').map(Number);
		return new Date(year, month - 1, day, hours, minutes);
	}

	async function createExam() {
		try {
			// Additional check to ensure only teachers can create exams
			if (userRole !== 'teacher') {
				alert('Only teachers can create exams');
				return;
			}

			const startDateTime = createTimestamp(startDate, startTime, startPeriod);
			const dueDateTime = createTimestamp(dueDate, dueTime, duePeriod);

			// Validate that due date is after start date
			if (dueDateTime <= startDateTime) {
				alert('Due date must be after start date');
				return;
			}

			const docRef = await addDoc(collection(db, 'exams'), {
				title: examTitle,
				year,
				maxAttempts,
				startDate: Timestamp.fromDate(startDateTime),
				dueDate: Timestamp.fromDate(dueDateTime),
				questions: questionParts,
				createdAt: new Date()
			});

			console.log('Exam created with ID: ', docRef.id);
			// Reset form
			examTitle = '';
			questionParts = [{ part: 1, content: '' }];
			maxAttempts = 5;
			
			// Reset dates to default values
			const resetToday = new Date();
			resetToday.setHours(12, 0, 0, 0);
			startDate = resetToday.toISOString().split('T')[0];
			startTime = '12:00';
			startPeriod = 'PM';

			const resetTomorrow = new Date();
			resetTomorrow.setDate(resetTomorrow.getDate() + 1);
			resetTomorrow.setHours(12, 0, 0, 0);
			dueDate = resetTomorrow.toISOString().split('T')[0];
			dueTime = '12:00';
			duePeriod = 'PM';
			
			showModal = false;
		} catch (error) {
			console.error('Error creating exam: ', error);
		}
	}

	function tryOpenModal() {
		if (userRole === 'teacher') {
			showModal = true;
		} else {
			alert('Only teachers can create exams');
		}
	}

	onMount(async () => {
		await getUserRole();
	});
</script>

<div class="bar">
	<p>{title}</p>
	<!-- Only show add button if checkShow is true AND user is a teacher -->
	<div 
		class:show={checkShow && userRole === 'teacher'} 
		on:click={tryOpenModal}
		title={userRole !== 'teacher' ? 'Only teachers can create exams' : 'Add new exam'}
	>
		{@html addFileSVG}
	</div>
</div>

{#if showModal}
	<div class="modal-overlay">
		<div class="modal">
			<h2>Add New Exam</h2>

			<div class="form-group">
				<label for="examTitle">Exam Title:</label>
				<input 
					type="text" 
					id="examTitle" 
					bind:value={examTitle} 
					placeholder="Enter exam title"
					required
				/>
			</div>

			<div class="form-group">
				<label for="year">Year:</label>
				<input type="number" id="year" bind:value={year} min="1900" max="2100" />
			</div>

			<div class="form-group">
				<label for="attempts">Max Attempts:</label>
				<input 
					type="number" 
					id="attempts" 
					bind:value={maxAttempts} 
					min="1" 
					max="100"
					placeholder="Enter maximum attempts allowed"
				/>
			</div>

			<div class="form-group date-time-group">
				<label>Start Date and Time:</label>
				<div class="date-time-inputs">
					<input 
						type="date" 
						bind:value={startDate}
						min={new Date().toISOString().split('T')[0]}
					/>
					<div class="time-with-period">
						<input 
							type="time" 
							bind:value={startTime}
						/>
						<select bind:value={startPeriod}>
							<option value="AM">AM</option>
							<option value="PM">PM</option>
						</select>
					</div>
				</div>
			</div>

			<div class="form-group date-time-group">
				<label>Due Date and Time:</label>
				<div class="date-time-inputs">
					<input 
						type="date" 
						bind:value={dueDate}
						min={startDate}
					/>
					<div class="time-with-period">
						<input 
							type="time" 
							bind:value={dueTime}
						/>
						<select bind:value={duePeriod}>
							<option value="AM">AM</option>
							<option value="PM">PM</option>
						</select>
					</div>
				</div>
			</div>

			<div class="questions-container">
				{#each questionParts as questionPart, index}
					<div class="question-part">
						<div class="part-header">
							<h3>Part {questionPart.part}</h3>
							{#if questionParts.length > 1}
								<button class="remove-part" on:click={() => removeQuestionPart(index)}> × </button>
							{/if}
						</div>
						<textarea
							bind:value={questionPart.content}
							rows="4"
							placeholder="Enter question content..."
						></textarea>
					</div>
				{/each}

				<button class="add-part" on:click={addQuestionPart}> + Add Another Part </button>
			</div>

			<div class="button-group">
				<button class="cancel" on:click={() => (showModal = false)}>Cancel</button>
				<button class="submit" on:click={createExam}>Save</button>
			</div>
		</div>
	</div>
{/if}

<style lang="scss">
	.bar {
		--subheading-height: 57px;
		display: flex;
		justify-content: space-between;
		position: relative;
		align-items: center;
		font-family: Inter;
		font-size: 24px;
		font-weight: 400;
		height: var(--subheading-height);

		p {
			margin-left: 10px;
		}

		> div {
			display: flex;
			width: 69px;
			height: var(--subheading-height);
			border-radius: 10px;
			border: 1px solid rgba(0, 0, 0, 1);
			justify-content: center;
			align-items: center;
			background-color: var(--clr-nav);
			box-shadow: 0px 4px 4px 0px rgba(0, 0, 0, 0.25);
			display: none;
			cursor: pointer;
			:global(svg) {
				width: 32px;
				height: 32px;
			}
		}
		& .show {
			display: flex;
		}
	}

	.modal-overlay {
		position: fixed;
		top: 0;
		left: 0;
		right: 0;
		bottom: 0;
		background-color: rgba(0, 0, 0, 0.5);
		display: flex;
		justify-content: center;
		align-items: center;
		z-index: 1000;
	}

	.modal {
		background-color: white;
		padding: 2rem;
		border-radius: 10px;
		width: 90%;
		max-width: 600px;
		max-height: 90vh;
		overflow-y: auto;

		h2 {
			margin-bottom: 1.5rem;
			font-size: 1.5rem;
		}
	}

	.form-group {
		margin-bottom: 1rem;

		label {
			display: block;
			margin-bottom: 0.5rem;
			font-weight: 500;
			color: #333;
		}

		input {
			width: 100%;
			padding: 0.75rem;
			border: 1px solid #ccc;
			border-radius: 4px;
			font-size: 1rem;
			transition: border-color 0.2s ease;

			&:focus {
				outline: none;
				border-color: #22c55e;
				box-shadow: 0 0 0 2px rgba(34, 197, 94, 0.1);
			}

			&::placeholder {
				color: #999;
			}
		}
	}

	.date-time-group {
		.date-time-inputs {
			display: flex;
			gap: 1rem;

			input[type="date"] {
				flex: 2;
			}

			.time-with-period {
				flex: 1;
				display: flex;
				gap: 0.5rem;

				input[type="time"] {
					flex: 2;
				}

				select {
					flex: 1;
					padding: 0.75rem;
					border: 1px solid #ccc;
					border-radius: 4px;
					font-size: 1rem;
					background-color: white;
					cursor: pointer;

					&:focus {
						outline: none;
						border-color: #22c55e;
						box-shadow: 0 0 0 2px rgba(34, 197, 94, 0.1);
					}
				}
			}
		}
	}

	.questions-container {
		margin-bottom: 1.5rem;
	}

	.question-part {
		margin-bottom: 1rem;
		padding: 1rem;
		border: 1px solid #eee;
		border-radius: 4px;
		background-color: #f9f9f9;

		.part-header {
			display: flex;
			justify-content: space-between;
			align-items: center;
			margin-bottom: 0.5rem;

			h3 {
				margin: 0;
				font-size: 1.1rem;
			}
		}

		textarea {
			width: 100%;
			padding: 0.5rem;
			border: 1px solid #ccc;
			border-radius: 4px;
			font-size: 1rem;
			resize: vertical;

			&:focus {
				outline: none;
				border-color: #22c55e;
				box-shadow: 0 0 0 2px rgba(34, 197, 94, 0.1);
			}
		}
	}

	.remove-part {
		background: none;
		border: none;
		color: #ff4444;
		font-size: 1.5rem;
		cursor: pointer;
		padding: 0 0.5rem;

		&:hover {
			color: #ff0000;
		}
	}

	.add-part {
		width: 100%;
		padding: 0.5rem;
		background-color: #f0f0f0;
		border: 1px dashed #ccc;
		border-radius: 4px;
		cursor: pointer;
		font-size: 1rem;
		margin-top: 1rem;

		&:hover {
			background-color: #e0e0e0;
		}
	}

	.button-group {
		display: flex;
		justify-content: flex-end;
		gap: 1rem;
		margin-top: 1.5rem;

		button {
			padding: 0.5rem 1rem;
			border-radius: 4px;
			border: none;
			cursor: pointer;
			font-size: 1rem;
			transition: all 0.2s ease;

			&.cancel {
				background-color: #e0e0e0;

				&:hover {
					background-color: #d0d0d0;
				}
			}

			&.submit {
				background-color: #22c55e;
				color: white;
				font-weight: 500;

				&:hover {
					background-color: #16a34a;
					transform: translateY(-1px);
					box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
				}

				&:active {
					transform: translateY(0);
					box-shadow: none;
				}
			}
		}
	}
</style>