<script lang="ts">
    export let title: string;
    export let content: string;
    export let author: string;
    export let createdAt: any;

    // Format the timestamp
    $: formattedDate = createdAt ? new Date(createdAt.seconds * 1000).toLocaleString() : '';
</script>

<div class="announcement-card">
    <h3>{title}</h3>
    <p class="content">{content}</p>
    <div class="metadata">
        <span class="author">Posted by: {author}</span>
        <span class="date">{formattedDate}</span>
    </div>
</div>

<style lang="scss">
    .announcement-card {
        background-color: white;
        border-radius: 8px;
        padding: 1.5rem;
        margin-bottom: 1rem;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);

        h3 {
            margin: 0 0 1rem 0;
            color: #333;
        }

        .content {
            margin-bottom: 1rem;
            line-height: 1.5;
        }

        .metadata {
            display: flex;
            justify-content: space-between;
            font-size: 0.9rem;
            color: #666;

            .author {
                font-weight: 500;
            }

            .date {
                font-style: italic;
            }
        }
    }
</style>