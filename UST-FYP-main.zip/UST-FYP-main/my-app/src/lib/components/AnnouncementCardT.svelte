<script lang="ts">
    export let title: string;
    export let content: string;
    export let author: string;
    export let createdAt: any;
    export let onEdit: () => void;
    export let onDelete: () => void;

    $: formattedDate = createdAt ? new Date(createdAt.seconds * 1000).toLocaleString() : '';
</script>

<div class="announcement-card">
    <div class="header">
        <h3>{title}</h3>
        <div class="button-group">
            <button class="edit-button" on:click={onEdit}>
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
                    <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
                </svg>
            </button>
            <button class="icon-button delete" on:click={onDelete}>
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M3 6h18"/>
                    <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/>
                    <path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
                </svg>
            </button>
        </div>
    </div>
    <p class="content">{content}</p>
    <div class="metadata">
        <span class="author">Posted by: {author}</span>
        <span class="date">{formattedDate}</span>
    </div>
</div>

<style lang="scss">
    .announcement-card {
        background-color: white;
        border-radius: 8px;
        padding: 1.5rem;
        margin-bottom: 1rem;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;

            h3 {
                margin: 0;
                font-size: 1.25rem;
                color: #333;
            }
        }

        .button-group {
            display: flex;
            gap: 0.25rem;
        }

        .icon-button, .edit-button {
            background: none;
            border: none;
            cursor: pointer;
            padding: 0.35rem;
            border-radius: 4px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s ease;

            &:hover {
                background-color: #f0f0f0;
            }

            svg {
                width: 20px;
                height: 20px;
            }
        }

        .icon-button.delete {
            &:hover {
                background-color: #fee2e2;
                color: #dc2626;
            }
        }

        .content {
            margin: 1rem 0;
            line-height: 1.6;
            color: #4b5563;
        }

        .metadata {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 1rem;
            font-size: 0.875rem;
            color: #6b7280;

            .author {
                font-weight: 500;
            }

            .date {
                font-style: italic;
            }
        }
    }
</style>