<script lang="ts">
</script>

<button><slot /></button>

<style lang="scss">
	button {
		width: 100%;
		background-color: var(--clr-nav);
		border-radius: 10px;

		cursor: pointer;
		&:hover {
			background-color: var(--clr-hover-backgroud);
			color: var(--clr-hover-font);
		}
	}
</style>
