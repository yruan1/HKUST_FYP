<!-- LoadingPage.svelte -->
<script>
    export let text = 'Loading';
  </script>
  
  <div class="loading-screen">
    <div class="pulse-container">
      <div class="pulse-bubble pulse-bubble-1"></div>
      <div class="pulse-bubble pulse-bubble-2"></div>
      <div class="pulse-bubble pulse-bubble-3"></div>
    </div>
    <p>{text}</p>
  </div>
  
  <style>
    .loading-screen {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      background: #ffffff;
    }
  
    .pulse-container {
      display: flex;
      justify-content: center;
      align-items: center;
      gap: 6px;
    }
  
    .pulse-bubble {
      width: 20px;
      height: 20px;
      border-radius: 50%;
      background-color: #3498db;
    }
  
    .pulse-bubble-1 {
      animation: pulse 0.4s ease 0s infinite alternate;
    }
    .pulse-bubble-2 {
      animation: pulse 0.4s ease 0.2s infinite alternate;
    }
    .pulse-bubble-3 {
      animation: pulse 0.4s ease 0.4s infinite alternate;
    }
  
    @keyframes pulse {
      from {
        opacity: 1;
        transform: scale(1);
      }
      to {
        opacity: 0.25;
        transform: scale(0.75);
      }
    }
  
    p {
      margin-top: 1rem;
      color: #666;
      font-size: 1.1rem;
    }
  </style>