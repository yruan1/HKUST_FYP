<script lang="ts">
	export let icon = '';
	export let tagContent = '?';
	export let link = '/home';
	export let onClick = () => {};
</script>

<a href={link} on:click={onClick}>
	<div>
		<img src={icon} alt="" />
		<p>{tagContent}</p>
	</div>
</a>

<style lang="scss">
	a {
		padding: 8px 0px 8px 4px;
		display: flex;
		flex-direction: row;
		cursor: pointer;
		border-radius: 20px;
		position: relative;
		max-width: 180px;
		&:hover {
			background-color: var(--clr-hover-backgroud);
			color: var(--clr-hover-font);
		}
		> div {
			display: flex;
			gap: 10px;
			flex-direction: row;
			align-items: center;
			padding-left: 10px;
		}
	}
	p {
		line-height: 29px;
		text-shadow: rgba(0, 0, 0, 0.25) 0px 1px;
	}
</style>
