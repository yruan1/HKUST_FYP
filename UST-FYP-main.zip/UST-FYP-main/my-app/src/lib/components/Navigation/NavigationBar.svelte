<script lang="ts">
	import NavigationTag from './NavigationTag.svelte';
	import setting from '$lib/img/setting.svg';
	import exam from '$lib/img/Exam.svg';
	import assignment from '$lib/img/Assignment.svg';
	import statisics from '$lib/img/statisics.svg';
	import home from '$lib/img/home.svg';
	import userIcon from '$lib/img/user.svg';
	import { onMount } from 'svelte';
	import ChartCard from '../ChartCard.svelte';
	export let data;
	export let name: string;
	let userRole: string = '';

	interface Tag {
		icon: string;
		tagContent: string;
		herf: string;
		roles?: string[];
		roleSpecificHrefs?: {
			[key: string]: string;
		};
	}

	let list: Tag[] = [
		{
			icon: home,
			tagContent: 'Home',
			herf: '/home', // default href
			roleSpecificHrefs: {
				admin: '/settings/users',
				student: '/student',
				teacher: '/teacher'
			},
			roles: ['admin', 'student', 'teacher']
		},
		{
			icon: statisics,
			tagContent: 'Statisics',
			herf: '/student/statistics',
			roles: ['student']
		},
		{
			icon: assignment,
			tagContent: 'Assignment',
			herf: '/student/assignment',
			roleSpecificHrefs: {
				student: '/student/assignment',
				teacher: '/teacher/assignment'
			},
			roles: ['student', 'teacher']
		},
		{
			icon: exam,
			tagContent: 'Exam',
			herf: '/student/examquestion',
			roleSpecificHrefs: {
				student: '/student/examquestion',
				teacher: '/teacher/examquestion'
			},
			roles: ['student', 'teacher']
		},
		{
			icon: exam,
			tagContent: 'Practice',
			herf: '/student/practice',
			roleSpecificHrefs: {
				student: '/student/practice'
			},
			roles: ['student']
		}
	];

	interface User {
		name: string;
		icon: string;
	}

	let user: User = {
		name: name,
		icon: userIcon
	};

	let currentPageIndex = 0;
	let selectorY = 0;
	let tagGap = 0;

	async function getUserRole() {
		try {
			const uid = document.cookie
				.split('; ')
				.find((row) => row.startsWith('uid='))
				?.split('=')[1];

			if (uid) {
				const url = '/api/auth/getUserRole?uid=' + uid;
				const response = await fetch(url);
				if (!response.ok) {
					throw new Error('Failed to fetch user role');
				}
				const data = await response.json();
				userRole = data.role.toLowerCase();
			}
		} catch (error) {
			console.error('Error fetching user role:', error);
		}
	}

	function getHref(tag: Tag): string {
		if (userRole && tag.roleSpecificHrefs && tag.roleSpecificHrefs[userRole]) {
			return tag.roleSpecificHrefs[userRole];
		}
		return tag.herf;
	}

	$: visibleNavItems = list.filter(
		(item) => !item.roles || (item.roles && userRole && item.roles.includes(userRole.toLowerCase()))
	);

	function clearCookie(name: string) {
		document.cookie = name + '=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;';
	}

	onMount(async () => {
		await getUserRole();
		const url = document.URL;
		if (url.includes('/student/statistics') || url.includes('/teacher/assignment')) {
			currentPageIndex = 1;
		} else if (url.includes('/student/assignment') || url.includes('/teacher/examquestion')) {
			currentPageIndex = 2;
		} else if (url.includes('/student/examquestion')) {
			currentPageIndex = 3;
		} else if (url.includes('/student/practice')) {
			currentPageIndex = 4;
		} else {
			currentPageIndex = 0;
		}
		selectorY = currentPageIndex * 48;
		tagGap = currentPageIndex * 10;
	});
</script>

<div class="naviation" style="--selector-Y: {selectorY}px;  --tap-gap:{tagGap}px;">
	<div class="user">
		<img src={user.icon} alt="" />
		<p>{user.name}</p>
	</div>
	<div class="tag">
		<div class="selector"></div>
		<div class="page-tag">
			{#each visibleNavItems as tag, i}
				<button class:disable={currentPageIndex === i}>
					<NavigationTag
						tagContent={tag.tagContent}
						icon={tag.icon}
						link={getHref(tag)}
						onClick={() => {
							currentPageIndex = i;
							selectorY = currentPageIndex * 48;
							tagGap = currentPageIndex * 10;
						}}
					></NavigationTag>
				</button>
			{/each}
		</div>
		{#if userRole === 'admin'}
			<div class="other">
				<NavigationTag tagContent="User Setting" icon={setting} link="/settings/users"
				></NavigationTag>
				<NavigationTag
					tagContent="Sign Out"
					onClick={() => {
						clearCookie('uid');
					}}
					icon={setting}
					link="/"
				></NavigationTag>
			</div>
		{:else}
			<div class="other">
				<NavigationTag
					tagContent="Sign Out"
					onClick={() => {
						clearCookie('uid');
					}}
					icon={setting}
					link="/"
				></NavigationTag>
			</div>
		{/if}
	</div>
</div>

<style lang="scss">
	.naviation {
		background-color: var(--clr-nav);
		min-width: 230px;
		height: 100vh;
		position: sticky;
		color: var(--clr-nav-font);
		font-weight: 400;
		padding-top: 50px;
		font-size: 17px;
		top: 0;
		left: 0;
		z-index: 99;
	}
	.user {
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
		transform: translate(50);
		gap: 10px;
		height: 80px;
		> img {
			height: 50px;
			width: 50px;
		}
	}

	.tag {
		position: relative;
		display: flex;
		flex-direction: column;
		margin-top: 55px;
		margin-bottom: 20px;
		padding-left: 30px;
		justify-content: space-between;
		height: calc(100% - 155px);
		> .selector {
			position: absolute;
			width: 100%;
			height: 48px;
			left: 0;
			top: 0;
			background-color: var(--clr-content-background);
			color: var(--clr-hover-font);
			border-radius: 20px 0px 0px 20px;
			transform: translateY(calc(var(--selector-Y) + var(--tap-gap)));
			transition-duration: 0.2s;
			&::before {
				position: absolute;
				content: '';
				width: 30px;
				height: 30px;
				right: -2px;
				top: 0;
				background-color: var(--clr-nav-background);
				transform: translateY(-100%);
				border-bottom-right-radius: 30px;
				box-shadow: 7px 7px 0px 0px var(--clr-content-background);
			}
			&::after {
				position: absolute;
				content: '';
				width: 30px;
				height: 30px;
				right: -2px;
				bottom: 0;
				background-color: var(--clr-nav-background);
				transform: translateY(100%);
				border-top-right-radius: 30px;
				box-shadow: 7px -7px 0px 0px var(--clr-content-background);
			}
		}
	}
	.page-tag {
		display: flex;
		flex-direction: column;
		gap: 10px;
		> button {
			position: relative;
		}
	}
	.disable {
		:global(a) {
			&:hover {
				background-color: var(--clr-content-background);
				color: var(--clr-nav-font);
			}
		}
	}

	.loading-container {
		display: flex;
		justify-content: center;
		align-items: center;
		height: 100vh;
		background-color: var(--clr-nav);
	}

	.error-container {
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
		height: 100vh;
		background-color: var(--clr-nav);
		color: var(--clr-nav-font);
		text-align: center;
		padding: 2rem;
	}

	@media (max-width: 768px) {
		.naviation {
			min-width: 60px;
			padding-top: 20px;
		}

		.user {
			height: 60px;
			> img {
				height: 30px;
				width: 30px;
			}
			> p {
				display: none;
			}
		}

		.tag {
			padding-left: 10px;
			margin-top: 30px;
		}
	}
</style>
