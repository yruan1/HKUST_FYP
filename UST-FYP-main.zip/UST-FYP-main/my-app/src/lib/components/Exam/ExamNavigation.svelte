<script lang="ts">
	import { page } from '$app/stores';
	import { goto } from '$app/navigation';
	import { db } from '$lib/firebase';
	import { doc, getDoc } from 'firebase/firestore';
	import { onMount } from 'svelte';
	export let curXY: { x: number; y: number } = { x: 0, y: 0 };
	export let callback: () => void = () => {};
	let examYear: string = '';
	let userRole: string = '';

	function getCurrentPageName() {
		const path = $page.url.pathname;
		if (path.includes('/people')) {
			return 'People';
		} else if (path.includes('/statistics')) {
			return 'Statistics';
		} else if (path.includes('/')) {
			return 'Recommendation';
		}
		return 'Modules';
	}

	$: currentPage = getCurrentPageName();

	function goToRecommendation() {
		const examId = $page.params.examId;
		if(userRole === 'teacher'){
			goto(`/teacher/examquestion/exams/${examId}/people`);
		}else{
			goto(`/student/examquestion/exams/${examId}/`);
		}
	}

	function goToPeople() {
		if (userRole === 'teacher') {
			const examId = $page.params.examId;
			goto(`/teacher/examquestion/exams/${examId}/people`);
		} else {
			alert('Only teachers can access this feature');
		}
	}

	function goToStatistics() {
		const examId = $page.params.examId;

		if (userRole === 'teacher') {
			goto(`/teacher/examquestion/exams/${examId}/statistics`);
		}else if (userRole === 'student') {
			goto(`/student/examquestion/exams/${examId}/statistics`);
		}
		
	}

	async function fetchExamDetails() {
		try {
			const examId = $page.params.examId;
			const examRef = doc(db, 'exams', examId);
			const examDoc = await getDoc(examRef);

			if (examDoc.exists()) {
				const examData = examDoc.data();
				examYear = examData?.year || '';
			}
		} catch (err) {
			console.error('Error fetching exam details:', err);
		}
	}

	async function getUserRole() {
		try {
			const uid = document.cookie
				.split('; ')
				.find((row) => row.startsWith('uid='))
				?.split('=')[1];

			if (uid) {
				const url = '/api/auth/getUserRole?uid=' + uid;
				const response = await fetch(url);
				if (!response.ok) {
					throw new Error('Failed to fetch user role');
				}
				const data = await response.json();
				userRole = data.role.toLowerCase();
			}
		} catch (error) {
			console.error('Error fetching user role:', error);
		}
	}

	onMount(async () => {
		await getUserRole();
		fetchExamDetails();
	});
	let mainContent: HTMLDivElement | null = null;
</script>

<div class="top-nav">
	<button class="menu-button">
		<svg
			xmlns="http://www.w3.org/2000/svg"
			class="menu-icon"
			viewBox="0 0 24 24"
			fill="none"
			stroke="currentColor"
			stroke-width="2"
		>
			<line x1="3" y1="12" x2="21" y2="12"></line>
			<line x1="3" y1="6" x2="21" y2="6"></line>
			<line x1="3" y1="18" x2="21" y2="18"></line>
		</svg>
	</button>
	<div class="nav-content">
		{#if $page.url.pathname.includes('/examquestion')}
			{#if examYear}
				<button on:click={goToRecommendation} class="course-link"
					>{examYear} HKDSE English Language Examination Paper 2</button
				>
			{/if}
			{#if currentPage}
				<span class="separator">›</span>
				<span class="current-page">{currentPage}</span>
			{/if}
		{:else}
			<a href="#" class="course-link">2025</a>
		{/if}
	</div>
</div>

<main class="flex h-screen">
	<div class="sidebar">
		<nav class="sidebar-nav">
			<div class="semester-label">Explore</div>
			{#if userRole === 'student'}
				<button class="nav-link text-left" on:click={goToRecommendation}> Recommendation </button>
			{/if}

			<!-- Only show People button to teachers -->
			{#if userRole === 'teacher'}
				<button class="nav-link text-left" on:click={goToPeople}> People </button>
			{/if}

			<button class="nav-link text-left" on:click={goToStatistics}> Statistics </button>
		</nav>
	</div>

	<div
		class="main-content"
		bind:this={mainContent}
		on:scroll={() => {
			if (mainContent) {
				curXY.y = mainContent.scrollTop;

				if (callback) {
					callback();
				}
			}
		}}
	>
		<div class="container">
			<slot></slot>
		</div>
	</div>
</main>

<style lang="scss">
	.semester-label {
		color: #333;
		font-weight: 600;
		font-size: 1rem;
		margin-bottom: 1rem;
		padding-bottom: 0.5rem;
		border-bottom: 1px solid #e9ecef;
	}
	.top-nav {
		display: flex;
		align-items: center;
		padding: 0.75rem 1rem;
		border-bottom: 1px solid #e5e5e5;
		background-color: white;
	}

	.menu-button {
		background: none;
		border: none;
		padding: 0.5rem;
		cursor: pointer;
		margin-right: 0.5rem;

		&:hover {
			background-color: #f0f0f0;
			border-radius: 4px;
		}
	}

	.menu-icon {
		width: 24px;
		height: 24px;
		color: #666;
	}

	.nav-content {
		display: flex;
		align-items: center;
		gap: 0.5rem;
	}

	.course-link {
		color: #0066cc;
		text-decoration: none;
		font-weight: 500;

		&:hover {
			text-decoration: underline;
		}
	}

	.separator {
		color: #666;
		margin: 0 0.25rem;
	}

	.current-page {
		color: #666;
	}

	.flex {
		display: flex;
	}

	.h-screen {
		height: calc(100vh - 57px);
	}

	.sidebar {
		width: 250px;
		background-color: white;
		border-right: 1px solid #e9ecef;
		height: 100%;
		padding: 1.5rem;
	}

	.sidebar-nav {
		display: flex;
		flex-direction: column;
		gap: 1rem;
	}

	.nav-link {
		color: #0066cc;
		text-decoration: none;
		font-size: 1rem;
		transition: all 0.2s ease;
		background: none;
		border: none;
		padding: 0;
		cursor: pointer;
		text-align: left;

		&:hover {
			text-decoration: underline;
		}
	}

	.main-content {
		flex: 1;
		overflow-y: scroll;
	}

	.container {
		padding: 10px 40px;
	}

	@media (max-width: 768px) {
		.sidebar {
			position: fixed;
			z-index: 1000;
			background-color: white;
			box-shadow: 2px 0 8px rgba(0, 0, 0, 0.1);
		}

		.main-content {
			width: 100%;
		}

		.container {
			padding: 10px 20px;
		}
	}
</style>
