<script lang="ts">
	export let year: string = 'YYYY';
	export let btn1: string = 'Summer';
	export let btn2: string = 'Winter';
</script>

<div class="card">
	<!-- <div class="backgroud"></div> -->
	<h1>{year}</h1>
	<div class="btn-container">
		<div class="btn1">{btn1}</div>
		<div class="btn2">{btn2}</div>
	</div>
</div>

<style lang="scss">
	.card {
		position: relative;
		display: flex;
		flex-direction: column;
		width: 90%;
		height: 150px;
		background-color: var(--clr-nav);
		border-radius: 10px;
	}
	.btn-container {
		display: flex;
		flex-direction: row;
		padding: 0px 15px;
		gap: 20px;

		cursor: pointer;
		justify-content: space-between;
	}
	.btn1,
	.btn2 {
		display: flex;
		align-items: center;
		justify-content: center;
		box-shadow: 0px 4px 4px 0px rgba(0, 0, 0, 0.25);
		background-color: white;
		height: 30px;
		width: 50%;
		border-radius: 10px;
		margin-top: 10px;
		z-index: 1;
	}
	h1 {
		padding: 15px;
	}
</style>
