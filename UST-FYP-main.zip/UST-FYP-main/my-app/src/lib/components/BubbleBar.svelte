<script lang="ts">
	export let x = 0;
	export let y = 0;
	export let display = 'none';
	export let start: number;
	export let end: number;
	export let callback: (type: string) => void;
	import crossIMG from '$lib/img/cross.svg?raw';
	import tickIMG from '$lib/img/tick.svg?raw';
	import warningIMG from '$lib/img/warning.svg?raw';
</script>

<div class="bar" style="--x : {x}px ;--y : {y}px ;--display:{display}">
	<div>
		<button on:click={() => callback('CORRECT')}>
			{@html tickIMG}
		</button>
	</div>
	<div><button on:click={() => callback('WARNING')}>{@html warningIMG}</button></div>
	<div><button on:click={() => callback('WRONG')}>{@html crossIMG}</button></div>
</div>

<style lang="scss">
	.bar {
		width: 200px;
		height: 50px;
		position: absolute;
		background-color: #fbfcfe;
		border: 3px solid #b3d7ff;
		border-radius: 15px;
		top: calc(-70px + var(--y));
		left: calc(var(--x));
		z-index: 99;
		display: var(--display);
		flex-direction: row;
		align-items: center;
		gap: 8px;
		padding: 0px 5px;
		> div {
			display: flex;
			// background-color:#ebf0fa ;
			height: 100%;

			align-items: center;
			margin: 3px;
		}
	}
	button {
		&:hover {
			border-radius: 5px;
			background-color: #ebf0fa;
		}
		> :global(svg) {
			height: 100%;
			width: 55%;
		}
	}
</style>
