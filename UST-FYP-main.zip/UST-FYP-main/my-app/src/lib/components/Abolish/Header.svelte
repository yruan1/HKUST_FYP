<script lang="ts">
	import iconIMG from '$lib/img/icon.svg';
	import emailIMG from '$lib/img/email_icon.svg';
	import facebookIMG from '$lib/img/facebook_icon.svg';
	import instagramIMG from '$lib/img/instagram_icon.svg';
	import phoneIMG from '$lib/img/phone_icon.svg';
	// let Y: any;
	interface Path {
		name: string;
		href: string;
		label?: string;
		paths?: undefined;
	}
	const pages: Path[] = [
		{ name: 'Home', href: '/' },
		{ name: 'About Us', href: '/' },
		{ name: 'Services', href: '/' },
		{ name: 'Events', href: '/' },
		{ name: 'Advice', href: '/' },
		{ name: 'Contact Us', href: '/' }
	];
	let value;
</script>

<!-- <svelte:window bind:scrollY={Y} /> -->
<main>
	<div class="contact-bar">
		<img src={emailIMG} alt="" />
		<p>aaaa@gmail.com</p>
		<img src={facebookIMG} alt="" />
		<p>aaaa@gmail.com</p>
		<img src={instagramIMG} alt="" />
		<p>aaaa@gmail.com</p>
		<img src={phoneIMG} alt="" />
		<p>12345678</p>
	</div>
	<div class="container">
		<div>
			<img class="logo" src={iconIMG} alt="" />
			<div class="page-list">
				{#each pages as page}
					<a href={page.href}>{page.name}</a>
				{/each}
			</div>
		</div>
	</div>
</main>

<style lang="scss">
	main {
		position: relative;
	}
	.contact-bar {
		height: 25px;
		background-color: var(--clr-footer);
		display: flex;
		align-items: center;
		> img {
			max-height: 18px;
			padding: 0px 3px 0px 15px;
		}
		> p {
			color: #e0e0eb;
			font-size: 12px;
		}
	}
	.container {
		height: 70px;
		width: 100%;
		display: flex;

		&::after {
			content: '';
			background: linear-gradient(#e0e0eb, #f0f0f5);
			width: 100%;
			height: 5px;
			position: absolute;
			top: 100%;
		}
		> div {
			display: flex;
			width: 100%;
			padding: 0px 30px;
			align-items: center;
			justify-content: space-between;
		}
	}
	.logo {
		max-height: 55px;
	}
	.page-list {
		> a {
			color: #47476b;
			padding: 0px 11px;
			position: relative;
			transition: font-size 0.3s;
			&:hover {
				color: #80aaff;
				font-size: 17px;
			}
			&::after {
				position: absolute;
				content: '';
				left: 0;
				height: 100%;
				width: 2px;
				background-color: #e6eeff;
			}
		}
	}
</style>
