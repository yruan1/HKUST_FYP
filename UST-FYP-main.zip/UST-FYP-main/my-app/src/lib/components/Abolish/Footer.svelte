<script lang="ts">
	const year = new Date().getFullYear();
</script>

<footer></footer>

<style lang="scss">
	footer {
		width: 100%;
		height: 150px;
		background-color: var(--clr-footer);
	}
</style>
