<script lang="ts">
	import SearchBar from './SearchBar.svelte';
	import NotificationButton from './NotificationButton.svelte';
</script>

<div>
	<SearchBar></SearchBar>
	<NotificationButton></NotificationButton>
</div>

<style lang="scss">
	div {
		display: flex;
		flex-direction: row;
		width: 100%;
		align-items: center;
		padding-top: 10px;
		height: 84px;
	}
</style>
