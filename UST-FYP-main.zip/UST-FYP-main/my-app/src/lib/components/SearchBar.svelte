<script lang="ts">
	import search from '$lib/img/search.svg?raw';
	let inputValue: string = '';
</script>

<div class="box">
	<div class="svg-container" class:active={inputValue != ''}>
		{@html search}
	</div>
	<input bind:value={inputValue} type="text" class="bar" placeholder="Search Here..." />
</div>

<style lang="scss">
	.box {
		display: flex;
		align-items: center;
		width: 90%;
		padding-left: 100px;
		position: relative; /* Ensures the SVG aligns relative to the box */
	}
	.svg-container {
		pointer-events: none;
		position: absolute;
		display: flex;
		align-items: center;
		font-size: 24px;
		font-weight: 400;
		padding-left: 10px;
		gap: 20px;

		:global(svg) {
			width: 32px;
			height: 32px;
			opacity: 0.33;
		}
	}
	.bar {
		font-size: 24px;
		font-weight: 400;
		width: 100%;
		height: 55px;
		top: 25px;
		left: 273px;
		gap: 0px;
		border-radius: 10px;
		opacity: 0px;
		background: rgba(245, 245, 245, 1);
		box-shadow: 0px 4px 4px 0px rgba(0, 0, 0, 0.25);
		padding-left: 30px;
		&::placeholder {
			padding-left: 20px;
		}
	}
	.active {
		display: none;
	}
</style>
