<script lang="ts">
	import menu from '$lib/img/menu.svg?raw';
</script>

<div class="menu-btn">
	{@html menu}
</div>

<style lang="scss">
	.menu-btn {
		position: absolute;
		background-color: var(--clr-nav);
		display: flex;
		border-radius: 0px 10px 10px 0px;
		justify-content: center;
		align-items: center;
		width: 30px;
		height: 30px;
		top: 0px;
		left: 229px;
		:global(svg) {
			height: 32px;
			width: 32px;
			fill: currentColor;
		}
		&:hover {
			background-color: var(--clr-hover-backgroud);
			color: var(--clr-hover-font);
		}
		z-index: 99;
	}
</style>
