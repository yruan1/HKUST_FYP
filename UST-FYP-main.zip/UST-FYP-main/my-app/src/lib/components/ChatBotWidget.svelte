<script lang="ts">
	let isChatOpen = false;
	let isAiTyping = false;
	let messages: Array<{
		role: 'user' | 'assistant';
		content: string;
	}> = [];

	let userInput = '';

	function toggleChat() {
		isChatOpen = !isChatOpen;
	}

	async function handleSubmit() {
		if (!userInput.trim()) return;

		const currentInput = userInput;
		messages = [...messages, { role: 'user', content: currentInput }];
		userInput = '';

		isAiTyping = true;

		try {
			const response = await fetch('/api/chat', {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json'
				},
				body: JSON.stringify({
					systemPrompt: 'You are a helpful assistant.',
					userPrompt: currentInput
				})
			});

			const data = await response.json();
			messages = [
				...messages,
				{
					role: 'assistant',
					content: data.response
				}
			];
		} catch (error) {
			console.error('Failed to get response:', error);
		} finally {
			isAiTyping = false;
		}
	}
</script>

<!-- Chat button -->
<button class="chat-button" style="display: none;" on:click={toggleChat}>
	{#if isChatOpen}
		<span>✕</span>
	{:else}
		<span>💬</span>
	{/if}
</button>

<!-- Chat window -->
{#if isChatOpen}
	<div class="chat-container">
		<div class="header">
			Chat Assistant
			<button class="close-button" on:click={toggleChat}>✕</button>
		</div>

		<div class="messages">
			{#each messages as message}
				<div class="message {message.role}">
					{message.content}
				</div>
			{/each}

			{#if isAiTyping}
				<div class="message assistant typing-indicator">
					<span class="dot"></span>
					<span class="dot"></span>
					<span class="dot"></span>
				</div>
			{/if}
		</div>

		<div class="input-wrapper">
			<input
				type="text"
				bind:value={userInput}
				placeholder="Type a message..."
				on:keydown={(e) => e.key === 'Enter' && handleSubmit()}
			/>
			<button class="send-button" on:click={handleSubmit}>Send</button>
		</div>
	</div>
{/if}

<style>
	.chat-button {
		position: fixed;
		bottom: 20px;
		right: 20px;
		width: 60px;
		height: 60px;
		border-radius: 50%;
		background: #2d2d3a;
		color: white;
		border: none;
		cursor: pointer;
		box-shadow: 0 2px 12px rgba(0, 0, 0, 0.15);
		display: flex;
		align-items: center;
		justify-content: center;
		font-size: 24px;
		z-index: 1000;
		transition: transform 0.2s;
	}

	.chat-button:hover {
		transform: scale(1.1);
	}

	.chat-container {
		position: fixed;
		bottom: 100px;
		right: 20px;
		width: 380px;
		height: 600px;
		border-radius: 16px;
		overflow: hidden;
		display: flex;
		flex-direction: column;
		background: white;
		box-shadow: 0 2px 12px rgba(0, 0, 0, 0.15);
		z-index: 999;
		animation: slideIn 0.3s ease-out;
	}

	@keyframes slideIn {
		from {
			transform: translateY(100%);
			opacity: 0;
		}
		to {
			transform: translateY(0);
			opacity: 1;
		}
	}

	.header {
		background: #2d2d3a;
		color: white;
		padding: 20px;
		font-size: 18px;
		font-weight: 500;
		display: flex;
		justify-content: space-between;
		align-items: center;
	}

	.close-button {
		background: none;
		border: none;
		color: white;
		cursor: pointer;
		font-size: 20px;
		padding: 0;
	}

	.messages {
		flex: 1;
		padding: 20px;
		overflow-y: auto;
		display: flex;
		flex-direction: column;
		gap: 12px;
	}

	.message {
		max-width: 80%;
		padding: 12px;
		border-radius: 8px;
	}

	.message.user {
		background: #f0f0f0;
		align-self: flex-end;
	}

	.message.assistant {
		background: #f8f8f8;
		align-self: flex-start;
	}

	.typing-indicator {
		padding: 12px 20px;
		display: flex;
		align-items: center;
		gap: 4px;
		width: fit-content;
		min-width: 60px;
	}

	.dot {
		width: 8px;
		height: 8px;
		background: #666;
		border-radius: 50%;
		animation: bounce 1.4s infinite ease-in-out;
		display: inline-block;
	}

	.dot:nth-child(1) {
		animation-delay: -0.32s;
	}

	.dot:nth-child(2) {
		animation-delay: -0.16s;
	}

	@keyframes bounce {
		0%,
		80%,
		100% {
			transform: scale(0);
		}
		40% {
			transform: scale(1);
		}
	}

	.input-wrapper {
		padding: 20px;
		border-top: 1px solid #eee;
		display: flex;
		gap: 12px;
	}

	input {
		flex: 1;
		padding: 12px 20px;
		border: 1px solid #ddd;
		border-radius: 100px;
		outline: none;
		font-size: 16px;
	}

	input::placeholder {
		color: #999;
	}

	.send-button {
		background: #2d2d3a;
		color: white;
		border: none;
		border-radius: 100px;
		padding: 12px 24px;
		font-size: 14px;
		cursor: pointer;
		transition: background 0.2s;
	}

	.send-button:hover {
		background: #3d3d4a;
	}

	input:disabled,
	.send-button:disabled {
		opacity: 0.6;
		cursor: not-allowed;
	}

	@media (max-width: 480px) {
		.chat-container {
			width: calc(100% - 40px);
			height: calc(100% - 120px);
			bottom: 90px;
		}

		.chat-button {
			bottom: 16px;
			right: 16px;
		}
	}
</style>
