<script lang="ts">
	export let graphData: { date: string; count: number }[] = [];

	let width = 0;
	let height = 200;
	let padding = {
		left: 40,
		right: 60,
		top: 40,
		bottom: 60
	};

	const dateRanges = [
		{ label: '7 Days', days: 7 },
		{ label: '30 Days', days: 30 },
		{ label: '90 Days', days: 90 },
		{ label: 'All', days: null }
	];

	let selectedRange = dateRanges[0];

	function formatDate(dateStr: string, index: number, total: number) {
		const date = new Date(dateStr);

		if (total > 10) {
			if (index % Math.ceil(total / 5) !== 0 && index !== total - 1) {
				return '';
			}
		}

		if (total > 30) {
			return date.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
		} else {
			return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
		}
	}

	$: filteredData = selectedRange.days
		? graphData.filter((point) => {
				const pointDate = new Date(point.date);
				const currentDate = new Date();
				// Set current date to end of day to include today
				currentDate.setHours(23, 59, 59, 999);
				const cutoffDate = new Date(currentDate);
				cutoffDate.setDate(currentDate.getDate() - selectedRange.days + 1); // +1 to include today
				cutoffDate.setHours(0, 0, 0, 0); // Start of day
				return pointDate >= cutoffDate && pointDate <= currentDate;
			})
		: graphData;

	$: maxCount = Math.max(...filteredData.map((d) => d.count), 1);
	$: points = filteredData
		.map((point, i) => {
			const x =
				padding.left +
				(i * (width - padding.left - padding.right)) / (filteredData.length - 1 || 1);
			const y =
				height -
				(padding.bottom + (point.count / maxCount) * (height - padding.top - padding.bottom));
			return `${x},${y}`;
		})
		.join(' ');

	$: path = filteredData.length > 1 ? `M ${points}` : '';
</script>

<div class="graph-container" bind:clientWidth={width}>
	<div class="header">
		<div class="title">Writing Frequency</div>
		<div class="date-range-selector">
			{#each dateRanges as range}
				<button
					class="date-range-button"
					class:selected={selectedRange === range}
					on:click={() => (selectedRange = range)}
				>
					{range.label}
				</button>
			{/each}
		</div>
	</div>

	{#if filteredData.length === 0}
		<div class="no-data">No data available</div>
	{:else}
		<svg {width} {height}>
			<!-- Y-axis -->
			<line
				x1={padding.left}
				y1={padding.top}
				x2={padding.left}
				y2={height - padding.bottom}
				stroke="#94A3B8"
			/>

			<!-- X-axis -->
			<line
				x1={padding.left}
				y1={height - padding.bottom}
				x2={width - padding.right}
				y2={height - padding.bottom}
				stroke="#94A3B8"
			/>

			<!-- Data line -->
			<path d={path} stroke="#2DD4BF" stroke-width="2" fill="none" />

			<!-- Data points and labels -->
			{#each filteredData as point, i}
				{@const x =
					padding.left +
					(i * (width - padding.left - padding.right)) / (filteredData.length - 1 || 1)}
				{@const y =
					height -
					(padding.bottom + (point.count / maxCount) * (height - padding.top - padding.bottom))}

				<circle cx={x} cy={y} r="4" fill="#2DD4BF" />

				<!-- Date label -->
				{@const dateLabel = formatDate(point.date, i, filteredData.length)}
				{#if dateLabel}
					<text
						{x}
						y={height - padding.bottom + 20}
						text-anchor={i === filteredData.length - 1 ? 'end' : i === 0 ? 'start' : 'middle'}
						class="date-label"
					>
						{dateLabel}
					</text>
				{/if}

				<!-- Count label -->
				<text {x} y={y - 10} text-anchor="middle" class="count-label">
					{point.count}
				</text>
			{/each}

			<!-- Y-axis labels -->
			{#each Array(5) as _, i}
				{@const value = Math.round((maxCount * (4 - i)) / 4)}
				<text
					x={padding.left - 10}
					y={padding.top + (i * (height - padding.top - padding.bottom)) / 4}
					text-anchor="end"
					alignment-baseline="middle"
					class="axis-label"
				>
					{value}
				</text>
			{/each}
		</svg>
	{/if}
</div>

<style>
	.graph-container {
		background-color: white;
		border-radius: 0.5rem;
		padding: 1rem;
		margin-bottom: 1rem;
		box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
		overflow: hidden;
	}

	.header {
		display: flex;
		justify-content: space-between;
		align-items: center;
		margin-bottom: 1rem;
	}

	.title {
		font-size: 1.125rem;
		font-weight: 500;
		color: #1f2937;
	}

	.date-range-selector {
		display: flex;
		gap: 0.5rem;
	}

	.date-range-button {
		padding: 0.375rem 0.75rem;
		font-size: 0.875rem;
		border-radius: 0.375rem;
		border: 1px solid #e5e7eb;
		background-color: white;
		color: #6b7280;
		cursor: pointer;
		transition: all 0.2s ease;

		&:hover {
			background-color: #f9fafb;
		}

		&.selected {
			background-color: #2dd4bf;
			color: white;
			border-color: #2dd4bf;
		}
	}

	.no-data {
		text-align: center;
		padding: 2rem;
		color: #6b7280;
	}

	svg {
		width: 100%;
		height: 200px;
	}

	.date-label {
		font-size: 0.75rem;
		fill: #6b7280;
	}

	.count-label {
		font-size: 0.75rem;
		fill: #2dd4bf;
		font-weight: 500;
	}

	.axis-label {
		font-size: 0.75rem;
		fill: #6b7280;
	}
</style>
