<script lang="ts">
	import notification from '$lib/img/notification.svg?raw';
</script>

<a href="">
	{@html notification}
</a>

<style lang="scss">
	a {
		position: absolute;
		right: 1.5vw;
		:global(svg) {
			width: 30px;
			height: 30px;
		}
	}
</style>
