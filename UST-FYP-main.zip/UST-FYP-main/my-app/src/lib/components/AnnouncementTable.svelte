<script lang="ts">
    export let announcements;
    export function formatFirestoreTimestamp(timestamp) {
    const date = new Date(timestamp.seconds * 1000); // Convert seconds to milliseconds
    const options = {
      year: 'numeric',
      month: 'numeric',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false,
      timeZone: 'Asia/Tokyo', // Adjust the timezone if necessary
    };

  // Format the date using Intl.DateTimeFormat
  const formatter = new Intl.DateTimeFormat('ja-JP', options);
  return formatter.format(date).replace(/\//g, '/').replace(/ /g, '/ ').replace(/,/g, '/');
}
    console.log(announcements);
    //<th>Date</th>
    //<td>{formatFirestoreTimestamp(item.datetime)}</td>
</script>

<table >
	<thead>
        <tr>
          <th>Title</th>
          <th>Context</th>
    
          <th>Author</th>
        </tr>
    </thead>
	<tbody>
    {#each announcements as item}
    <tr>
      <td>{item.title}</td>
      <td>{item.content}</td>
      
      <td>{item.author}</td>
    </tr>
  {/each}
	</tbody>
</table>