<!-- src/lib/components/QuestionItem.svelte -->
<script>
    export let question = {
      id: 1,
      title: "Question 1",
      status: "Closed",
      publishedDate: "Apr 26 5:23pm",
      dueDate: "Apr 26 12:00am",
      submitted: 0,
      total: 2
    };
  </script>
  
  <div class="question-item">
    <div class="question-header">
      <div class="edit-icon">
        <svg viewBox="0 0 24 24" width="20" height="20">
          <path fill="currentColor" d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34a.996.996 0 0 0-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/>
        </svg>
      </div>
      <h3>{question.title}</h3>
      <span class={`status ${question.status.toLowerCase()}`}>{question.status}</span>
    </div>
    <div class="question-metadata">
      <span>Published {question.publishedDate}</span>
      <span class="separator">|</span>
      <span>Due {question.dueDate}</span>
      <span class="separator">|</span>
      <span>Submitted {question.submitted}/{question.total}</span>
    </div>
    <hr>
  </div>
  
  <style>
    .question-item {
      padding: 10px 0;
    }
    
    .question-header {
      display: flex;
      align-items: center;
      gap: 10px;
    }
    
    h3 {
      font-size: 18px;
      margin: 0;
      flex-grow: 1;
    }
    
    .edit-icon {
      color: #333;
      cursor: pointer;
    }
    
    .status {
      padding: 2px 8px;
      border-radius: 4px;
      font-size: 12px;
      font-weight: bold;
    }
    
    .status.closed {
      background-color: #ff5252;
      color: white;
    }
    
    .question-metadata {
      margin-top: 5px;
      font-size: 14px;
      color: #666;
    }
    
    .separator {
      margin: 0 5px;
    }
    
    hr {
      border: none;
      border-top: 1px solid #eee;
      margin: 10px 0 0 0;
    }
  </style>