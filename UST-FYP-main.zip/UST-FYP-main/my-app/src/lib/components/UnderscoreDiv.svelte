<script lang="ts">
</script>

<div>
	<slot />
</div>

<style lang="scss">
	
	div {
		position: relative;
		&::after {
			position: absolute;
			content: '';
			width: 60%;
			height: 2px;
			left: 0;
			transform: translateX(33.333%);
			background-color: var(--clr-nav);
		}
	}
</style>
