<script content="module" lang="ts">
	import type { Task } from '$lib/type';
	export let tasks: Task[] = [{ title: 'Empty', dueDate: 'None' }];
</script>

<table class="list-container">
	<tr><td>Titile</td><td>Due Date</td></tr>
	{#each tasks as task}
		<tr><td>{task.title}</td><td>{task.dueDate}</td></tr>
	{/each}
</table>

<style lang="scss">
	.list-container {
		display: flex;
		flex-direction: column;
		width: 100%;
		min-height: 300px;
		max-height: 500px;
		background-color: var(--clr-nav);
		border-radius: 10px;
		padding: 0px 20px;
		margin-bottom: 15px;
		overflow-y: scroll;
	}
	tr {
		position: relative;
		display: flex;
		justify-content: space-between;
		padding: 20px 0px;
		&::after {
			position: absolute;
			content: '';
			width: 100%;
			height: 1px;
			bottom: 0;
			background-color: black;
		}
	}
	tr:not(:first-of-type) {
		font-size: 24px;
		font-weight: 400;
	}
</style>
