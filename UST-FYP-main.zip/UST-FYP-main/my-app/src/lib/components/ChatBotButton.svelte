<script lang="ts">
	import chatIMG from '$lib/img/chat.svg?raw';
</script>

<div class="chat-btn">
	{@html chatIMG}
	<!-- <img src={chatIMG} alt="" /> -->
</div>

<style lang="scss">
	.chat-btn {
		display: flex;
		width: 70px;
		height: 60px;
		position: absolute;
		bottom: 15px;
		right: 15px;
		background-color: var(--clr-nav);
		border: 1px solid rgba(0, 0, 0, 1);
		border-radius: 10px;
		justify-content: center;
		align-items: center;
		box-shadow: 0px 4px 4px 0px rgba(0, 0, 0, 0.25);
		> img {
			width: 32px;
			height: 32px;
		}
		&:hover {
			background-color: var(--clr-hover-backgroud);
			color: var(--clr-hover-font);
		}
		cursor: pointer;
		:global(svg) {
			fill: currentColor;
			width: 32px;
			height: 32px;
		}
		z-index: 99;
	}
</style>
