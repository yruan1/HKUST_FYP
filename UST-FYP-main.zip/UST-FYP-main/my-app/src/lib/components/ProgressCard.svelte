<script lang="ts">
	import home from '$lib/img/home.svg';
	interface ProgressCard {
		img: string;
		category: string;
		progress: string;
	}
	let progressCards: ProgressCard[] = [
		{
			img: home,
			category: 'exam',
			progress: '20/20'
		},
		{
			img: home,
			category: 'assignment',
			progress: '19/20'
		}
	];
</script>

<div class="box">
	<div class="title">Completeness</div>
	<div class="list">
		{#each progressCards as card}
			<div class="card">
				<div class="container">
					<img src={card.img} alt="" />
					<div>
						<p class="category">{card.category}</p>
						<p class="progress">{card.progress}</p>
					</div>
				</div>
			</div>
		{/each}
	</div>
</div>

<style lang="scss">
	.box {
		display: flex;
		flex-direction: column;
		align-items: center;
		width: fit-content;
	}
	.title {
		font-size: 22px;
		font-weight: 700;
		line-height: 30.8px;
		text-align: left;
		text-underline-position: from-font;
		text-decoration-skip-ink: none;
	}
	.list {
		display: flex;
		flex-direction: column;
		gap: 12px;
	}
	.card {
		width: fit-content;
		width: 280px;
		padding: 16px;
		border-radius: 24px;
		background-color: aqua;
	}
	.container {
		display: flex;
		padding: 36px 48px;
		gap: 20px;
		background-color: white;
	}
	.category {
		font-size: 14px;
		font-weight: 400;
		line-height: 19.6px;
		text-align: left;
		text-underline-position: from-font;
		text-decoration-skip-ink: none;
	}
	.progress {
		font-size: 12px;
		font-weight: 400;
		line-height: 16.8px;
		text-align: left;
		text-underline-position: from-font;
		text-decoration-skip-ink: none;
		color: rgba(149, 155, 165, 1);
	}
</style>
