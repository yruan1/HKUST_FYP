<script lang="ts">
	import CircleChart from './CircleChart.svelte';
	export let title = 'Default Title';
	export let value: number = 10;
</script>

<div class="card">
	<div>
		<p>{title}</p>
	</div>
	<div class="info">
		<p>bbb</p>
		<CircleChart {value} />
	</div>
</div>

<style lang="scss">
	.card {
		width: 200px;
		padding: 0px 10px;
		display: flex;
		flex-direction: column;
		box-shadow:
			6px 6px 10px -1px rgba(0, 0, 0, 0.15),
			-6px -6px 10px -1px rgba(255, 255, 255, 0.7);
		border-style: solid;
		border-radius: 20px;
		border-color: antiquewhite;
	}
	.info {
		display: flex;
		align-items: center;
		justify-content: space-between;
	}
</style>
