<script lang="ts">
	interface Tag {
		value: number;
		fillMark: number;
	}
	let tags: Tag[] = [
		{
			value: 0,
			fillMark: 9
		},
		{
			value: 0,
			fillMark: 9
		},
		{
			value: 0.0,
			fillMark: 9.5
		}
	];
	let currentIndex = 0;
</script>

<div class="tag-container">
	{#each tags as tag, i}
		<button
			class="tag"
			class:active={i === currentIndex}
			on:click={() => {
				currentIndex = i;
			}}
		>
			<p>{i + 1}</p>
			<p class="content">{tag.value}/{tag.fillMark}</p>
		</button>
	{/each}
</div>

<style lang="scss">
	.tag-container {
		display: flex;
		align-items: center;
		gap: 5px;
	}
	.tag {
		gap: 14px;
		padding: 4px 8px;
		display: flex;
		border-radius: 8px;
		font-size: 16px;
		font-weight: 400;
		line-height: 24px;
		background-color: #f7f9fb;
	}
	.number {
		font-weight: 500;
		color: rgb(215, 0, 13);
	}
	.content {
		background-color: var(--clr-content-background);
		color: #606266;
		padding: 0px 4px;
		border-radius: 12px;
	}
	.active {
		color: rgb(255, 255, 255);
		background-color: red;
	}
</style>
