export function getCurrentUserIdFromCookie(): string | null {
    try {
        if (typeof document === 'undefined') return null;
        
        const cookies = document.cookie.split(';');
        const uidCookie = cookies
            .map(cookie => cookie.trim())
            .find(cookie => cookie.startsWith('uid='));
            
        if (!uidCookie) return null;
        
        const uid = uidCookie.split('=')[1];
        return uid || null;
    } catch (error) {
        console.error('Error getting user ID from cookie:', error);
        return null;
    }
}