export const clearAuthCookies = (cookies: any) => {
    cookies.delete('uid', { path: '/' });
    cookies.delete('uid', { path: '/student' }); // Clear cookie with specific path
};
