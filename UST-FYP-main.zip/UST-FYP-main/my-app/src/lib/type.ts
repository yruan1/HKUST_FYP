export interface Task {
    title: string;
    dueDate: string;
}
export interface Student{
    
}