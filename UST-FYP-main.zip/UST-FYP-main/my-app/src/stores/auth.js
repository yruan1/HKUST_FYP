import { writable } from "svelte/store";
import { auth } from "../firebase";
import { onAuthStateChanged } from "firebase/auth";

/**
 * @typedef {import("firebase/auth").User} User
 */

/** @type {import("svelte/store").Writable<User | null>} */
export const user = writable(null);

// Listen for authentication state changes
onAuthStateChanged(auth, (currentUser) => {
  if (currentUser) {
    user.set(currentUser); // Update the store when the user logs in
  } else {
    user.set(null); // Set the store to null when the user logs out
  }
});